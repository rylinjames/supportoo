/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as atomicBilling from "../atomicBilling.js";
import type * as billing from "../billing.js";
import type * as browse from "../browse.js";
import type * as categories from "../categories.js";
import type * as cleanup from "../cleanup.js";
import type * as companies from "../companies.js";
import type * as crons from "../crons.js";
import type * as events from "../events.js";
import type * as livekit from "../livekit.js";
import type * as lounge from "../lounge.js";
import type * as participantBilling from "../participantBilling.js";
import type * as participantMute from "../participantMute.js";
import type * as participants from "../participants.js";
import type * as planManagement from "../planManagement.js";
import type * as plans from "../plans.js";
import type * as promos from "../promos.js";
import type * as reactions from "../reactions.js";
import type * as rooms from "../rooms.js";
import type * as screenShare from "../screenShare.js";
import type * as seedPlans from "../seedPlans.js";
import type * as setup from "../setup.js";
import type * as usage from "../usage.js";
import type * as users from "../users.js";
import type * as webhooks from "../webhooks.js";
import type * as whop from "../whop.js";
import type * as whopPayments from "../whopPayments.js";
import type * as whopPaymentsMutations from "../whopPaymentsMutations.js";
import type * as whopSync from "../whopSync.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

/**
 * A utility for referencing Convex functions in your app's API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
declare const fullApi: ApiFromModules<{
  atomicBilling: typeof atomicBilling;
  billing: typeof billing;
  browse: typeof browse;
  categories: typeof categories;
  cleanup: typeof cleanup;
  companies: typeof companies;
  crons: typeof crons;
  events: typeof events;
  livekit: typeof livekit;
  lounge: typeof lounge;
  participantBilling: typeof participantBilling;
  participantMute: typeof participantMute;
  participants: typeof participants;
  planManagement: typeof planManagement;
  plans: typeof plans;
  promos: typeof promos;
  reactions: typeof reactions;
  rooms: typeof rooms;
  screenShare: typeof screenShare;
  seedPlans: typeof seedPlans;
  setup: typeof setup;
  usage: typeof usage;
  users: typeof users;
  webhooks: typeof webhooks;
  whop: typeof whop;
  whopPayments: typeof whopPayments;
  whopPaymentsMutations: typeof whopPaymentsMutations;
  whopSync: typeof whopSync;
}>;
declare const fullApiWithMounts: typeof fullApi;

export declare const api: FilterApi<
  typeof fullApiWithMounts,
  FunctionReference<any, "public">
>;
export declare const internal: FilterApi<
  typeof fullApiWithMounts,
  FunctionReference<any, "internal">
>;

export declare const components: {
  crons: {
    public: {
      del: FunctionReference<
        "mutation",
        "internal",
        { identifier: { id: string } | { name: string } },
        null
      >;
      get: FunctionReference<
        "query",
        "internal",
        { identifier: { id: string } | { name: string } },
        {
          args: Record<string, any>;
          functionHandle: string;
          id: string;
          name?: string;
          schedule:
            | { kind: "interval"; ms: number }
            | { cronspec: string; kind: "cron"; tz?: string };
        } | null
      >;
      list: FunctionReference<
        "query",
        "internal",
        {},
        Array<{
          args: Record<string, any>;
          functionHandle: string;
          id: string;
          name?: string;
          schedule:
            | { kind: "interval"; ms: number }
            | { cronspec: string; kind: "cron"; tz?: string };
        }>
      >;
      register: FunctionReference<
        "mutation",
        "internal",
        {
          args: Record<string, any>;
          functionHandle: string;
          name?: string;
          schedule:
            | { kind: "interval"; ms: number }
            | { cronspec: string; kind: "cron"; tz?: string };
        },
        string
      >;
    };
  };
};
