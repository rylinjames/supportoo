import { internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { components } from "./_generated/api";
import { internal } from "./_generated/api";
import { Crons } from "@convex-dev/crons";

const crons = new Crons(components.crons);

// Clean up events older than 24 hours
export const cleanupOldEvents = internalMutation({
  args: {},
  handler: async (ctx): Promise<number> => {
    const twentyFourHoursAgo = Date.now() - 24 * 60 * 60 * 1000; // 24 hours in milliseconds

    const oldEvents = await ctx.db
      .query("loungeEvents")
      .withIndex("by_time", (q) => q.lt("createdAt", twentyFourHoursAgo))
      .collect();

    // Delete old events
    for (const event of oldEvents) {
      await ctx.db.delete(event._id);
    }

    console.log(`🧹 Cleaned up ${oldEvents.length} old events`);
    return oldEvents.length; // Return number of events deleted
  },
});

// Clean up expired reactions
export const cleanupExpiredReactions = internalMutation({
  args: {},
  handler: async (ctx): Promise<number> => {
    const now = Date.now();

    const expiredReactions = await ctx.db
      .query("reactions")
      .withIndex("by_expires", (q) => q.lt("expiresAt", now))
      .collect();

    // Delete expired reactions
    for (const reaction of expiredReactions) {
      await ctx.db.delete(reaction._id);
    }

    console.log(`🧹 Cleaned up ${expiredReactions.length} expired reactions`);
    return expiredReactions.length; // Return number of reactions deleted
  },
});

// Register daily cleanup cron job
export const registerDailyCleanupCron = internalMutation({
  args: {},
  handler: async (ctx): Promise<string> => {
    // Check if cron job already exists
    const existingCron = await crons.get(ctx, { name: "daily-cleanup" });

    if (existingCron === null) {
      // Register daily cleanup cron job (runs at midnight UTC)
      const cronId: string = await crons.register(
        ctx,
        { kind: "cron", cronspec: "0 0 * * *" }, // Daily at 00:00 UTC
        internal.cleanup.runDailyCleanup,
        {},
        "daily-cleanup"
      );

      console.log("✅ Registered daily cleanup cron job with ID:", cronId);
      return cronId;
    } else {
      console.log("ℹ️ Daily cleanup cron job already exists");
      return existingCron.id;
    }
  },
});

// Clean up active rooms with no participants (edge case cleanup)
export const cleanupInactiveRooms = internalMutation({
  args: {},
  handler: async (ctx): Promise<number> => {
    // Find rooms that are marked as active but have no participants (edge case)
    const activeRooms = await ctx.db
      .query("rooms")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .collect();

    let deletedRooms = 0;

    for (const room of activeRooms) {
      // Check if room has any participants
      const participants = await ctx.db
        .query("participants")
        .withIndex("by_room", (q) => q.eq("roomId", room._id))
        .collect();

      if (participants.length === 0) {
        // Room has no participants, clean up everything and delete the room

        // Clean up all reactions for this room
        const roomReactions = await ctx.db
          .query("reactions")
          .withIndex("by_room", (q) => q.eq("roomId", room._id))
          .collect();

        for (const reaction of roomReactions) {
          await ctx.db.delete(reaction._id);
        }

        // Clean up all reaction history for this room
        const roomReactionHistory = await ctx.db
          .query("reactionHistory")
          .withIndex("by_room", (q) => q.eq("roomId", room._id))
          .collect();

        for (const historyItem of roomReactionHistory) {
          await ctx.db.delete(historyItem._id);
        }

        // Clean up all lounge events for this room
        const roomEvents = await ctx.db
          .query("loungeEvents")
          .withIndex("by_room", (q) => q.eq("roomId", room._id))
          .collect();

        for (const event of roomEvents) {
          await ctx.db.delete(event._id);
        }

        // Delete the room itself
        await ctx.db.delete(room._id);
        deletedRooms++;

        console.log(`🗑️ Deleted inactive room: ${room.name} (${room._id})`);
      }
    }

    console.log(
      `🧹 Cleaned up ${deletedRooms} inactive rooms with no participants`
    );
    return deletedRooms;
  },
});

// Clean up orphaned participants (participants tied to deleted/non-existent rooms)
export const cleanupOrphanedParticipants = internalMutation({
  args: {},
  handler: async (ctx): Promise<number> => {
    const allParticipants = await ctx.db.query("participants").collect();
    let deletedParticipants = 0;

    for (const participant of allParticipants) {
      // Check if the room still exists
      const room = await ctx.db.get(participant.roomId);

      if (!room) {
        // Room doesn't exist, delete this orphaned participant
        await ctx.db.delete(participant._id);
        deletedParticipants++;
        console.log(
          `🗑️ Deleted orphaned participant: ${participant._id} (room: ${participant.roomId})`
        );
      }
    }

    console.log(`🧹 Cleaned up ${deletedParticipants} orphaned participants`);
    return deletedParticipants;
  },
});

// Hourly cleanup function that runs room and participant cleanup
export const runHourlyCleanup = internalMutation({
  args: {},
  handler: async (
    ctx
  ): Promise<{
    inactiveRoomsDeleted: number;
    orphanedParticipantsDeleted: number;
    totalDeleted: number;
  }> => {
    console.log("🕐 Starting hourly cleanup...");

    // Clean up inactive rooms with no participants
    const inactiveRoomsDeleted: number = await ctx.runMutation(
      internal.cleanup.cleanupInactiveRooms,
      {}
    );

    // Clean up orphaned participants
    const orphanedParticipantsDeleted: number = await ctx.runMutation(
      internal.cleanup.cleanupOrphanedParticipants,
      {}
    );

    console.log(
      `✅ Hourly cleanup completed: ${inactiveRoomsDeleted} inactive rooms, ${orphanedParticipantsDeleted} orphaned participants deleted`
    );

    return {
      inactiveRoomsDeleted,
      orphanedParticipantsDeleted,
      totalDeleted: inactiveRoomsDeleted + orphanedParticipantsDeleted,
    };
  },
});

// Combined cleanup function that runs both event and reaction cleanup
export const runDailyCleanup = internalMutation({
  args: {},
  handler: async (
    ctx
  ): Promise<{
    eventsDeleted: number;
    reactionsDeleted: number;
    totalDeleted: number;
  }> => {
    console.log("🕐 Starting daily cleanup...");

    // Clean up old events
    const eventsDeleted: number = await ctx.runMutation(
      internal.cleanup.cleanupOldEvents,
      {}
    );

    // Clean up expired reactions
    const reactionsDeleted: number = await ctx.runMutation(
      internal.cleanup.cleanupExpiredReactions,
      {}
    );

    console.log(
      `✅ Daily cleanup completed: ${eventsDeleted} events, ${reactionsDeleted} reactions deleted`
    );

    return {
      eventsDeleted,
      reactionsDeleted,
      totalDeleted: eventsDeleted + reactionsDeleted,
    };
  },
});

// Register hourly cleanup cron job
export const registerHourlyCleanupCron = internalMutation({
  args: {},
  handler: async (ctx): Promise<string> => {
    // Check if cron job already exists
    const existingCron = await crons.get(ctx, { name: "hourly-cleanup" });

    if (existingCron === null) {
      // Register hourly cleanup cron job (runs every hour at minute 0)
      const cronId: string = await crons.register(
        ctx,
        { kind: "cron", cronspec: "0 * * * *" }, // Every hour at minute 0
        internal.cleanup.runHourlyCleanup,
        {},
        "hourly-cleanup"
      );

      console.log("✅ Registered hourly cleanup cron job with ID:", cronId);
      return cronId;
    } else {
      console.log("ℹ️ Hourly cleanup cron job already exists");
      return existingCron.id;
    }
  },
});
