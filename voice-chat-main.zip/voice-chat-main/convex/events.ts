import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { Id } from "./_generated/dataModel";

// Event types enum
export const EVENT_TYPES = {
  USER_JOINED: "user_joined",
  USER_LEFT: "user_left",
  SPEAK_REQUEST: "speak_request",
  USER_KICKED: "user_kicked",
  USER_BANNED: "user_banned",
  ROLE_PROMOTED: "role_promoted",
  ROLE_DEMOTED: "role_demoted",
  ROOM_RENAMED: "room_renamed",
  LOUNGE_STARTED: "lounge_started",
  ROOM_CODE_UPDATED: "room_code_updated",
  MINUTE_WARNING: "minute_warning",
  SCREEN_SHARE_STARTED: "screen_share_started",
  SCREEN_SHARE_STOPPED: "screen_share_stopped",
  PARTICIPANT_MUTED: "participant_muted",
  PARTICIPANT_UNMUTED: "participant_unmuted",
  ALL_SPEAKERS_MUTED: "all_speakers_muted",
} as const;

export type EventType = (typeof EVENT_TYPES)[keyof typeof EVENT_TYPES];

// Helper function to get first name from full name
export const getFirstName = (fullName: string): string => {
  return fullName.split(" ")[0] || fullName;
};

// Event data interface
export interface EventData {
  userName?: string;
  targetUserName?: string;
  actorUserName?: string;
  oldRole?: string;
  newRole?: string;
  oldRoomName?: string;
  newRoomName?: string;
  moderatorName?: string;
  participantId?: string;
  warningLevel?: string;
  minutesRemaining?: number;
}

// Create event helper function
export const createLoungeEvent = async (
  ctx: any,
  {
    roomId,
    eventType,
    userId,
    targetUserId,
    actorUserId,
    eventData,
  }: {
    roomId: Id<"rooms">;
    eventType: EventType;
    userId?: Id<"users">;
    targetUserId?: Id<"users">;
    actorUserId?: Id<"users">;
    eventData: EventData;
  }
) => {
  return await ctx.db.insert("loungeEvents", {
    roomId,
    eventType,
    userId,
    targetUserId,
    actorUserId,
    eventData,
    createdAt: Date.now(),
  });
};

// Get latest events for a room (for initial load)
export const getLatestEvents = query({
  args: { roomId: v.id("rooms"), limit: v.number() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("loungeEvents")
      .withIndex("by_room_and_time", (q) => q.eq("roomId", args.roomId))
      .order("desc")
      .take(args.limit);
  },
});

// Get events before a specific timestamp (for infinite scroll)
export const getEventsBefore = query({
  args: {
    roomId: v.id("rooms"),
    beforeTimestamp: v.number(),
    limit: v.number(),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("loungeEvents")
      .withIndex("by_room_and_time", (q) =>
        q.eq("roomId", args.roomId).lt("createdAt", args.beforeTimestamp)
      )
      .order("desc")
      .take(args.limit);
  },
});

// Delete all events for a room (when room becomes inactive)
export const deleteRoomEvents = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const events = await ctx.db
      .query("loungeEvents")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    // Delete all events for the room
    for (const event of events) {
      await ctx.db.delete(event._id);
    }

    return events.length; // Return number of events deleted
  },
});

// Query to get recent warning events for a room
export const getRecentWarningEvents = query({
  args: {
    roomId: v.id("rooms"),
    minutes: v.number(), // How many minutes back to look
  },
  handler: async (ctx, args) => {
    const cutoffTime = Date.now() - args.minutes * 60 * 1000;

    const warningEvents = await ctx.db
      .query("loungeEvents")
      .withIndex("by_room_and_time", (q) =>
        q.eq("roomId", args.roomId).gte("createdAt", cutoffTime)
      )
      .filter((q) => q.eq(q.field("eventType"), "minute_warning"))
      .order("desc")
      .collect();

    return warningEvents;
  },
});
