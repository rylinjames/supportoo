import { WebhookReceiver } from "livekit-server-sdk";
import { ConvexHttpClient } from "convex/browser";
import { api } from "@/convex/_generated/api";

const receiver = new WebhookReceiver(
  process.env.LIVEKIT_API_KEY!,
  process.env.LIVEKIT_API_SECRET!
);

const convex = new ConvexHttpClient(process.env.NEXT_PUBLIC_CONVEX_URL!);

export async function POST(req: Request) {
  try {
    // Get the raw body for webhook verification
    const body = await req.text();
    const authHeader = req.headers.get("Authorization") || undefined;
    console.log("=== WEBHOOK RECEIVED ===");
    // Verify and decode the webhook
    const event = await receiver.receive(body, authHeader);
    console.log("=== DECODED WEBHOOK EVENT ===");
    // Handle different webhook events
    switch (event.event) {
      case "room_started":
        console.log("Room started:", event.room?.name);
        // Room creation is handled by our app, not webhooks
        break;
      case "participant_joined":
        console.log(
          "Participant joined:",
          event.participant?.identity,
          "in room:",
          event.room?.name
        );
        if (event.room && event.participant) {
          await convex.mutation(api.webhooks.handleParticipantJoined, {
            event: event.event,
            room: { name: event.room.name },
            participant: {
              identity: event.participant.identity,
              name: event.participant.name || event.participant.identity,
            },
          });
        }
        break;
      case "participant_left":
        console.log(
          "Participant left:",
          event.participant?.identity,
          "from room:",
          event.room?.name
        );
        if (event.room && event.participant) {
          await convex.mutation(api.webhooks.handleParticipantLeft, {
            event: event.event,
            room: { name: event.room.name },
            participant: { identity: event.participant.identity },
          });
        }
        break;
      case "room_finished":
        console.log("Room finished:", event.room?.name);
        if (event.room) {
          await convex.mutation(api.webhooks.handleRoomDeleted, {
            event: event.event,
            room: { name: event.room.name },
          });
        }
        break;
      default:
        console.log("Unhandled webhook event:", event.event);
    }
    console.log("=== WEBHOOK PROCESSING COMPLETE ===");
    return new Response("OK", { status: 200 });
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error";
    const errorStack = error instanceof Error ? error.stack : "No stack trace";
    console.error("=== WEBHOOK ERROR ===");
    console.error("Error:", error);
    console.error("Error message:", errorMessage);
    console.error("Error stack:", errorStack);
    return new Response(
      JSON.stringify({
        error: "Webhook Error",
        message: errorMessage,
        stack: errorStack,
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
}
