const Footer = () => {
  return (
    <div className="absolute bottom-0 left-0 right-0 z-50 border-t bg-background border-neutral-200 dark:border-neutral-800 w-full p-4 flex items-center justify-between h-[73px]">
      <div className="flex flex-col md:flex-row w-full text-sm justify-between items-center">
        <p>All rights reserved</p>
        <p className="text-neutral-400">
          Voice Lounge.{" "}
          <span className="text-neutral-800 dark:text-white">
            Powered by Bookoo Apps
          </span>
        </p>
      </div>
    </div>
  );
};

export default Footer;
