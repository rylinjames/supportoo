"use client";

import { motion } from "motion/react";
import {
  Volume2,
  VolumeX,
  ChevronRight,
  ChevronLeft,
  HomeIcon,
  ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { toast } from "sonner";
import { useMutation, useAction, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import MobileLoungeSidebar from "./mobile/mobile-lounge-sidebar";
import { Participant } from "./types";
import Link from "next/link";

interface LoungeHeaderProps {
  roomName: string; // Changed from companyName to roomName
  participantCount: number;
  onVolumeToggle: () => void;
  volume: boolean;
  onSidebarToggle: () => void;
  sidebarOpen: boolean;
  experienceId: string;
  roomId: string;
  whopUserData: {
    _id: string;
    whopUserId: string;
    whopUsername: string;
    fullName: string;
    isAnonymous?: boolean;
  };
  currentUserRole: string;
  roomDetails: any;
  localParticipant: any;
  handleReaction: (emoji: string) => void;
  canRequestToSpeak: boolean;
  handleRequestToSpeak: () => void;
  openResetConfirmation: () => void;
  isReactionOpen: boolean;
  setIsReactionOpen: (open: boolean) => void;
  isPublic: boolean;
  // Screen share props for mobile sidebar
  canScreenShare?: boolean;
  isSharing?: boolean;
  screenShareLoading?: boolean;
  screenShareActive?: boolean;
  screenShareError?: string | null;
  participants?: Participant[];
  onStartScreenShare?: () => void;
  onStopScreenShare?: () => void;
  onTakeoverScreenShare?: () => void;
  // Participant management functions
  onAddToSpeakers?: (participantId: string) => void;
  onRemoveFromSpeakers?: (participantId: string) => void;
  onKickFromLounge?: (participantId: string) => void;
  onPromoteToModerator?: (participantId: string) => void;
  onDemoteModeratorToSpeaker?: (participantId: string) => void;
  canManageModerators?: boolean;
}

export function LoungeHeader({
  roomName, // Changed from companyName to roomName
  participantCount,
  onVolumeToggle,
  volume,
  onSidebarToggle,
  sidebarOpen,
  experienceId,
  roomId,
  whopUserData,
  currentUserRole,
  roomDetails,
  localParticipant,
  handleReaction,
  canRequestToSpeak,
  handleRequestToSpeak,
  openResetConfirmation,
  isReactionOpen,
  setIsReactionOpen,
  isPublic,
  // Screen share props
  canScreenShare,
  isSharing,
  screenShareLoading,
  screenShareActive,
  screenShareError,
  participants,
  onStartScreenShare,
  onStopScreenShare,
  onTakeoverScreenShare,
  // Participant management functions
  onAddToSpeakers,
  onRemoveFromSpeakers,
  onKickFromLounge,
  onPromoteToModerator,
  onDemoteModeratorToSpeaker,
  canManageModerators,
}: LoungeHeaderProps) {
  const title = roomName; // Use room name directly instead of adding "Lounge"

  // Test event mutations
  const updateRoomSettingsMutation = useMutation(api.rooms.updateRoomSettings);
  const updateParticipantRoleMutation = useMutation(
    api.participants.updateParticipantRole
  );
  const banUserMutation = useMutation(api.rooms.banUserFromRoom);
  const testLiveKitRoomsAction = useAction(api.livekit.testLiveKitRooms);
  const activeRoomsQuery = useQuery(api.rooms.getActiveRoomsForTest);

  // Test event functions
  const testRenameRoom = async () => {
    try {
      await updateRoomSettingsMutation({
        roomId: roomId as Id<"rooms">,
        name: `Test Room ${Date.now()}`,
      });
      toast.success("Room renamed for testing");
    } catch (error) {
      toast.error("Failed to rename room");
    }
  };

  const testPromoteUser = async () => {
    try {
      await updateParticipantRoleMutation({
        roomId: roomId as Id<"rooms">,
        userId: whopUserData._id as Id<"users">,
        role: "speaker",
      });
      toast.success("User promoted for testing");
    } catch (error) {
      toast.error("Failed to promote user");
    }
  };

  const testDemoteUser = async () => {
    try {
      await updateParticipantRoleMutation({
        roomId: roomId as Id<"rooms">,
        userId: whopUserData._id as Id<"users">,
        role: "listener",
      });
      toast.success("User demoted for testing");
    } catch (error) {
      toast.error("Failed to demote user");
    }
  };

  const testBanUser = async () => {
    try {
      await banUserMutation({
        roomId: roomId as Id<"rooms">,
        userId: whopUserData._id as Id<"users">,
      });
      toast.success("User banned for testing");
    } catch (error) {
      toast.error("Failed to ban user");
    }
  };

  const testResetToModerator = async () => {
    try {
      await updateParticipantRoleMutation({
        roomId: roomId as Id<"rooms">,
        userId: whopUserData._id as Id<"users">,
        role: "moderator",
      });
      toast.success("User reset to moderator for testing");
    } catch (error) {
      toast.error("Failed to reset to moderator");
    }
  };

  const testLiveKitRooms = async () => {
    try {
      const result = await testLiveKitRoomsAction();
      console.log("=== LIVEKIT ROOMS ===");
      console.log("LiveKit Rooms:", result);
      console.log("=== DATABASE ACTIVE ROOMS ===");
      console.log("DB Active Rooms:", activeRoomsQuery);

      if (result.success) {
        toast.success(
          `LiveKit: ${result.roomCount} rooms | DB: ${activeRoomsQuery?.length || 0} active rooms`
        );
      } else {
        toast.error(`LiveKit error: ${result.error}`);
      }
    } catch (error) {
      console.error("Failed to test LiveKit rooms:", error);
      toast.error("Failed to test LiveKit rooms");
    }
  };

  const handleOpenWhopInNewTab = () => {
    window.open("https://whop.com", "_blank");
  };

  return (
    <motion.header
      className="border-b border-neutral-200 dark:border-neutral-800 p-6 max-md:p-4 max-lg:px-8"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <div>
            <h1 className="text-2xl font-bold mb-1">{title}</h1>
            <p className="text-neutral-600 dark:text-neutral-400 text-sm">
              {participantCount} participant
              {participantCount === 1 ? "" : "s"}
            </p>
          </div>

          {/* Test Event Buttons */}
          {process.env.NODE_ENV === "development" && (
            <div className="flex items-center gap-1 ml-4">
              <Button
                size="sm"
                variant="outline"
                onClick={testRenameRoom}
                className="text-xs px-2 py-1 h-6 bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white"
              >
                Rename
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={testPromoteUser}
                className="text-xs px-2 py-1 h-6 bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white"
              >
                Promote
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={testDemoteUser}
                className="text-xs px-2 py-1 h-6 bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white"
              >
                Demote
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={testBanUser}
                className="text-xs px-2 py-1 h-6 bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white"
              >
                Ban
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={testResetToModerator}
                className="text-xs px-2 py-1 h-6 bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white"
              >
                Reset to Moderator
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  navigator.clipboard.writeText(window.location.href);
                }}
                className="text-xs px-2 py-1 h-6 bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white"
              >
                Copy URL
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={testLiveKitRooms}
                className="text-xs px-2 py-1 h-6 bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white"
              >
                Test LiveKit
              </Button>
            </div>
          )}
        </div>
        <div className="flex items-center gap-3">
          <Tooltip>
            <TooltipTrigger asChild>
              <Link href={`/experiences/${experienceId}/browse`}>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-neutral-600 dark:text-neutral-400 hover:text-white! hover:bg-primary!"
                >
                  <HomeIcon className="w-5 h-5" />
                  <span className="sr-only">Back to Browse</span>
                </Button>
              </Link>
            </TooltipTrigger>
            <TooltipContent>
              <p>Back to Browse</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                onClick={onVolumeToggle}
                className="text-neutral-600 dark:text-neutral-400 hover:text-white! hover:bg-primary!"
              >
                {volume ? (
                  <Volume2 className="w-5 h-5" />
                ) : (
                  <VolumeX className="w-5 h-5" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{volume ? "Mute Volume" : "Unmute Volume"}</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleOpenWhopInNewTab}
                className="text-neutral-600 dark:text-neutral-400 hover:text-white! hover:bg-primary!"
              >
                <ExternalLink className="w-5 h-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Open Whop in New Tab</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                onClick={onSidebarToggle}
                className="text-neutral-600 dark:text-neutral-400 hover:text-white! hover:bg-primary! max-lg:hidden"
              >
                {sidebarOpen ? (
                  <ChevronRight className="w-5 h-5" />
                ) : (
                  <ChevronLeft className="w-5 h-5" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{sidebarOpen ? "Close Sidebar" : "Open Sidebar"}</p>
            </TooltipContent>
          </Tooltip>
          <MobileLoungeSidebar
            roomId={roomId}
            whopUserData={whopUserData}
            currentUserRole={currentUserRole}
            roomDetails={roomDetails}
            localParticipant={localParticipant}
            handleReaction={handleReaction}
            canRequestToSpeak={canRequestToSpeak}
            handleRequestToSpeak={handleRequestToSpeak}
            openResetConfirmation={openResetConfirmation}
            isReactionOpen={isReactionOpen}
            setIsReactionOpen={setIsReactionOpen}
            // Screen share props
            canScreenShare={canScreenShare}
            isSharing={isSharing}
            screenShareLoading={screenShareLoading}
            screenShareActive={screenShareActive}
            screenShareError={screenShareError}
            participantCount={participants?.length || 0}
            participants={participants}
            onStartScreenShare={onStartScreenShare}
            onStopScreenShare={onStopScreenShare}
            onTakeoverScreenShare={onTakeoverScreenShare}
            // Participant management functions
            onAddToSpeakers={onAddToSpeakers}
            onRemoveFromSpeakers={onRemoveFromSpeakers}
            onKickFromLounge={onKickFromLounge}
            onPromoteToModerator={onPromoteToModerator}
            onDemoteModeratorToSpeaker={onDemoteModeratorToSpeaker}
            canManageModerators={canManageModerators}
          />
        </div>
      </div>
    </motion.header>
  );
}
