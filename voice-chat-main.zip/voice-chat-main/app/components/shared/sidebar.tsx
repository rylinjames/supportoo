import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/avatar";
import { ThemeToggler } from "./theme-toggler";
import { Trash2 } from "lucide-react";

const Sidebar = () => {
  return (
    <div className="flex flex-col justify-between gap-4 w-1/6 py-8 px-4 h-full border-r border-neutral-200 bg-white dark:bg-foreground dark:border-neutral-800">
      <Link
        href="/lounge-setup/test-company"
        className="flex transition-all duration-300 items-center gap-2 w-full rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-800 p-2"
      >
        <Avatar>
          <AvatarImage src="/images/voice-lounge-logo.png" />
          <AvatarFallback>VL</AvatarFallback>
        </Avatar>
        <p>Voice Lounge</p>
      </Link>

      <Link
        href="/test-cleanup"
        className="flex transition-all duration-300 items-center gap-2 w-full rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-800 p-2 text-red-600 dark:text-red-400"
      >
        <Trash2 className="h-4 w-4" />
        <p>Test Cleanup</p>
      </Link>

      <div className="w-full flex justify-end">
        <ThemeToggler />
      </div>
    </div>
  );
};

export default Sidebar;
