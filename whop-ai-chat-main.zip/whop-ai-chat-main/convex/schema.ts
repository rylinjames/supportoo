import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * Complete Database Schema for AI Support Agent
 *
 * Multi-tenant architecture with companyId on every table
 * Real-time sync with Convex live queries
 * Optimized indexes for common query patterns
 */

export default defineSchema({
  // ============================================================================
  // PLANS - Subscription tiers
  // ============================================================================
  plans: defineTable({
    name: v.union(v.literal("free"), v.literal("pro"), v.literal("elite")),
    price: v.number(), // Monthly price in cents

    // Whop integration
    whopPlanId: v.optional(v.string()), // Whop's plan ID (null for free plan)

    // AI Configuration
    aiModels: v.array(v.string()), // Available AI models (e.g., ["gpt-3.5-turbo"])
    aiResponsesPerMonth: v.number(),

    // Features
    hasTemplates: v.boolean(),
    hasInsights: v.boolean(),
    hasPrioritySupport: v.boolean(),
    hasCustomTriggers: v.boolean(),
    hasFileAttachments: v.boolean(),

    // Limits
    maxAgents: v.number(),
    maxConversations: v.number(),
  })
    .index("by_name", ["name"])
    .index("by_whop_plan_id", ["whopPlanId"]),

  // ============================================================================
  // COMPANIES - Multi-tenant root
  // ============================================================================
  companies: defineTable({
    // Core company info
    whopCompanyId: v.string(), // Whop's company ID
    name: v.string(),
    domain: v.optional(v.string()),
    timezone: v.string(),

    // Plan & Billing
    planId: v.id("plans"),
    billingStatus: v.union(
      v.literal("active"),
      v.literal("canceled"),
      v.literal("past_due"),
      v.literal("trialing")
    ),
    currentPeriodStart: v.number(),
    currentPeriodEnd: v.number(),

    // Whop billing integration
    whopMembershipId: v.optional(v.string()), // Links to Whop subscription
    lastPaymentAt: v.optional(v.number()),

    // Usage tracking
    aiResponsesThisMonth: v.number(),
    aiResponsesResetAt: v.number(),
    usageWarningSent: v.optional(v.boolean()), // True if 80% warning sent this cycle

    // Scheduled plan changes (for cancellations)
    scheduledPlanChangeAt: v.optional(v.number()), // When to execute change
    scheduledPlanId: v.optional(v.id("plans")), // What plan to change to

    // AI Configuration
    aiPersonality: v.union(
      v.literal("professional"),
      v.literal("friendly"),
      v.literal("casual"),
      v.literal("technical")
    ),
    aiResponseLength: v.union(
      v.literal("brief"),
      v.literal("medium"),
      v.literal("detailed")
    ),
    aiSystemPrompt: v.string(),
    aiHandoffTriggers: v.array(v.string()),
    selectedAiModel: v.string(), // Selected from plan's available models

    // Company context
    companyContextOriginal: v.string(), // Raw text for editing
    companyContextProcessed: v.string(), // AI-condensed version
    companyContextFileId: v.optional(v.id("company_context_files")),
    companyContextLastUpdated: v.number(),

    // OpenAI Assistants API
    openaiAssistantId: v.optional(v.string()), // OpenAI Assistant ID (created per company)
    openaiVectorStoreId: v.optional(v.string()), // Vector Store ID for company knowledge base
    openaiContextFileId: v.optional(v.string()), // Current context file ID in Vector Store
    testAssistantId: v.optional(v.string()), // Cached test assistant ID (for AI Studio testing)

    // Onboarding status
    onboardingCompleted: v.boolean(),
    setupWizardCompleted: v.boolean(),

    // Metadata
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_whop_company_id", ["whopCompanyId"])
    .index("by_plan", ["planId"])
    .index("by_billing_status", ["billingStatus"]),

  // ============================================================================
  // USERS - All user types (admin, support, customer)
  // ============================================================================
  users: defineTable({
    // Whop integration
    whopUserId: v.string(),
    companyId: v.optional(v.id("companies")), // TEMPORARY - will be removed after migration

    // User info (from Whop)
    whopUsername: v.string(),
    displayName: v.string(),
    avatarUrl: v.optional(v.string()),

    // Role (cached from Whop) - TEMPORARY - will be removed after migration
    role: v.optional(
      v.union(v.literal("admin"), v.literal("support"), v.literal("customer"))
    ),
    roleLastChecked: v.number(), // When we last verified with Whop

    // User preferences
    timezone: v.string(),
    theme: v.union(v.literal("light"), v.literal("dark"), v.literal("system")),
    notificationsEnabled: v.boolean(),

    // Activity tracking
    lastActiveAt: v.number(),
    lastLoginAt: v.number(),

    // Metadata
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_whop_user_id", ["whopUserId"])
    .index("by_whop_username", ["whopUsername"])
    .index("by_company_role", ["companyId", "role"]) // TEMPORARY - will be removed
    .index("by_company", ["companyId"]), // TEMPORARY - will be removed

  // ============================================================================
  // USER_COMPANIES - Junction table for multi-company support
  // ============================================================================
  user_companies: defineTable({
    // Relationships
    userId: v.id("users"),
    companyId: v.id("companies"),

    // Role in this specific company
    role: v.union(
      v.literal("admin"),
      v.literal("support"),
      v.literal("customer")
    ),

    // Timestamps
    joinedAt: v.number(), // When user joined this company
    lastActiveInCompany: v.number(), // Last time user was active in this company

    // Metadata
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_company", ["companyId"])
    .index("by_user_company", ["userId", "companyId"]) // Compound for unique lookups
    .index("by_company_role", ["companyId", "role"]) // For team member queries
    .index("by_last_active", ["lastActiveInCompany"]), // For default company selection

  // ============================================================================
  // CONVERSATIONS - Chat sessions
  // ============================================================================
  conversations: defineTable({
    // Relationships
    companyId: v.id("companies"),
    customerId: v.id("users"),

    // Status & flow
    status: v.union(
      v.literal("ai_handling"),
      v.literal("available"),
      v.literal("support_staff_handling"),
      v.literal("resolved")
    ),
    handoffTriggeredAt: v.optional(v.number()),
    handoffReason: v.optional(v.string()), // e.g., "User requested support staff", "Billing question"

    // Conversation metadata
    messageCount: v.number(),
    lastMessageAt: v.number(),
    firstMessageAt: v.number(),

    // Agent participation (group chat model)
    participatingAgents: v.array(v.id("users")),
    lastAgentMessage: v.optional(v.number()),

    // AI processing state
    aiProcessing: v.boolean(),
    aiProcessingStartedAt: v.optional(v.number()),

    // Debouncing
    pendingAIJobId: v.optional(v.id("_scheduled_functions")),

    // OpenAI Assistants API
    openaiThreadId: v.optional(v.string()), // Maps to OpenAI Thread for this conversation

    // Rolling summarization
    summary: v.optional(v.string()),
    lastSummaryAt: v.optional(v.number()),
    lastSummaryMessageCount: v.optional(v.number()),

    // Metadata
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_company_status", ["companyId", "status"])
    .index("by_company_customer", ["companyId", "customerId"])
    .index("by_company_updated", ["companyId", "updatedAt"])
    .index("by_status", ["status"]),

  // ============================================================================
  // MESSAGES - Individual messages in conversations
  // ============================================================================
  messages: defineTable({
    // Relationships
    conversationId: v.id("conversations"),
    companyId: v.id("companies"), // Denormalized for performance

    // Message content
    role: v.union(
      v.literal("customer"),
      v.literal("ai"),
      v.literal("agent"),
      v.literal("system")
    ),
    content: v.string(),

    // Sender info (for agent messages)
    agentId: v.optional(v.id("users")),
    agentName: v.optional(v.string()), // Denormalized for performance

    // AI metadata (for ai messages)
    aiModel: v.optional(v.string()),
    tokensUsed: v.optional(v.number()),
    processingTime: v.optional(v.number()),

    // Message metadata
    timestamp: v.number(),

    // Read receipts (for customer/agent messages only, not AI/system)
    readByAgentAt: v.optional(v.number()), // When ANY agent first read this message
    readByCustomerAt: v.optional(v.number()), // When customer first read this message

    // File attachments (Elite plan only)
    attachmentUrl: v.optional(v.string()),
    attachmentName: v.optional(v.string()),
    attachmentSize: v.optional(v.number()),
    attachmentType: v.optional(v.string()),

    // System message context
    systemMessageType: v.optional(
      v.union(
        v.literal("handoff"),
        v.literal("agent_joined"),
        v.literal("agent_left"),
        v.literal("issue_resolved")
      )
    ),
  })
    .index("by_conversation", ["conversationId", "timestamp"])
    .index("by_company", ["companyId", "timestamp"])
    // Compound indexes for efficient unread message queries
    .index("by_conversation_role_unread_agent", [
      "conversationId",
      "role",
      "readByAgentAt",
    ])
    .index("by_conversation_role_unread_customer", [
      "conversationId",
      "role",
      "readByCustomerAt",
    ]),

  // ============================================================================
  // TEMPLATES - Quick reply templates
  // ============================================================================
  templates: defineTable({
    // Relationships
    companyId: v.id("companies"),
    createdBy: v.id("users"),

    // Template content
    title: v.string(),
    content: v.string(),
    category: v.union(
      v.literal("greeting"),
      v.literal("escalation"),
      v.literal("resolution"),
      v.literal("general")
    ),

    // Usage tracking
    usageCount: v.number(),
    lastUsedAt: v.optional(v.number()),
    lastUsedBy: v.optional(v.id("users")),

    // Template management
    isActive: v.boolean(),
    isDefault: v.boolean(), // System-created vs user-created

    // Metadata
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_company_category", ["companyId", "category"])
    .index("by_company_active", ["companyId", "isActive"])
    .index("by_creator", ["createdBy"]),

  // ============================================================================
  // USAGE RECORDS - AI response usage tracking
  // ============================================================================
  usageRecords: defineTable({
    // Relationships
    companyId: v.id("companies"),

    // Usage tracking
    period: v.string(), // "2024-01" format
    aiResponses: v.number(), // Total AI messages sent this month

    // Usage breakdown by time
    dailyUsage: v.object({}), // { "2024-01-15": 25 }
    hourlyUsage: v.object({}), // { "2024-01-15-14": 3 }

    // Metadata
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_company_period", ["companyId", "period"])
    .index("by_period", ["period"]),

  // ============================================================================
  // FILES - Chat attachments (images)
  // ============================================================================
  files: defineTable({
    // Relationships
    companyId: v.id("companies"),
    uploadedBy: v.id("users"),
    conversationId: v.optional(v.id("conversations")),

    // File info
    fileName: v.string(),
    fileSize: v.number(),
    mimeType: v.string(),
    fileUrl: v.string(), // UploadThing URL

    // File restrictions
    fileType: v.literal("image"), // Only images for Elite plan
    maxSize: v.number(), // 2MB limit

    // Processing status
    status: v.union(
      v.literal("uploading"),
      v.literal("processing"),
      v.literal("completed"),
      v.literal("failed")
    ),
    processedText: v.optional(v.string()),
    processingError: v.optional(v.string()),

    // AI analysis results
    aiAnalysis: v.optional(
      v.object({
        description: v.optional(v.string()),
        extractedText: v.optional(v.string()),
        confidence: v.optional(v.number()),
      })
    ),

    // Metadata
    uploadedAt: v.number(),
    processedAt: v.optional(v.number()),
    expiresAt: v.optional(v.number()),
  })
    .index("by_company", ["companyId"])
    .index("by_uploader", ["uploadedBy"])
    .index("by_status", ["status"])
    .index("by_conversation", ["conversationId"]),

  // ============================================================================
  // COMPANY CONTEXT FILES - Company knowledge base documents
  // ============================================================================
  company_context_files: defineTable({
    // Relationships
    companyId: v.id("companies"),
    uploadedBy: v.id("users"),

    // File info
    fileName: v.string(),
    fileSize: v.number(),
    mimeType: v.string(),
    fileUrl: v.string(), // UploadThing URL
    fileKey: v.string(), // UploadThing key (for deletion)

    // Metadata
    uploadedAt: v.number(),
  })
    .index("by_company", ["companyId"])
    .index("by_uploader", ["uploadedBy"]),

  // ============================================================================
  // PRESENCE - Real-time typing indicators
  // ============================================================================
  presence: defineTable({
    // Relationships
    userId: v.id("users"),
    companyId: v.id("companies"),

    // User role for context
    userRole: v.union(
      v.literal("customer"),
      v.literal("support"),
      v.literal("admin")
    ),

    // Typing indicators
    isTyping: v.boolean(),
    typingInConversation: v.optional(v.id("conversations")),
    typingStartedAt: v.optional(v.number()),

    // NEW: Viewing tracking
    viewingConversation: v.optional(v.id("conversations")),

    // Metadata
    heartbeatAt: v.number(),
    expiresAt: v.number(), // Auto-cleanup stale records
  })
    .index("by_user", ["userId"])
    .index("by_company", ["companyId"])
    .index("by_conversation", ["typingInConversation"])
    .index("by_viewing", ["viewingConversation"]) // NEW index
    .index("by_expires", ["expiresAt"]),

  // ============================================================================
  // BILLING EVENTS - Payment & subscription history
  // ============================================================================
  billing_events: defineTable({
    companyId: v.id("companies"),

    // Event type
    eventType: v.union(
      v.literal("payment_succeeded"),
      v.literal("subscription_cancelled")
    ),

    // Whop data
    whopPaymentId: v.optional(v.string()),
    whopMembershipId: v.string(),
    whopUserId: v.string(),
    whopPlanId: v.string(),

    // Financial (in USD, not cents!)
    amount: v.optional(v.number()),
    currency: v.optional(v.string()),

    // Plan changes
    newPlanId: v.id("plans"),

    // Raw webhook data for debugging
    rawData: v.optional(v.any()),

    // Metadata
    createdAt: v.number(),
  })
    .index("by_company", ["companyId"])
    .index("by_whop_membership", ["whopMembershipId"])
    .index("by_created_at", ["createdAt"]),

  // ============================================================================
  // USAGE RECORDS - Aggregated usage stats for insights
  // ============================================================================
  usage_records: defineTable({
    companyId: v.id("companies"),

    // Period (hourly or daily aggregates)
    period: v.union(v.literal("hourly"), v.literal("daily")),
    periodStart: v.number(), // Unix timestamp
    periodEnd: v.number(), // Unix timestamp

    // Metrics
    aiResponseCount: v.number(), // AI messages sent
    customerMessageCount: v.number(), // Customer messages
    agentMessageCount: v.number(), // Agent messages
    conversationCount: v.number(), // Active conversations
    handoffCount: v.number(), // AI → Support Staff handoffs

    // Timestamps
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_company_period", ["companyId", "period", "periodStart"])
    .index("by_period_start", ["periodStart"]),
});
