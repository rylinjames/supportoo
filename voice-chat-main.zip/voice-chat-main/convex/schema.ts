import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  companies: defineTable({
    whopCompanyId: v.string(), // Whop company ID
    whopExperienceId: v.string(), // Whop experience ID
    name: v.string(),
    owner: v.id("users"), // Company owner (Whop user)
    isActive: v.boolean(),
    // Pricing & billing (tiers and minutes)
    planTier: v.optional(v.id("plans")), // Reference to plans table
    planOwner: v.optional(v.string()), // Whop user ID of the admin who can make plan changes
    minutesUsedThisMonth: v.optional(v.number()), // Accrued participant-minutes (resets monthly)
    planRenewsAt: v.optional(v.number()), // UTC ms timestamp for next renewal boundary
    isRollingOver: v.optional(v.boolean()), // Lock for monthly rollover coordination
    billingProvider: v.optional(
      v.union(v.literal("whop"), v.literal("stripe"), v.literal("manual"))
    ),
    billingRef: v.optional(v.string()), // External subscription id/reference
    allowMembersToCreateLounges: v.optional(v.boolean()), // Admin-controlled toggle (Starter+)
    // Billing & subscription management
    whopMembershipId: v.optional(v.string()), // Active Whop membership ID
    billingStatus: v.optional(
      v.union(v.literal("active"), v.literal("canceled"))
    ), // Subscription status
    scheduledPlanChangeAt: v.optional(v.number()), // Timestamp when scheduled downgrade should execute
    scheduledPlanId: v.optional(v.id("plans")), // Plan ID to downgrade to (usually free)
    currentPeriodStart: v.optional(v.number()), // Start of current billing period
    currentPeriodEnd: v.optional(v.number()), // End of current billing period

    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_whop_company_id", ["whopCompanyId"])
    .index("by_whop_experience_id", ["whopExperienceId"])
    .index("by_owner", ["owner"])
    .index("by_active", ["isActive"])
    .index("by_plan_tier", ["planTier"])
    .index("by_plan_owner", ["planOwner"]),

  users: defineTable({
    whopUserId: v.string(), // Whop user ID
    whopUsername: v.string(), // Whop username
    fullName: v.string(), // Combined first + last name
    avatarUrl: v.optional(v.string()),
    isAnonymous: v.optional(v.boolean()), // Anonymous mode for listeners
    isActive: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.number(),
    // User browsing history
    registeredRooms: v.optional(v.array(v.id("rooms"))), // Rooms user has joined/created (persistent)
  })
    .index("by_whop_user_id", ["whopUserId"])
    .index("by_whop_username", ["whopUsername"])
    .index("by_active", ["isActive"]),

  experienceMappings: defineTable({
    whopExperienceId: v.string(),
    companyId: v.id("companies"),
    createdAt: v.number(),
  })
    .index("by_experience", ["whopExperienceId"])
    .index("by_company", ["companyId"]),

  rooms: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    maxParticipants: v.optional(v.number()), // Optional, default set in mutation
    maxSpeakers: v.optional(v.number()), // Optional, default set in mutation
    isActive: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.number(),
    companyId: v.id("companies"),
    creatorId: v.id("users"), // Renamed from createdBy
    bannedUsers: v.optional(v.array(v.id("users"))),
    // Discover page metadata
    category: v.optional(v.string()), // "gaming", "business", "social", etc.
    tags: v.optional(v.array(v.string())), // ["esports", "casual", "professional"]
    isPublic: v.optional(v.boolean()), // Whether room appears in discover
    roomImage: v.optional(v.string()), // Custom room image URL
    featured: v.optional(v.boolean()), // Featured rooms for discover page
    discoverListed: v.optional(v.boolean()), // Listed on Discover page
    participantCount: v.optional(v.number()), // Current participant count
    maxParticipantsEverReached: v.optional(v.number()), // Peak participant count for popularity
    lastActivityAt: v.optional(v.number()), // Last activity timestamp
    // Multi-lounge support
    roomCodeHash: v.optional(v.string()), // Hashed room code for private lounges
    allowedUsers: v.optional(v.array(v.string())), // Allowed Whop usernames
    // Temporary vs permanent rooms
    isTemporary: v.optional(v.boolean()), // Optional for existing rooms, default true for new rooms
    // Room shutdown tracking
    shutdownReason: v.optional(v.string()), // Reason for room shutdown (e.g., "minutes_exhausted")
    shutdownAt: v.optional(v.number()), // Timestamp when room was shutdown
    // Screen sharing state
    screenShareActive: v.optional(v.boolean()), // Is screen sharing currently active
    currentPresenter: v.optional(v.id("users")), // Who is currently presenting
    screenShareStartedAt: v.optional(v.number()), // When screen sharing started
    // Auto speakers configuration
    autoSpeakersEnabled: v.optional(v.boolean()), // Auto-promote joiners to speaker role (muted)
  })
    .index("by_company", ["companyId"])
    .index("by_active", ["isActive"])
    .index("by_company_and_active", ["companyId", "isActive"])
    .index("by_created_at", ["createdAt"])
    // Discover page indexes
    .index("by_category", ["category"])
    .index("by_public", ["isPublic"])
    .index("by_featured", ["featured"])
    .index("by_company_and_discover", ["companyId", "discoverListed"])
    .index("by_public_and_active", ["isPublic", "isActive"])
    .index("by_category_and_public", ["category", "isPublic"])
    // Multi-lounge indexes
    .index("by_creator", ["creatorId"])
    .index("by_creator_and_active", ["creatorId", "isActive"])
    // Screen sharing indexes
    .index("by_screen_share_active", ["screenShareActive"]),

  reactions: defineTable({
    roomId: v.id("rooms"),
    userId: v.id("users"),
    emoji: v.string(),
    createdAt: v.number(),
    expiresAt: v.number(), // When the reaction should auto-clear
  })
    .index("by_room", ["roomId"])
    .index("by_user", ["userId"])
    .index("by_expires", ["expiresAt"]),

  reactionHistory: defineTable({
    roomId: v.id("rooms"),
    userId: v.id("users"),
    emoji: v.string(),
    createdAt: v.number(),
    expiresAt: v.number(), // For rate limiting cleanup
  })
    .index("by_user", ["userId"])
    .index("by_room", ["roomId"])
    .index("by_expires", ["expiresAt"]),

  participants: defineTable({
    roomId: v.id("rooms"),
    userId: v.id("users"),
    role: v.union(
      v.literal("speaker"),
      v.literal("listener"),
      v.literal("moderator")
    ),
    isSpeaking: v.boolean(),
    isMuted: v.boolean(),
    joinedAt: v.number(),
    leftAt: v.optional(v.number()),
    // Multi-lounge support
    isCreator: v.boolean(), // Is this user the creator of the lounge
    // LiveKit webhook support
    liveKitIdentity: v.optional(v.string()), // LiveKit participant identity
    // Real-time billing tracking
    billingStartedAt: v.optional(v.number()), // When billing timer started
    lastBilledAt: v.optional(v.number()), // Last time participant was charged
    billingStoppedAt: v.optional(v.number()), // When billing timer stopped
    finalChargeMinutes: v.optional(v.number()), // Final charge amount when leaving
  })
    .index("by_room", ["roomId"])
    .index("by_room_and_livekit_identity", ["roomId", "liveKitIdentity"])
    .index("by_user", ["userId"])
    .index("by_room_and_user", ["roomId", "userId"])
    .index("by_speaking", ["isSpeaking"]),

  loungeEvents: defineTable({
    roomId: v.id("rooms"),
    eventType: v.union(
      v.literal("user_joined"),
      v.literal("user_left"),
      v.literal("speak_request"),
      v.literal("user_kicked"),
      v.literal("user_banned"),
      v.literal("role_promoted"),
      v.literal("role_demoted"),
      v.literal("room_renamed"),
      v.literal("lounge_started"),
      v.literal("room_code_updated"),
      v.literal("minute_warning"),
      v.literal("screen_share_started"),
      v.literal("screen_share_stopped"),
      v.literal("participant_muted"),
      v.literal("participant_unmuted"),
      v.literal("all_speakers_muted")
    ),
    userId: v.optional(v.id("users")), // User who performed the action
    targetUserId: v.optional(v.id("users")), // User who was affected (kicked, banned, etc.)
    actorUserId: v.optional(v.id("users")), // User who performed the action (moderator actions)
    eventData: v.object({
      userName: v.optional(v.string()),
      targetUserName: v.optional(v.string()),
      actorUserName: v.optional(v.string()),
      oldRole: v.optional(v.string()),
      newRole: v.optional(v.string()),
      oldRoomName: v.optional(v.string()),
      newRoomName: v.optional(v.string()),
      moderatorName: v.optional(v.string()),
      participantId: v.optional(v.string()),
      warningLevel: v.optional(v.string()), // "10_minutes", "5_minutes", "1_minute"
      minutesRemaining: v.optional(v.number()),
    }),
    createdAt: v.number(),
  })
    .index("by_room_and_time", ["roomId", "createdAt"]) // Primary query index for infinite scroll
    .index("by_room", ["roomId"]) // For room cleanup
    .index("by_time", ["createdAt"]), // For general time-based queries

  // Invitations for private lounges
  invitations: defineTable({
    roomId: v.id("rooms"),
    inviterId: v.id("users"),
    inviteeWhopUsername: v.string(),
    status: v.union(
      v.literal("pending"),
      v.literal("accepted"),
      v.literal("declined"),
      v.literal("revoked")
    ),
    createdAt: v.number(),
    expiresAt: v.optional(v.number()),
  })
    .index("by_invitee", ["inviteeWhopUsername"]) // List invites for a whop user
    .index("by_room", ["roomId"]) // Room-level management
    .index("by_inviter", ["inviterId"]) // Who invited
    .index("by_room_and_invitee", ["roomId", "inviteeWhopUsername"]),

  // Minute packs / credits purchased by a company
  companyMinuteCredits: defineTable({
    companyId: v.id("companies"),
    minutes: v.number(), // original minutes granted by this credit
    remainingMinutes: v.number(), // remaining minutes for this credit
    source: v.union(
      v.literal("pack"),
      v.literal("promo"),
      v.literal("plan_adjustment")
    ),
    receiptRef: v.optional(v.string()), // provider receipt/charge id
    purchasedAt: v.number(), // ms since epoch (UTC)
    expiresAt: v.optional(v.number()), // null => never expires
  })
    .index("by_company", ["companyId"])
    .index("by_expires", ["expiresAt"])
    .index("by_receipt_ref", ["receiptRef"]),

  // Monthly usage aggregates + plan snapshot for reporting/reconciliation
  companyUsageMonthly: defineTable({
    companyId: v.id("companies"),
    yearMonth: v.string(), // 'YYYY-MM'
    totalMinutes: v.number(), // accumulated participant-minutes
    includedMinutesAtStart: v.number(), // snapshot of included at cycle start
    planTierAtStart: v.union(
      v.literal("free"),
      v.literal("starter"),
      v.literal("pro"),
      v.literal("creator")
    ),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_company_and_month", ["companyId", "yearMonth"])
    .index("by_month", ["yearMonth"]),

  // Billing receipts mirror (audit & reconciliation; provider = Whop for now)
  billingReceipts: defineTable({
    companyId: v.id("companies"),
    provider: v.literal("whop"),
    receiptId: v.string(),
    billingReason: v.union(
      v.literal("manual"),
      v.literal("one_time"),
      v.literal("subscription"),
      v.literal("subscription_create"),
      v.literal("subscription_cycle"),
      v.literal("subscription_update")
    ),
    status: v.union(
      v.literal("failed"),
      v.literal("partially_refunded"),
      v.literal("past_due"),
      v.literal("refunded"),
      v.literal("succeeded")
    ),
    amountUsd: v.number(),
    currency: v.string(),
    planId: v.optional(v.string()), // provider plan id when applicable
    packId: v.optional(v.string()), // our pack catalog id when applicable
    creditId: v.optional(v.id("companyMinuteCredits")),
    paidAt: v.optional(v.number()),
    rawPayload: v.optional(v.string()), // JSON string of provider payload
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_company", ["companyId"])
    .index("by_receipt", ["receiptId"])
    .index("by_paid_at", ["paidAt"]),

  // Centralized plan management
  plans: defineTable({
    tier: v.union(
      v.literal("free"),
      v.literal("starter"),
      v.literal("pro"),
      v.literal("creator")
    ),
    name: v.string(),
    description: v.string(),
    priceUsd: v.number(),
    includedMinutes: v.number(),
    maxSavedLounges: v.optional(v.number()),
    features: v.array(v.string()),
    whopPlanId: v.optional(v.string()), // Whop checkout plan ID
    whopCheckoutUrl: v.optional(v.string()),
    isActive: v.boolean(),
    sortOrder: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_tier", ["tier"])
    .index("by_active", ["isActive"])
    .index("by_sort_order", ["sortOrder"])
    .index("by_whop_plan_id", ["whopPlanId"]),

  minutePacks: defineTable({
    name: v.string(),
    minutes: v.number(),
    priceUsd: v.number(),
    whopPlanId: v.string(), // Whop checkout plan ID
    whopCheckoutUrl: v.string(),
    isActive: v.boolean(),
    sortOrder: v.number(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_active", ["isActive"])
    .index("by_sort_order", ["sortOrder"])
    .index("by_whop_plan_id", ["whopPlanId"]),

  // Billing events for audit trail
  billing_events: defineTable({
    companyId: v.id("companies"),
    eventType: v.union(
      v.literal("payment_succeeded"),
      v.literal("subscription_cancelled")
    ),
    whopPaymentId: v.optional(v.string()),
    whopMembershipId: v.string(),
    whopUserId: v.string(),
    whopPlanId: v.string(),
    amount: v.optional(v.number()),
    currency: v.optional(v.string()),
    newPlanId: v.id("plans"),
    rawData: v.optional(v.any()), // Full webhook payload for debugging
    createdAt: v.number(),
  }).index("by_company", ["companyId"]),
});
