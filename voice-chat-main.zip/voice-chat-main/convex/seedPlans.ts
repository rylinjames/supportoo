import { mutation } from "./_generated/server";

// Mutation to seed plans and minutePacks tables - call from Convex dashboard
export const seedPlansAndPacks = mutation({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();

    console.log("🌱 Starting to seed plans and minute packs...");

    // Check if plans already exist
    const existingPlans = await ctx.db.query("plans").collect();
    if (existingPlans.length > 0) {
      console.log(
        `⚠️  Found ${existingPlans.length} existing plans. Skipping plan seeding.`
      );
    } else {
      // Seed plans
      const plans = [
        {
          tier: "free" as const,
          name: "Free Tier",
          description: "Perfect for getting a feel",
          priceUsd: 0,
          includedMinutes: 200,
          maxSavedLounges: 1,
          features: ["1 lounge maximum", "Only 200 minutes per month"],
          whopPlanId: "plan_QiT7NH0OuiAxn",
          whopCheckoutUrl:
            "https://whop.com/checkout/plan_QiT7NH0OuiAxn?d2c=true",
          sortOrder: 0,
        },
        {
          tier: "starter" as const,
          name: "Starter Tier",
          description: "Great for small communities",
          priceUsd: 15,
          includedMinutes: 10_000,
          maxSavedLounges: 3,
          features: [
            "3 lounges maximum",
            "10,000 minutes per month",
            "Priority Support",
            "Analytics",
          ],
          whopPlanId: "plan_MpQr5TOBXDXlH",
          whopCheckoutUrl:
            "https://whop.com/checkout/plan_MpQr5TOBXDXlH?d2c=true",
          sortOrder: 1,
        },
        {
          tier: "pro" as const,
          name: "Pro Tier",
          description: "For growing communities",
          priceUsd: 39,
          includedMinutes: 50_000,
          maxSavedLounges: undefined,
          features: [
            "Unlimited lounges",
            "50,000 minutes per month",
            "Lounge Chat",
            "Priority support",
            "Analytics",
          ],
          whopPlanId: "plan_Ii7qcB4uAndV5",
          whopCheckoutUrl:
            "https://whop.com/checkout/plan_Ii7qcB4uAndV5?d2c=true",
          sortOrder: 2,
        },
        {
          tier: "creator" as const,
          name: "Creator Tier",
          description: "Maximum visibility and features",
          priceUsd: 99,
          includedMinutes: 150_000,
          maxSavedLounges: undefined,
          features: [
            "Unlimited lounges",
            "150,000 minutes per month",
            "Showcase lounges on Explore Page",
            "Lounge Chat",
            "Priority Support",
            "Analytics",
          ],
          whopPlanId: "plan_Ki2ZjNEWauJbH",
          whopCheckoutUrl:
            "https://whop.com/checkout/plan_Ki2ZjNEWauJbH?d2c=true",
          sortOrder: 3,
        },
      ];

      // Insert plans
      for (const plan of plans) {
        await ctx.db.insert("plans", {
          ...plan,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        });
      }

      console.log(`✅ Seeded ${plans.length} plans`);
    }

    // Check if minute packs already exist
    const existingPacks = await ctx.db.query("minutePacks").collect();
    if (existingPacks.length > 0) {
      console.log(
        `⚠️  Found ${existingPacks.length} existing minute packs. Skipping pack seeding.`
      );
    } else {
      // Seed minute packs
      const minutePacks = [
        {
          name: "20k minutes",
          minutes: 20_000,
          priceUsd: 10,
          whopPlanId: "plan_CmumhNcVdm2cR",
          whopCheckoutUrl:
            "https://whop.com/checkout/plan_CmumhNcVdm2cR?d2c=true",
          sortOrder: 0,
        },
        {
          name: "60k minutes",
          minutes: 60_000,
          priceUsd: 25,
          whopPlanId: "plan_zrsjPXVLCx8d9",
          whopCheckoutUrl:
            "https://whop.com/checkout/plan_zrsjPXVLCx8d9?d2c=true",
          sortOrder: 1,
        },
        {
          name: "150k minutes",
          minutes: 150_000,
          priceUsd: 50,
          whopPlanId: "plan_iyod9NLYz14Sr",
          whopCheckoutUrl:
            "https://whop.com/checkout/plan_iyod9NLYz14Sr?d2c=true",
          sortOrder: 2,
        },
      ];

      // Insert minute packs
      for (const pack of minutePacks) {
        await ctx.db.insert("minutePacks", {
          ...pack,
          isActive: true,
          createdAt: now,
          updatedAt: now,
        });
      }

      console.log(`✅ Seeded ${minutePacks.length} minute packs`);
    }

    const finalPlansCount = await ctx.db.query("plans").collect();
    const finalPacksCount = await ctx.db.query("minutePacks").collect();

    // Update existing companies to reference plan IDs instead of string literals
    const companies = await ctx.db.query("companies").collect();
    let companiesUpdated = 0;

    for (const company of companies) {
      // Check if planTier is a string (old format) or undefined
      if (company.planTier && typeof company.planTier === "string") {
        // Find the plan by tier name
        const plan = await ctx.db
          .query("plans")
          .withIndex("by_tier", (q) =>
            q.eq(
              "tier",
              company.planTier as "free" | "starter" | "pro" | "creator"
            )
          )
          .filter((q) => q.eq(q.field("isActive"), true))
          .first();

        if (plan) {
          await ctx.db.patch(company._id, {
            planTier: plan._id, // Update to reference plan ID
            updatedAt: now,
          });
          companiesUpdated++;
        }
      } else if (!company.planTier) {
        // Set to free plan ID if no plan tier set
        const freePlan = await ctx.db
          .query("plans")
          .withIndex("by_tier", (q) => q.eq("tier", "free"))
          .filter((q) => q.eq(q.field("isActive"), true))
          .first();

        if (freePlan) {
          await ctx.db.patch(company._id, {
            planTier: freePlan._id, // Set to free plan ID
            updatedAt: now,
          });
          companiesUpdated++;
        }
      }
      // If planTier is already an ID, skip it
    }

    console.log("🎉 Seeding complete!");
    console.log(
      `📊 Updated ${companiesUpdated} companies to reference plan IDs`
    );

    return {
      success: true,
      plansCount: finalPlansCount.length,
      packsCount: finalPacksCount.length,
      companiesUpdated,
      message:
        "Plans, minute packs, and company references updated successfully!",
    };
  },
});
