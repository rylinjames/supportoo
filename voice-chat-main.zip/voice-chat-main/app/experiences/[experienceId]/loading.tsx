import LoadingScreen from "@/app/components/shared/loading-screen";

export default function ExperienceLoading() {
  return <LoadingScreen />;
}
