"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Button } from "@/components/ui/button";
import { RefreshCw, Mic } from "lucide-react";
import { AnimatedDots } from "./ui/animated-dots";
import Link from "next/link";

type SetupState = "loading" | "creating" | "error" | "success";

interface WhopVoiceSetupProps {
  whopUserId: string;
  whopUsername: string;
  fullName: string;
  avatarUrl?: string;
  whopCompanyId: string;
  whopExperienceId: string;
  companyName: string;
  whopAccessLevel: "admin" | "customer" | "no_access";
}

export function WhopVoiceSetup({
  whopUserId,
  whopUsername,
  fullName,
  avatarUrl,
  whopCompanyId,
  whopExperienceId,
  companyName,
  whopAccessLevel,
}: WhopVoiceSetupProps) {
  const router = useRouter();
  const [setupState, setSetupState] = useState<SetupState>("loading");
  const [error, setError] = useState<string | null>(null);
  const hasProcessed = useRef(false);

  const createRoomMutation = useMutation(api.rooms.createRoom);
  const joinRoomMutation = useMutation(api.participants.joinRoom);
  const reactivateRoomMutation = useMutation(api.rooms.reactivateRoom);
  const updateParticipantRoleMutation = useMutation(
    api.participants.updateParticipantRole
  );
  const syncUserMutation = useMutation(api.whopSync.syncWhopUser);
  const syncCompanyMutation = useMutation(api.whopSync.syncWhopCompany);

  // Sync Whop data to Convex first
  useEffect(() => {
    const syncWhopData = async () => {
      try {
        // Sync user first
        const userId = await syncUserMutation({
          whopUserId,
          whopUsername,
          fullName,
          avatarUrl,
        });

        if (!userId) {
          throw new Error("Failed to sync user");
        }

        // Then sync company
        await syncCompanyMutation({
          whopCompanyId,
          whopExperienceId,
          name: companyName,
          ownerUserId: userId,
        });
      } catch (error) {
        console.error("❌ Failed to sync Whop data:", error);
        setError("Failed to sync user data. Please try again.");
        setSetupState("error");
      }
    };

    // Sync data immediately when component loads
    syncWhopData();
  }, [
    whopUserId,
    whopUsername,
    fullName,
    whopCompanyId,
    whopExperienceId,
    companyName,
    syncUserMutation,
    syncCompanyMutation,
  ]);

  // Get user data from Convex (synced from Whop)
  const userData = useQuery(api.users.getUserByWhopId, {
    whopUserId,
  });

  // Get company by Whop company ID
  const company = useQuery(api.companies.getCompanyByWhopId, {
    whopCompanyId,
  });

  // Get active room for this company
  const activeRoom = useQuery(
    api.rooms.getActiveRoomForCompany,
    company?._id ? { companyId: company._id } : "skip"
  );

  // Get any room (active or inactive) for this company
  const anyRoom = useQuery(
    api.rooms.getAnyRoomForCompany,
    company?._id ? { companyId: company._id } : "skip"
  );

  // Get participants to check if there's a moderator
  const participants = useQuery(
    api.participants.getParticipantsByRoom,
    activeRoom?._id ? { roomId: activeRoom._id } : "skip"
  );

  // Check if user is company owner (only if both company and user data are loaded)
  const isOwner = useQuery(
    api.companies.isCompanyOwner,
    company && userData
      ? {
          companyId: company._id,
          userId: userData._id,
        }
      : "skip"
  );

  useEffect(() => {
    // Skip if data is still loading
    if (!userData || !company) {
      return;
    }

    // CRITICAL: Wait for both room queries to finish loading
    // activeRoom and anyRoom can be null (no room) or an object (room exists)
    // but we need to wait for them to stop being "undefined" (still loading)
    if (activeRoom === undefined || anyRoom === undefined) {
      return;
    }

    // Check if user is banned from any room
    if (anyRoom && anyRoom.bannedUsers?.includes(userData._id)) {
      setError(
        "You have been banned from this lounge. Please contact the lounge owner to request access."
      );
      setSetupState("error");
      return;
    }

    // If there's an active room, join it
    if (activeRoom) {
      handleJoinExistingRoom();
    }
    // If there's an inactive room and user is admin, reactivate it
    else if (anyRoom && !anyRoom.isActive && whopAccessLevel === "admin") {
      handleReactivateLounge();
    }
    // If no room exists and user is admin, create new room
    else if (!anyRoom && !activeRoom && whopAccessLevel === "admin") {
      handleCreateLounge();
    }
    // If no room exists and user is not admin, show error
    else if (!anyRoom && !activeRoom && whopAccessLevel !== "admin") {
      setError(
        "No lounge exists for this company. Please contact an admin to create one."
      );
      setSetupState("error");
    }
  }, [userData, company, activeRoom, anyRoom, whopAccessLevel, participants]);

  const handleJoinExistingRoom = async () => {
    if (!userData || !activeRoom || !company) {
      return;
    }

    setSetupState("creating");
    setError(null);

    try {
      // Check if user is the room creator
      const isRoomCreator = activeRoom.creatorId === userData._id;

      const isBanned = activeRoom.bannedUsers?.includes(userData._id);

      if (isBanned) {
        setError(
          "You have been banned from this lounge. Please contact the lounge owner to request access."
        );
        setSetupState("error");
        return;
      }

      // Determine role based on Whop access level and room creation
      let userRole: "moderator" | "listener";
      if (whopAccessLevel === "admin" || isRoomCreator) {
        userRole = "moderator";
      } else {
        userRole = "listener";
      }

      // Join the existing room
      await joinRoomMutation({
        roomId: activeRoom._id,
        userId: userData._id,
        role: userRole,
      });

      setSetupState("success");

      // Redirect to the existing lounge with a longer delay to ensure data sync
      setTimeout(() => {
        router.push(
          `/experiences/${whopExperienceId}/lounge/${activeRoom._id}?whopUserId=${whopUserId}`
        );
      }, 2000);
    } catch (err) {
      console.error("❌ Error joining room:", err);
      setError("Failed to join lounge. Please try again.");
      setSetupState("error");
    }
  };

  const handleReactivateLounge = async () => {
    if (!userData || !company || !anyRoom) return;

    // Prevent double calls
    if (setupState === "creating") {
      return;
    }

    setSetupState("creating");
    setError(null);

    try {
      // Reactivate the existing room
      const reactivateResult = await reactivateRoomMutation({
        roomId: anyRoom._id,
        requesterId: userData._id,
      });

      // Check if reactivation failed due to insufficient minutes
      if (
        !reactivateResult.ok &&
        reactivateResult.reason === "minutes_exhausted"
      ) {
        setError(
          "Cannot reactivate lounge - your Whop has insufficient minutes remaining. Please upgrade your plan to continue."
        );
        setSetupState("error");
        return;
      }

      // Join the room first
      await joinRoomMutation({
        roomId: anyRoom._id,
        userId: userData._id,
      });

      // Then update role to moderator (company owner can be moderator when reactivating)
      await updateParticipantRoleMutation({
        roomId: anyRoom._id,
        userId: userData._id,
        role: "moderator",
      });

      setSetupState("success");

      // Redirect to the specific lounge with a longer delay to ensure data sync
      setTimeout(() => {
        router.push(
          `/experiences/${whopExperienceId}/lounge/${anyRoom._id}?whopUserId=${whopUserId}`
        );
      }, 2000);
    } catch (err) {
      setError("Failed to reactivate lounge. Please try again.");
      setSetupState("error");
    }
  };

  const handleCreateLounge = async () => {
    if (!userData || !company) {
      return;
    }

    // Prevent double calls
    if (setupState === "creating") {
      return;
    }

    setSetupState("creating");
    setError(null);

    try {
      // Create the room
      const roomId = await createRoomMutation({
        name: `${companyName} Lounge`,
        description: `${companyName} Lounge`,
        category: "other",
        isPublic: true,
        companyId: company._id,
        userId: userData._id,
      });

      // Join the room as moderator (room creator)
      await joinRoomMutation({
        roomId: roomId,
        userId: userData._id,
        role: "moderator",
      });

      setSetupState("success");

      // Redirect to the specific lounge with a longer delay to ensure data sync
      setTimeout(() => {
        router.push(
          `/experiences/${whopExperienceId}/lounge/${roomId}?whopUserId=${whopUserId}`
        );
      }, 2000);
    } catch (err) {
      console.error("❌ Error creating room:", err);
      const errorMessage =
        (err instanceof Error && err.message) || (err as any)?.message || "";
      const lowerError = String(errorMessage).toLowerCase();

      if (lowerError.includes("insufficient minutes")) {
        setError(
          "Your Whop has insufficient minutes to create a lounge. Please upgrade your plan to continue."
        );
      } else {
        setError("Failed to create lounge. Please try again.");
      }
      setSetupState("error");
    }
  };

  const getStatusMessage = () => {
    switch (setupState) {
      case "loading":
        return "Please wait while we sync you with the server";
      case "creating":
        if (activeRoom) {
          return "Joining existing lounge";
        } else if (anyRoom) {
          return "Reactivating lounge";
        } else {
          return "Setting up your lounge";
        }
      case "success":
        return "Lounge ready! Redirecting";
      case "error":
        return "Something went wrong. Please try again";
      default:
        return "Loading";
    }
  };

  return (
    <div className="flex items-center justify-center h-full p-8">
      <div className="text-center max-w-md">
        <div className="flex flex-col gap-2 justify-center items-center">
          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-primary flex items-center justify-center animate-pulse">
            <Mic className="h-16 w-16 text-white" />
          </div>
        </div>
        {setupState !== "error" && (
          <div className="flex items-center justify-center gap-2 mt-6">
            <AnimatedDots
              size="lg"
              className="text-neutral-600 dark:text-neutral-400"
            />
          </div>
        )}

        {/* Error State */}
        {setupState === "error" && (
          <div className="space-y-4 mt-6">
            <div className="p-4 text-sm text-red-600 bg-red-50 dark:bg-red-950 dark:text-red-400 rounded-md">
              {error}
            </div>
            <div className="flex gap-3 justify-center">
              <Button
                onClick={() => window.location.reload()}
                className="flex items-center gap-2"
              >
                <RefreshCw className="h-4 w-4" />
                Try Again
              </Button>
              <Button variant="outline" onClick={() => router.push("/")}>
                Go Back to Browse
              </Button>
            </div>
          </div>
        )}
      </div>
      <p className="text-sm text-neutral-600 dark:text-neutral-400 absolute bottom-4 left-1/2 -translate-x-1/2">
        powered by{" "}
        <Link
          className="text-black dark:text-white hover:underline"
          href="https://whop.com/joined/bookoo-apps-developers/"
        >
          Bookoo Apps
        </Link>
      </p>
    </div>
  );
}
