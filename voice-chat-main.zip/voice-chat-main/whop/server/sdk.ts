import { WhopServerSdk } from "@whop/api";
import { headers } from "next/headers";

// Initialize Whop SDK client
export const whopSdk = WhopServerSdk({
  appApiKey: process.env.WHOP_API_KEY!,
  appId: process.env.NEXT_PUBLIC_WHOP_APP_ID!,
});

// Verify user token and extract user ID
export async function verifyUserToken() {
  const headersList = await headers();

  try {
    const { userId } = await whopSdk.verifyUserToken(headersList);
    return { success: true, userId };
  } catch (error) {
    console.error("Failed to verify Whop user token:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// Get user information from Whop
export async function getUserInfo(userId: string) {
  try {
    const user = await whopSdk.users.getUser({ userId });
    return { success: true, user };
  } catch (error) {
    console.error("Failed to get user info:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// Check if user has access to experience and get their role
export async function getUserExperienceAccess(
  userId: string,
  experienceId: string
) {
  try {
    const access = await whopSdk.access.checkIfUserHasAccessToExperience({
      experienceId,
      userId,
    });
    return { success: true, access };
  } catch (error) {
    console.error("Failed to get user experience access:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// Check if user has access to company and get their role
export async function getUserCompanyAccess(userId: string, companyId: string) {
  try {
    const access = await whopSdk.access.checkIfUserHasAccessToCompany({
      companyId,
      userId,
    });
    return { success: true, access };
  } catch (error) {
    console.error("Failed to get user company access:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// Get experience information from Whop
export async function getExperienceInfo(experienceId: string) {
  try {
    const experience = await whopSdk.experiences.getExperience({
      experienceId,
    });
    return { success: true, experience };
  } catch (error) {
    console.error("Failed to get experience info:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// Get access pass for an experience to get company logo
export async function getAccessPassForExperience(experienceId: string) {
  try {
    const result = await whopSdk.experiences.listAccessPassesForExperience({
      experienceId,
    });

    // Get the first access pass (usually there's one per experience)
    const accessPass = result.accessPasses?.[0];

    if (accessPass) {
      return { success: true, accessPass };
    } else {
      return {
        success: false,
        error: "No access pass found for this experience",
      };
    }
  } catch (error) {
    console.error("Failed to get access pass for experience:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// fetch the company's logo
export async function getCompanyLogoForExperience(experienceId: string) {
  try {
    const experienceFound = await whopSdk.experiences.getExperience({
      experienceId,
    });
    const logoUrl = experienceFound?.logo?.sourceUrl;

    if (!logoUrl) {
      return { success: false, error: "No access pass found" } as const;
    }
    const companyLogo = logoUrl as string | undefined;
    return { success: true, companyLogo } as const;
  } catch (error) {
    console.error("Failed to get company logo for experience:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    } as const;
  }
}
