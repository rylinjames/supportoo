"use client";

import { useEffect, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Button } from "@/components/ui/button";
import { useSessionStore } from "@/stores/session-store";
import LoadingScreen from "@/app/components/shared/loading-screen";
import { Id } from "@/convex/_generated/dataModel";
import { EnrichedRoom } from "@/convex/browse";
import Navbar from "./components/navbar";
import { ChevronRightIcon } from "lucide-react";
import BrowseSection from "./components/browse-section";
import Footer from "./components/footer";
import LoungeCard from "./components/lounge-card";
import { useWhopSync } from "@/app/hooks/useWhopSync";
import { PromoDialog } from "@/app/components/promo/promo-dialog";
import { usePromoDisplay } from "@/app/hooks/use-promo-display";

type SyncState = "idle" | "syncing" | "success" | "error";

interface LoungeBrowseClientProps {
  whopUserId: string;
  whopUsername: string;
  fullName: string;
  avatarUrl?: string;
  whopCompanyId: string;
  whopExperienceId: string;
  companyName: string;
  companyLogo: string;
  whopAccessLevel: "admin" | "customer" | "no_access" | null;
}

export function LoungeBrowseClient(props: LoungeBrowseClientProps) {
  const [error, setError] = useState<string | null>(null);
  const [convexUserId, setConvexUserId] = useState<string | null>(null);

  const setSession = useSessionStore((s) => s.setSession);

  // After sync, read back Convex company by experience to capture Convex companyId
  const convexCompany = useQuery(api.whopSync.getCompanyByExperienceId, {
    whopExperienceId: props.whopExperienceId,
  });

  // Browse queries - only fetch after session is ready
  const {
    syncState,
    convexCompany: syncedCompany,
    convexUserId: uid,
  } = useWhopSync({
    whopUserId: props.whopUserId,
    whopUsername: props.whopUsername,
    fullName: props.fullName,
    avatarUrl: props.avatarUrl,
    whopCompanyId: props.whopCompanyId,
    whopExperienceId: props.whopExperienceId,
    whopAccessLevel: props.whopAccessLevel,
    companyName: props.companyName,
  });
  useEffect(() => {
    if (uid) setConvexUserId(uid as unknown as string);
  }, [uid]);

  const whopLounges:
    | { publicLounges: EnrichedRoom[]; privateLounges: EnrichedRoom[] }
    | undefined = useQuery(
    api.browse.getWhopLounges,
    convexUserId && convexCompany?._id && syncState === "success"
      ? {
          companyId: convexCompany._id as Id<"companies">,
          userId: convexUserId as Id<"users">,
          viewerWhopAccessLevel: props.whopAccessLevel || undefined,
          limit: 10,
        }
      : "skip"
  );

  // Promo system - check if user should see promo (admin-only)
  const promoData = useQuery(
    api.promos.getActivePromo,
    convexCompany?._id && convexUserId && syncState === "success"
      ? {
          companyId: convexCompany._id as Id<"companies">,
          userId: convexUserId as Id<"users">,
        }
      : "skip"
  );

  // Promo display logic
  const { shouldShow, handleMaybeLater, handleClose } = usePromoDisplay({
    enabled: !!promoData && syncState === "success",
    delayMs: 1500, // Show after 1.5 seconds
  });

  if (syncState === "idle" || syncState === "syncing") {
    return <LoadingScreen />;
  }

  if (syncState === "error") {
    return <LoadingScreen message={error} error={true} />;
  }

  return (
    <div className="min-h-screen w-full relative bg-white dark:bg-background pb-10">
      <Navbar
        whopExperienceId={props.whopExperienceId}
        syncState={syncState}
        convexUserId={convexUserId || undefined}
        whopUsername={props.whopUsername}
        whopUserId={props.whopUserId}
        whopCompanyId={props.whopCompanyId}
        companyName={props.companyName}
      />

      <div className="max-w-[1500px] mx-auto px-4 pt-24 pb-8">
        {/* Row 1: Public Lounges in Company */}
        <BrowseSection
          title={`Public Lounges`}
          noLoungeText="No public lounges found in your Whop"
          lounges={whopLounges?.publicLounges}
          isLoading={syncState === "success" && whopLounges === undefined}
        />
        {/* Row 2: Private Lounges in Company */}
        <BrowseSection
          title={`Private Lounges`}
          noLoungeText="No private lounges found in your Whop"
          lounges={whopLounges?.privateLounges}
          isLoading={syncState === "success" && whopLounges === undefined}
        />
      </div>
      <Footer />

      {/* Promo Dialog */}
      {promoData && (
        <PromoDialog
          isOpen={shouldShow}
          onClose={handleClose}
          onMaybeLater={handleMaybeLater}
          promo={promoData}
          experienceId={props.whopExperienceId}
        />
      )}
    </div>
  );
}
