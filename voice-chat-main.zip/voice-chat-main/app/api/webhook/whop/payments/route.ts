import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";

// Webhook signature verification
const verifyWebhookSignature = (
  payload: string,
  signature: string,
  secret: string,
  toleranceSeconds: number = 300 // 5 minutes
): { isValid: boolean; error?: string } => {
  try {
    // Parse signature header: "t=timestamp,v1=signature"
    const parts = signature.split(",");
    const timestampPart = parts.find((p) => p.startsWith("t="));
    const signaturePart = parts.find((p) => p.startsWith("v1="));

    if (!timestampPart || !signaturePart) {
      return { isValid: false, error: "Invalid signature format" };
    }

    const timestamp = parseInt(timestampPart.split("=")[1]);
    const receivedSignature = signaturePart.split("=")[1];

    // Check timestamp (prevent replay attacks)
    const now = Math.floor(Date.now() / 1000);
    if (Math.abs(now - timestamp) > toleranceSeconds) {
      return { isValid: false, error: "Webhook timestamp too old" };
    }

    // Create expected signature
    const expectedSignature = crypto
      .createHmac("sha256", secret)
      .update(`${timestamp}.${payload}`)
      .digest("hex");

    // Compare signatures (timing-safe)
    const isValid = crypto.timingSafeEqual(
      Buffer.from(expectedSignature, "hex"),
      Buffer.from(receivedSignature, "hex")
    );
    return { isValid };
  } catch (error) {
    return { isValid: false, error: "Signature verification failed" };
  }
};

// Event router (stripped). Only logs when amount > 0 for payment.succeeded.
const routeWebhookEvent = async (event: any) => {
  try {
    const action = event?.action as string | undefined;
    const data = event?.data ?? {};

    if (action === "payment.succeeded") {
      const amount = Number(data?.subtotal ?? 0);
      if (amount > 0) {
        console.log("💰 Payment succeeded:", data.id, `($${amount})`);
      }
    }

    // app_membership_went_invalid: no logging here (handled in Convex)
    return { success: true, action, processed: true };
  } catch (error) {
    console.error("❌ Error in routeWebhookEvent:", error);
    return {
      success: false,
      action: event?.action,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
};

export async function POST(request: NextRequest) {
  try {
    // Webhook received

    // Get webhook secret from environment (use dev secret in development)
    const webhookSecret =
      process.env.NODE_ENV === "development"
        ? process.env.WHOP_DEV_WEBHOOK_SECRET
        : process.env.WHOP_WEBHOOK_SECRET;

    if (!webhookSecret) {
      const envType =
        process.env.NODE_ENV === "development"
          ? "WHOP_DEV_WEBHOOK_SECRET"
          : "WHOP_WEBHOOK_SECRET";
      console.error(`❌ ${envType} not configured`);
      return NextResponse.json(
        { error: "Webhook secret not configured" },
        { status: 500 }
      );
    }

    // Get request body and signature
    const body = await request.text();

    // Debug: Log all headers in development to diagnose missing signature
    if (process.env.NODE_ENV === "development") {
      const allHeaders: Record<string, string> = {};
      request.headers.forEach((value, key) => {
        // Sanitize sensitive headers for logging
        if (
          key.toLowerCase().includes("signature") ||
          key.toLowerCase().includes("authorization")
        ) {
          allHeaders[key] = value ? `${value.substring(0, 20)}...` : "(empty)";
        } else {
          allHeaders[key] = value;
        }
      });
      console.log("🔍 Received headers:", JSON.stringify(allHeaders, null, 2));
    }

    // Try standard header name (Next.js headers.get() is case-insensitive)
    let signature: string | null = request.headers.get("x-whop-signature");

    // Fallback: search for any header containing "whop" and "signature"
    // This helps catch cases where the header name might differ slightly
    if (!signature) {
      request.headers.forEach((value, key) => {
        const lowerKey = key.toLowerCase();
        if (lowerKey.includes("whop") && lowerKey.includes("signature")) {
          signature = value;
          if (process.env.NODE_ENV === "development") {
            console.log(`✅ Found signature header via search: ${key}`);
          }
        }
      });
    }

    if (!signature) {
      console.error("❌ Missing x-whop-signature header");
      const errorResponse: { error: string; debug?: any } = {
        error: "Missing signature header",
      };

      // Include debug info in development
      if (process.env.NODE_ENV === "development") {
        const headerNames: string[] = [];
        request.headers.forEach((_, key) => {
          headerNames.push(key);
        });
        errorResponse.debug = {
          receivedHeaders: headerNames,
          message:
            "Check if Whop is sending the header with a different name or if it's being stripped by middleware",
        };
      }

      return NextResponse.json(errorResponse, { status: 401 });
    }

    // Minimal logging; avoid echoing payload/signature

    // Verify webhook signature
    const verification = verifyWebhookSignature(body, signature, webhookSecret);
    if (!verification.isValid) {
      console.error("❌ Invalid webhook signature:", verification.error);
      const errorResponse: { error: string; details?: string; debug?: any } = {
        error: "Invalid signature",
      };

      if (verification.error) {
        errorResponse.details = verification.error;
      }

      // Include debug info in development
      if (process.env.NODE_ENV === "development") {
        errorResponse.debug = {
          signatureHeader: signature
            ? `${signature.substring(0, 30)}...`
            : "missing",
          error: verification.error,
          message:
            "Check if webhook secret matches Whop dashboard configuration",
        };
      }

      return NextResponse.json(errorResponse, { status: 401 });
    }

    // Signature verified

    // Parse webhook payload
    let event;
    try {
      event = JSON.parse(body);
      console.log("🔄 Webhook received:", event);
    } catch (error) {
      console.error("❌ Failed to parse webhook JSON:", error);
      return NextResponse.json(
        { error: "Invalid JSON payload" },
        { status: 400 }
      );
    }

    // Minimal filtering: only handle events we care about
    const action = event?.action;
    const data = event?.data ?? {};

    // Only process app_membership_went_invalid and payment.succeeded
    const isPayment = action === "payment.succeeded";
    const isAppInvalidation = action === "app_membership_went_invalid";
    if (!isPayment && !isAppInvalidation) {
      return NextResponse.json(
        { success: true, ignored: true },
        { status: 401 }
      );
    }

    // For payments: skip zero or missing subtotal (noise)
    if (isPayment) {
      const subtotal = Number(data?.subtotal ?? 0);
      if (!(subtotal > 0)) {
        return NextResponse.json(
          { success: true, ignored: true, reason: "zero_subtotal" },
          { status: 200 }
        );
      }
    }

    // For successful payment events (amount > 0), log the entire event once for audit
    if (isPayment) {
      const amount = Number(data?.final_amount ?? data?.subtotal ?? 0);
      if (amount > 0) {
        try {
          console.log(
            "🧾 Whop payment.succeeded event (audit)",
            JSON.stringify(event)
          );
        } catch {}
      }
    }

    // Route and process the webhook event (log-only router)
    const result = await routeWebhookEvent(event);

    // Forward to Convex for durable idempotent processing of core events
    try {
      console.log("🔄 Forwarding to Convex");
      // Lazy import to avoid edge/runtime pitfalls
      const { ConvexHttpClient } = await import("convex/browser");
      const apiModule = await import("@/convex/_generated/api");
      const convex = new ConvexHttpClient(process.env.NEXT_PUBLIC_CONVEX_URL!);

      const eventId = crypto.createHash("sha256").update(body).digest("hex");

      // Forward the filtered events to Convex for durable processing
      if (apiModule.api?.whopPayments?.ingestWhopWebhook) {
        // Call action when available
        console.log("🔄 Forwarding to Convex action");
        await convex.action(apiModule.api.whopPayments.ingestWhopWebhook, {
          raw: body,
        });
      } else if (apiModule.api?.whopPaymentsMutations?.applyWhopEvent) {
        // Fallback: call mutation directly with parsed data
        console.log("🔄 Forwarding to Convex mutation");
        await convex.mutation(
          apiModule.api.whopPaymentsMutations.applyWhopEvent,
          { eventId, action: event.action, data: event.data }
        );
      } else {
        console.warn("No Convex handler found for Whop payments webhook");
      }
    } catch (err) {
      console.error("⚠️ Failed to forward to Convex handler:", err);
      // Do not fail the webhook if Convex forwarding fails; logs will help retry manually
    }

    if (result.success) {
      console.log("✅ Webhook processed successfully");
      return NextResponse.json({
        success: true,
        message: "Webhook processed successfully",
        action: result.action,
        timestamp: new Date().toISOString(),
      });
    } else {
      console.error("❌ Webhook processing failed:", result.error);
      return NextResponse.json(
        { error: "Webhook processing failed", details: result.error },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error("❌ Webhook error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
