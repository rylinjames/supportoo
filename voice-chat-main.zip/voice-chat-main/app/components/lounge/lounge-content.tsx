"use client";

interface LoungeContentProps {
  companyName: string;
  roomName: string;
}

export function LoungeContent({ companyName, roomName }: LoungeContentProps) {
  return (
    <div className="flex items-center justify-center h-full p-8 max-h-max">
      <div className="text-center">
        <p className="text-sm text-neutral-500 dark:text-neutral-400">
          Voice chat interface coming soon...
        </p>
      </div>
    </div>
  );
}
