"use client";

export function Chat() {
  return (
    <div className="flex-1 min-h-0 flex items-center justify-center">
      <div className="text-center text-neutral-400">
        <p className="text-sm">Chat section coming soon...</p>
        <p className="text-xs mt-1">This feature is under development</p>
      </div>
    </div>
  );
}
