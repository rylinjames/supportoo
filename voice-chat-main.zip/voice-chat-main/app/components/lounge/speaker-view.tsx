"use client";

import { z } from "zod";
import {
  UseFormRegister,
  UseFormHandleSubmit,
  FieldErrors,
} from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/animate-ui/radix/switch";
import { ThemeToggler } from "../shared/theme-toggler";
import { AudioDevicesSection } from "./audio-devices-section";

// Speaker settings schema (no anonymous option)
export const speakerSettingsSchema = z.object({
  // Appearance settings (placeholder for future)
  // Theme settings (placeholder for future)
});

export type SpeakerSettingsFormData = z.infer<typeof speakerSettingsSchema>;

interface SpeakerViewProps {
  register: UseFormRegister<SpeakerSettingsFormData>;
  handleSubmit: UseFormHandleSubmit<SpeakerSettingsFormData>;
  errors: FieldErrors<SpeakerSettingsFormData>;
  isDirty: boolean;
  isSubmitting: boolean;
  reset: () => void;
  localParticipant?: any; // LiveKit local participant
}

export function SpeakerView({
  register,
  handleSubmit,
  errors,
  isDirty,
  isSubmitting,
  reset,
  localParticipant,
}: SpeakerViewProps) {
  const onSubmit = (data: SpeakerSettingsFormData) => {
    console.log("Speaker settings:", data);
    // TODO: Implement speaker settings update
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Header */}

      {/* Appearance Settings */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-neutral-800 dark:text-white">
          User Settings
        </h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-neutral-800 dark:text-neutral-400">
              Change theme
            </span>
            <ThemeToggler />
          </div>
        </div>
      </div>

      <Separator className="bg-neutral-200 dark:bg-neutral-700" />

      {/* Privacy Settings */}
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-neutral-800 dark:text-neutral-400">
          Privacy
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-sm font-medium text-neutral-800 dark:text-neutral-400">
                Anonymous Mode
              </Label>
              <p className="text-xs text-neutral-600 dark:text-neutral-400">
                Speakers cannot be anonymous for accountability.
              </p>
            </div>
            <Switch disabled checked={false} />
          </div>
        </div>
      </div>

      {/* Audio Devices Settings */}
      <AudioDevicesSection localParticipant={localParticipant} />

      {/* Form Actions */}
      <div className="flex justify-end space-x-2 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={reset}
          disabled={!isDirty || isSubmitting}
        >
          Reset
        </Button>
        <Button type="submit" disabled={!isDirty || isSubmitting}>
          {isSubmitting ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </form>
  );
}
