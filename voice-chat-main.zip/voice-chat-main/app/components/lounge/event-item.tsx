"use client";

import React from "react";
import { motion } from "motion/react";

// Event type configuration
const EVENT_CONFIG = {
  user_joined: {
    icon: "🟢",
    color: "text-green-600 dark:text-green-400",
    message: (data: any) => `${data.userName} joined the lounge`,
  },
  user_left: {
    icon: "👋",
    color: "text-neutral-600 dark:text-neutral-400",
    message: (data: any) => `${data.userName} left the lounge`,
  },
  speak_request: {
    icon: "✋",
    color: "text-yellow-600 dark:text-yellow-400",
    message: (data: any) => `${data.userName} requested to speak`,
  },
  user_kicked: {
    icon: "👢",
    color: "text-red-400",
    message: (data: any) =>
      `${data.targetUserName} was kicked by ${data.actorUserName}`,
  },
  user_banned: {
    icon: "🚫",
    color: "text-red-600",
    message: (data: any) =>
      `${data.targetUserName} was banned by ${data.actorUserName}`,
  },
  role_promoted: {
    icon: "⬆️",
    color: "text-blue-600 dark:text-blue-400",
    message: (data: any) => `${data.userName} was promoted to ${data.newRole}`,
  },
  role_demoted: {
    icon: "⬇️",
    color: "text-orange-600 dark:text-orange-400",
    message: (data: any) => `${data.userName} was demoted to ${data.newRole}`,
  },
  room_renamed: {
    icon: "✏️",
    color: "text-purple-600 dark:text-purple-400",
    message: (data: any) => `Lounge renamed to "${data.newRoomName}"`,
  },
  lounge_started: {
    icon: "🚀",
    color: "text-emerald-600 dark:text-emerald-400",
    message: (data: any) => `${data.moderatorName} started the lounge`,
  },
  room_code_updated: {
    icon: "🔑",
    color: "text-blue-600 dark:text-blue-400",
    message: (data: any) => `Room code was updated`,
  },
  minute_warning: {
    icon: "⚠️",
    color: "text-amber-600 dark:text-amber-400",
    message: (data: any) =>
      `Warning: ${data.minutesRemaining} minutes remaining`,
  },
  screen_share_started: {
    icon: "📺",
    color: "text-cyan-600 dark:text-cyan-400",
    message: (data: any) => `${data.userName} started presenting`,
  },
  screen_share_stopped: {
    icon: "📺",
    color: "text-cyan-800 dark:text-cyan-600",
    message: (data: any) => `${data.userName} stopped presenting`,
  },
  participant_muted: {
    icon: "🔇",
    color: "text-red-600 dark:text-red-400",
    message: (data: any) =>
      `${data.userName} was muted by ${data.actorUserName || "moderator"}`,
  },
  participant_unmuted: {
    icon: "🔊",
    color: "text-green-600 dark:text-green-400",
    message: (data: any) =>
      `${data.userName} was unmuted by ${data.actorUserName || "moderator"}`,
  },
  all_speakers_muted: {
    icon: "🔇",
    color: "text-orange-600 dark:text-orange-400",
    message: (data: any) =>
      `All speakers were muted by ${data.actorUserName || "moderator"}`,
  },
} as const;

// Format relative time
function formatRelativeTime(timestamp: number): string {
  const now = Date.now();
  const diff = now - timestamp;

  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  if (seconds > 0) return `${seconds}s ago`;
  return "just now";
}

interface EventItemProps {
  event: {
    _id: string;
    eventType: keyof typeof EVENT_CONFIG;
    eventData: any;
    createdAt: number;
  };
}

export function EventItem({ event }: EventItemProps) {
  const config = EVENT_CONFIG[event.eventType];

  if (!config) {
    return null; // Unknown event type
  }

  const message = config.message(event.eventData);

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="flex flex-col text-xs"
    >
      <div className="flex items-center space-x-2">
        <span className="text-[10px]">{config.icon}</span>
        <p className={`${config.color} font-medium`}>{message}</p>
      </div>

      <p className=" text-neutral-500 mt-1">
        {formatRelativeTime(event.createdAt)}
      </p>
    </motion.div>
  );
}
