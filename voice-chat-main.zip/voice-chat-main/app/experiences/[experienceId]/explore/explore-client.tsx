"use client";
import { useState, useEffect } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import Navbar from "../browse/components/navbar";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { Room, LoungeCategory } from "@/types/participants";
import LoungeCard from "../browse/components/lounge-card";
import { useWhopSync } from "@/app/hooks/useWhopSync";
import Footer from "../browse/components/footer";
import { ChevronRightIcon } from "lucide-react";

type ExploreClientProps = {
  experienceId: string;
  whopUserId: string;
  whopUsername: string;
  fullName: string;
  avatarUrl?: string;
  whopCompanyId: string;
  companyName: string;
  whopAccessLevel: "admin" | "customer" | "no_access" | null;
};

export default function ExploreClient(props: ExploreClientProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("popular");
  const [currentLimit, setCurrentLimit] = useState(8);

  const { syncState, convexCompany } = useWhopSync({
    whopUserId: props.whopUserId,
    whopUsername: props.whopUsername,
    fullName: props.fullName,
    avatarUrl: props.avatarUrl,
    whopCompanyId: props.whopCompanyId,
    whopExperienceId: props.experienceId,
    companyName: props.companyName,
    whopAccessLevel: props.whopAccessLevel,
  });

  // Queries for new two-section layout
  const liveLounges = useQuery(api.browse.getLiveLounges, {});
  const categories = useQuery(api.browse.getRoomCategories, {});
  const categorizedLounges = useQuery(api.browse.getCategorizedLounges, {
    category: selectedCategory,
    offset: 0,
    limit: currentLimit,
  });

  // Handle category change
  const handleCategoryChange = (newCategory: string) => {
    setSelectedCategory(newCategory);
    setCurrentLimit(8); // Reset limit
  };

  // Handle load more
  const handleLoadMore = () => {
    setCurrentLimit((prev) => prev + 8);
  };

  return (
    <div className="min-h-screen w-full relative bg-white dark:bg-background pb-10">
      <Navbar
        whopExperienceId={props.experienceId}
        syncState={syncState}
        whopUserId={props.whopUserId}
        whopCompanyId={props.whopCompanyId}
        companyName={props.companyName}
      />

      <div className="max-w-[1500px] mx-auto px-4 pt-24 pb-8">
        {/* Section 1: Live Lounges */}
        <section className="mb-6 max-w-screen">
          <div className="relative max-w-max">
            <h2 className="font-medium">Live Lounges</h2>
            <ChevronRightIcon className="size-5 absolute -right-5 top-[3px] text-neutral-500" />
          </div>
          <div className="relative flex gap-4 py-4 min-h-100 md:min-h-120 max-md:overflow-x-scroll md:grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {liveLounges?.length ? (
              liveLounges.map((room) => (
                <LoungeCard key={room._id} lounge={room} />
              ))
            ) : (
              <p className="text-neutral-400 text-sm col-span-full w-full text-center absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                No live lounges at the moment
              </p>
            )}
          </div>
        </section>

        {/* Section 2: Categorized Lounges */}
        <section className="mb-6 max-w-screen">
          <div className="flex w-full justify-between items-start gap-3 mb-4">
            <div className="relative max-w-max">
              <h2 className="font-medium">Explore More Lounges</h2>
              <ChevronRightIcon className="size-5 absolute -right-5 top-[3px] text-neutral-500" />
            </div>
            <Select
              value={selectedCategory}
              onValueChange={handleCategoryChange}
            >
              <SelectTrigger className="w-40 md:w-56">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {categories?.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    <div className="flex items-center gap-2">
                      <span>{c.icon}</span>
                      <span>{c.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="relative flex gap-4 py-4 min-h-100 md:min-h-120 max-md:overflow-x-scroll md:grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {categorizedLounges?.length ? (
              categorizedLounges.map((room) => (
                <LoungeCard key={room._id} lounge={room} />
              ))
            ) : (
              <p className="text-neutral-400 text-sm col-span-full w-full text-center absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                No{" "}
                {categories
                  ?.find((c) => c.id === selectedCategory)
                  ?.name?.toLowerCase()}{" "}
                lounges found
              </p>
            )}
          </div>

          {/* Load More Button */}
          {categorizedLounges &&
            categorizedLounges.length >= currentLimit &&
            categorizedLounges.length % 8 === 0 && (
              <div className="flex justify-center pt-4">
                <button
                  onClick={handleLoadMore}
                  className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary/90"
                >
                  Load More
                </button>
              </div>
            )}
        </section>
      </div>
      <Footer />
    </div>
  );
}
