import { v } from "convex/values";
import { mutation, query, action } from "./_generated/server";
import { api } from "./_generated/api";
import { createLoungeEvent, EVENT_TYPES, getFirstName } from "./events";

// Helper function to register room to user's collection
const registerRoomToUser = async (ctx: any, userId: string, roomId: string) => {
  const user = await ctx.db.get(userId);
  if (!user) return;

  const currentRooms = user.registeredRooms || [];
  if (!currentRooms.includes(roomId)) {
    await ctx.db.patch(userId, {
      registeredRooms: [...currentRooms, roomId],
    });
  }
};

// Mark room as inactive
export const markRoomInactive = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.roomId, { isActive: false });
    return { success: true };
  },
});

// Join a public room with entry-time validation
export const joinPublicRoom = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    role: v.optional(
      v.union(
        v.literal("speaker"),
        v.literal("listener"),
        v.literal("moderator")
      )
    ),
    viewerIsCompanyAdmin: v.optional(v.boolean()),
    requesterCompanyId: v.optional(v.id("companies")),
  },
  handler: async (ctx, args) => {
    try {
      // Get room info to validate it's public
      let room = await ctx.db.get(args.roomId);
      if (!room) {
        console.error("joinPublicRoom: room not found", {
          roomId: args.roomId,
        });
        throw new Error("Room not found");
      }

      // Ensure room is public
      if (!room.isPublic) {
        console.error("joinPublicRoom: room is private", {
          roomId: args.roomId,
        });
        throw new Error("This room is private. Use joinPrivateRoom instead.");
      }

      // Check if company has sufficient minutes before allowing join
      const summary = await ctx.runQuery(api.plans.getCompanyUsageSummary, {
        companyId: room.companyId,
      });
      const available = summary.available || 0;
      if (available < 1) {
        throw new Error(
          "Your Whop has insufficient minutes to join this lounge. Please upgrade your plan to continue."
        );
      }

      // Get user info
      const user = await ctx.db.get(args.userId);
      if (!user) {
        console.error("joinPublicRoom: user not found", {
          userId: args.userId,
        });
        throw new Error("User not found");
      }

      // Check if user is the creator
      const isCreator = room.creatorId === args.userId;
      const viewerIsCompanyAdmin = args.viewerIsCompanyAdmin === true;
      const isSameCompany = args.requesterCompanyId
        ? args.requesterCompanyId === room.companyId
        : false;

      // Entry-time validation: Check if room is active
      if (!room.isActive) {
        if (!isCreator) {
          console.warn(
            "joinPublicRoom: room inactive and requester not creator",
            {
              roomId: args.roomId,
              userId: args.userId,
            }
          );
          throw new Error(
            "This room is inactive. Only the creator can boot it up."
          );
        }
        // Reactivate room when creator joins
        await ctx.db.patch(args.roomId, {
          isActive: true,
          updatedAt: Date.now(),
        });
      }

      // Check if user is already in the room
      const existingParticipant = await ctx.db
        .query("participants")
        .withIndex("by_room_and_user", (q) =>
          q.eq("roomId", args.roomId).eq("userId", args.userId)
        )
        .first();

      if (existingParticipant) {
        // Get user info for identity mapping
        const user = await ctx.db.get(args.userId);
        if (!user) {
          console.error("joinPublicRoom: user not found on rejoin", {
            userId: args.userId,
          });
          throw new Error("User not found");
        }
        // Update existing participant
        const participantId = await ctx.db.patch(existingParticipant._id, {
          role: args.role || existingParticipant.role,
          isSpeaking: false,
          isMuted: false,
          leftAt: undefined,
          liveKitIdentity:
            existingParticipant.liveKitIdentity ?? (user.whopUserId as string),
        });

        // Start billing timer for re-joined participant
        await ctx.runMutation(api.participantBilling.startParticipantBilling, {
          participantId: existingParticipant._id,
        });

        return participantId;
      }

      // Determine role: creator/admin => moderator; others => listener or speaker (if autoSpeakersEnabled)
      let finalRole = args.role;
      if (!finalRole) {
        if (isCreator || (viewerIsCompanyAdmin && isSameCompany)) {
          finalRole = "moderator";
        } else if (room.autoSpeakersEnabled) {
          finalRole = "speaker"; // Auto-promote to speaker
        } else {
          finalRole = "listener";
        }
      } else {
        if (
          finalRole === "moderator" &&
          !(isCreator || (viewerIsCompanyAdmin && isSameCompany))
        ) {
          finalRole = "listener";
        }
      }

      // Create new participant
      const participantId = await ctx.db.insert("participants", {
        roomId: args.roomId,
        userId: args.userId,
        role: finalRole,
        isSpeaking: false,
        isMuted: finalRole === "speaker" && room.autoSpeakersEnabled ? true : false,
        joinedAt: Date.now(),
        isCreator: isCreator,
        liveKitIdentity: user.whopUserId,
      });

      await registerRoomToUser(ctx, args.userId, args.roomId);

      // Start real-time billing timer for this participant
      await ctx.runMutation(api.participantBilling.startParticipantBilling, {
        participantId,
      });

      if (!user.isAnonymous) {
        await createLoungeEvent(ctx, {
          roomId: args.roomId,
          eventType: EVENT_TYPES.USER_JOINED,
          userId: args.userId,
          eventData: { userName: getFirstName(user.fullName) },
        });
      }

      return participantId;
    } catch (e: any) {
      console.error("joinPublicRoom error", {
        roomId: args.roomId,
        userId: args.userId,
        message: e?.message || String(e),
      });
      throw e;
    }
  },
});

// Join a private room (requires code verification)
export const joinPrivateRoom = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    roomCode: v.string(), // Room code is required for private rooms
    role: v.optional(
      v.union(
        v.literal("speaker"),
        v.literal("listener"),
        v.literal("moderator")
      )
    ),
    viewerIsCompanyAdmin: v.optional(v.boolean()),
    requesterCompanyId: v.optional(v.id("companies")),
  },
  handler: async (ctx, args) => {
    // Get room info to validate it's private
    let room = await ctx.db.get(args.roomId);
    if (!room) {
      throw new Error("Room not found");
    }

    // Ensure room is private
    if (room.isPublic) {
      throw new Error("This room is public. Use joinPublicRoom instead.");
    }

    // Check if company has sufficient minutes before allowing join
    const summary = await ctx.runQuery(api.plans.getCompanyUsageSummary, {
      companyId: room.companyId,
    });
    const available = summary.available || 0;
    if (available < 1) {
      throw new Error(
        "Your Whop has insufficient minutes to join this lounge. Please upgrade your plan to continue."
      );
    }

    // Get user info
    const user = await ctx.db.get(args.userId);
    if (!user) {
      throw new Error("User not found");
    }

    // Determine if user is creator or already allowed
    const isCreator = room.creatorId === args.userId;
    const viewerIsCompanyAdmin = args.viewerIsCompanyAdmin === true;
    const isSameCompany = args.requesterCompanyId
      ? args.requesterCompanyId === room.companyId
      : false;

    // If there is a pending invite for this user to this room, delete it and grant access
    const invite = await ctx.db
      .query("invitations")
      .withIndex("by_room_and_invitee", (q: any) =>
        q.eq("roomId", args.roomId).eq("inviteeWhopUsername", user.whopUsername)
      )
      .first();
    if (invite) {
      // Add to allow-list if missing
      const currentAllowed = Array.isArray(room.allowedUsers)
        ? room.allowedUsers
        : [];
      if (!currentAllowed.includes(user.whopUsername)) {
        await ctx.db.patch(args.roomId, {
          allowedUsers: [...currentAllowed, user.whopUsername],
        });
        // refresh room snapshot for subsequent checks
        room = (await ctx.db.get(args.roomId))!;
      }
      // Delete the invite to save space
      await ctx.db.delete(invite._id);
    }

    const isUserAllowed =
      isCreator || (room.allowedUsers || []).includes(user.whopUsername || "");

    if (isUserAllowed) {
      // User is already allowed - check if they're an existing participant
      const existingParticipant = await ctx.db
        .query("participants")
        .withIndex("by_room_and_user", (q) =>
          q.eq("roomId", args.roomId).eq("userId", args.userId)
        )
        .first();

      if (existingParticipant) {
        // Ensure we have the user's whopUserId for identity mapping
        const user = await ctx.db.get(args.userId);
        if (!user) {
          throw new Error("User not found");
        }
        // Update existing participant (rejoin)
        return await ctx.db.patch(existingParticipant._id, {
          role: args.role || existingParticipant.role,
          isSpeaking: false,
          isMuted: false,
          leftAt: undefined, // Re-join
          // Ensure liveKitIdentity is set for webhook correlation
          liveKitIdentity:
            existingParticipant.liveKitIdentity ?? (user.whopUserId as string),
        });
      }
    } else {
      // User is not allowed - verify code and add to allowedUsers
      if (!args.roomCode) {
        throw new Error("Room code is required for private rooms");
      }

      // Verify room code
      const hashRoomCode = async (creatorId: string, code: string) => {
        const input = `${creatorId}_${code}_${process.env.PRIVATE_LOUNGE_SECRET}`;
        const encoder = new TextEncoder();
        const data = encoder.encode(input);
        const hashBuffer = await crypto.subtle.digest("SHA-256", data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
      };

      const providedCodeHash = await hashRoomCode(
        room.creatorId,
        args.roomCode
      );

      if (providedCodeHash !== room.roomCodeHash) {
        throw new Error("Invalid room code");
      }

      // Add user to allowedUsers array after successful code verification
      await ctx.db.patch(args.roomId, {
        allowedUsers: [...(room.allowedUsers || []), user.whopUsername],
      });
    }

    // Reactivate room if inactive (anyone with access can reactivate private rooms)
    if (!room.isActive) {
      await ctx.db.patch(args.roomId, {
        isActive: true,
        updatedAt: Date.now(),
      });
    }

    // Determine role: room creator or company admin (same company) becomes moderator, others become speakers
    let finalRole = args.role;
    if (!finalRole) {
      if (
        room.creatorId === args.userId ||
        (viewerIsCompanyAdmin && isSameCompany)
      ) {
        finalRole = "moderator";
      } else {
        finalRole = "speaker"; // Private rooms have no listeners
      }
    } else {
      if (
        finalRole === "moderator" &&
        !(
          room.creatorId === args.userId ||
          (viewerIsCompanyAdmin && isSameCompany)
        )
      ) {
        finalRole = "speaker"; // Private rooms have no listeners
      }
    }

    // Create new participant (for allowed users rejoining or new users)
    const participantId = await ctx.db.insert("participants", {
      roomId: args.roomId,
      userId: args.userId,
      role: finalRole,
      isSpeaking: false,
      isMuted: false,
      joinedAt: Date.now(),
      isCreator: room.creatorId === args.userId,
      // Store LiveKit identity for webhook correlation
      liveKitIdentity: user.whopUserId,
    });

    // Register room to user's collection
    await registerRoomToUser(ctx, args.userId, args.roomId);

    // Create event for user joining
    if (!user.isAnonymous) {
      await createLoungeEvent(ctx, {
        roomId: args.roomId,
        eventType: EVENT_TYPES.USER_JOINED,
        userId: args.userId,
        eventData: {
          userName: getFirstName(user.fullName),
        },
      });
    }

    return participantId;
  },
});

// Join a room
export const joinRoom = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    role: v.optional(
      v.union(
        v.literal("speaker"),
        v.literal("listener"),
        v.literal("moderator")
      )
    ),
  },
  handler: async (ctx, args) => {
    // Get room info for minute validation
    const room = await ctx.db.get(args.roomId);
    if (!room) {
      throw new Error("Room not found");
    }

    // Check if company has sufficient minutes before allowing join
    const summary = await ctx.runQuery(api.plans.getCompanyUsageSummary, {
      companyId: room.companyId,
    });
    const available = summary.available || 0;
    if (available < 1) {
      throw new Error(
        "Your Whop has insufficient minutes to join this lounge. Please upgrade your plan to continue."
      );
    }

    // Check if user is already in the room
    const existingParticipant = await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q) =>
        q.eq("roomId", args.roomId).eq("userId", args.userId)
      )
      .first();

    if (existingParticipant) {
      // Get user info for event and identity mapping
      const user = await ctx.db.get(args.userId);
      if (!user) {
        throw new Error("User not found");
      }
      // Update existing participant
      const participantId = await ctx.db.patch(existingParticipant._id, {
        role: args.role || existingParticipant.role, // Keep existing role if not specified
        isSpeaking: false,
        isMuted: false,
        leftAt: undefined, // Re-join
        // Ensure liveKitIdentity is set for webhook correlation
        liveKitIdentity:
          existingParticipant.liveKitIdentity ?? (user.whopUserId as string),
      });

      // Start billing timer for re-joined participant
      await ctx.runMutation(api.participantBilling.startParticipantBilling, {
        participantId: existingParticipant._id,
      });

      return participantId;
    }

    // Get user info for event
    const user = await ctx.db.get(args.userId);
    if (!user) {
      throw new Error("User not found");
    }

    // Determine role: room creator becomes moderator, others become listeners
    let finalRole = args.role;
    if (!finalRole) {
      if (room.creatorId === args.userId) {
        finalRole = "moderator"; // Room creator becomes moderator
      } else {
        finalRole = "listener"; // Others become listeners by default
      }
    } else {
      // If role is explicitly provided, validate it
      if (finalRole === "moderator" && room.creatorId !== args.userId) {
        // Only room creator can be moderator
        finalRole = "listener";
      }
    }

    // Create new participant
    const participantId = await ctx.db.insert("participants", {
      roomId: args.roomId,
      userId: args.userId,
      role: finalRole,
      isSpeaking: false,
      isMuted: false,
      joinedAt: Date.now(),
      // Multi-lounge support
      isCreator: room.creatorId === args.userId, // Is this user the creator of the lounge
      // Store LiveKit identity for webhook correlation
      liveKitIdentity: user.whopUserId,
    });

    // Register room to user's collection
    await registerRoomToUser(ctx, args.userId, args.roomId);

    // Start real-time billing timer for this participant
    await ctx.runMutation(api.participantBilling.startParticipantBilling, {
      participantId,
    });

    // Create event for user joining (skip if user is anonymous)
    if (!user.isAnonymous) {
      await createLoungeEvent(ctx, {
        roomId: args.roomId,
        eventType: EVENT_TYPES.USER_JOINED,
        userId: args.userId,
        eventData: {
          userName: getFirstName(user.fullName),
        },
      });
    }

    return participantId;
  },
});

// Leave a room
export const leaveRoom = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q) =>
        q.eq("roomId", args.roomId).eq("userId", args.userId)
      )
      .first();

    if (participant) {
      // Get user info for event before deleting
      const user = await ctx.db.get(args.userId);

      // Get room info to check screen sharing
      const room = await ctx.db.get(args.roomId);

      // Actually delete the participant record instead of just marking as left
      await ctx.db.delete(participant._id);

      // Check if the leaving participant was sharing screen and stop it
      if (
        room &&
        room.screenShareActive &&
        room.currentPresenter === args.userId
      ) {
        await ctx.runMutation(api.screenShare.stopScreenShare, {
          roomId: args.roomId,
          presenterId: args.userId,
        });
        console.log(
          `Stopped screen sharing for leaving participant ${args.userId} in room ${args.roomId}`
        );
      }

      // Check if room is now empty and deactivate if so
      const remainingParticipants = await ctx.db
        .query("participants")
        .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
        .collect();

      if (remainingParticipants.length === 0) {
        // Room is empty, deactivate it
        await ctx.db.patch(args.roomId, {
          isActive: false,
          updatedAt: Date.now(),
        });
      }

      // Create event for user leaving (skip if user is anonymous)
      if (user && !user.isAnonymous) {
        await createLoungeEvent(ctx, {
          roomId: args.roomId,
          eventType: EVENT_TYPES.USER_LEFT,
          userId: args.userId,
          eventData: {
            userName: getFirstName(user.fullName),
          },
        });
      }
    }
  },
});

// Update speaking status
export const updateSpeakingStatus = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    isSpeaking: v.boolean(),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q) =>
        q.eq("roomId", args.roomId).eq("userId", args.userId)
      )
      .first();

    if (participant) {
      return await ctx.db.patch(participant._id, {
        isSpeaking: args.isSpeaking,
      });
    }
  },
});

// Update mute status
export const updateMuteStatus = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    isMuted: v.boolean(),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q) =>
        q.eq("roomId", args.roomId).eq("userId", args.userId)
      )
      .first();

    if (participant) {
      return await ctx.db.patch(participant._id, {
        isMuted: args.isMuted,
      });
    }
  },
});

// Internal: remove participant without emitting leave event
export const removeParticipantNoEvent = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q) =>
        q.eq("roomId", args.roomId).eq("userId", args.userId)
      )
      .first();
    if (participant) {
      await ctx.db.delete(participant._id);
    }
  },
});

// Update participant role (moderator action)
export const updateParticipantRole = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    role: v.union(
      v.literal("speaker"),
      v.literal("listener"),
      v.literal("moderator")
    ),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q) =>
        q.eq("roomId", args.roomId).eq("userId", args.userId)
      )
      .first();

    if (participant) {
      const oldRole = participant.role;

      // Get user info for event
      const user = await ctx.db.get(args.userId);

      // Update the role
      await ctx.db.patch(participant._id, {
        role: args.role,
        // Automatically mute users when demoted to listener
        isMuted: args.role === "listener" ? true : participant.isMuted,
      });

      // Create event for role change (skip if user is anonymous)
      if (user && !user.isAnonymous) {
        // Determine promotion/demotion by rank
        const rank = { listener: 1, speaker: 2, moderator: 3 } as const;
        const oldR = oldRole as "listener" | "speaker" | "moderator";
        const newR = args.role as "listener" | "speaker" | "moderator";
        const eventType =
          rank[newR] >= rank[oldR]
            ? EVENT_TYPES.ROLE_PROMOTED
            : EVENT_TYPES.ROLE_DEMOTED;

        await createLoungeEvent(ctx, {
          roomId: args.roomId,
          eventType,
          userId: args.userId,
          eventData: {
            userName: getFirstName(user.fullName),
            oldRole,
            newRole: args.role,
          },
        });
      }
    }
  },
});

// Internal: set participant role without emitting events (used by actions)
export const setParticipantRoleNoEvent = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    role: v.union(
      v.literal("speaker"),
      v.literal("listener"),
      v.literal("moderator")
    ),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q) =>
        q.eq("roomId", args.roomId).eq("userId", args.userId)
      )
      .first();
    if (!participant) return;
    await ctx.db.patch(participant._id, {
      role: args.role,
      isMuted: args.role === "listener" ? true : participant.isMuted,
    });
  },
});

// Secure role change with authorization and LiveKit permission sync
export const authorizeAndSetRole = action({
  args: {
    roomId: v.id("rooms"),
    targetUserId: v.id("users"),
    requestedRole: v.union(
      v.literal("speaker"),
      v.literal("listener"),
      v.literal("moderator")
    ),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
    isWhopAdmin: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    // Load room and participants
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");

    const targetParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.targetUserId }
    );
    if (!targetParticipant) throw new Error("Target participant not found");

    // Authorization
    const isCreator = room.creatorId === args.requesterId;
    const isSameCompany = room.companyId === args.requesterCompanyId;
    const isWhopAdmin = args.isWhopAdmin === true && isSameCompany;

    // Determine requester's current role in the room
    const requesterParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.requesterId }
    );
    const isRequesterModerator = requesterParticipant?.role === "moderator";

    // Determine if target is a company admin via Whop
    const targetUser = await ctx.runQuery(api.users.getUser, {
      userId: args.targetUserId,
    });
    if (!targetUser) throw new Error("Target user not found");

    let targetIsCompanyAdmin = false;
    try {
      const company = await ctx.runQuery(api.companies.getCompanyById, {
        companyId: room.companyId,
      });
      if (company?.whopCompanyId && targetUser.whopUserId) {
        const res = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
          whopUserId: targetUser.whopUserId,
          whopCompanyId: company.whopCompanyId,
        });
        targetIsCompanyAdmin = res?.isAdmin === true;
      }
    } catch {}

    // Rules:
    // - Cannot modify creator
    if (room.creatorId === args.targetUserId) {
      throw new Error("Cannot modify the lounge creator");
    }
    // - Cannot modify a company admin at all (creators and admins cannot manage company admins)
    if (targetIsCompanyAdmin) {
      throw new Error("Cannot modify a company admin moderator");
    }
    // - Moderator changes (promote to moderator, demote moderator) require creator or company admin
    // - Speaker/listener changes can be done by any moderator or above
    const isModeratorChange =
      args.requestedRole === "moderator" ||
      targetParticipant.role === "moderator";

    if (isModeratorChange) {
      if (!(isCreator || isWhopAdmin)) {
        throw new Error("Not authorized to change moderator roles");
      }
    } else {
      if (!(isCreator || isWhopAdmin || isRequesterModerator)) {
        throw new Error("Not authorized to change participant roles");
      }
    }

    // Apply Convex role update
    await ctx.runMutation(api.participants.setParticipantRoleNoEvent, {
      roomId: args.roomId,
      userId: args.targetUserId,
      role: args.requestedRole,
    });

    // LiveKit permission sync
    // LiveKit identity equals Whop user id; we must fetch the user's whopUserId
    const user = await ctx.runQuery(api.users.getUser, {
      userId: args.targetUserId,
    });
    if (!user) throw new Error("User not found");

    const identity = user.whopUserId as string;
    const roomName = args.roomId as unknown as string;
    const shouldPublish =
      args.requestedRole === "speaker" || args.requestedRole === "moderator";

    await ctx.runAction(api.livekit.setParticipantPublishPermission, {
      roomName,
      participantIdentity: identity,
      canPublish: shouldPublish,
    });

    return { success: true };
  },
});

// Securely kick a participant with authorization and LiveKit eject
export const authorizeAndKick = action({
  args: {
    roomId: v.id("rooms"),
    targetUserId: v.id("users"),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
  },
  handler: async (ctx, args) => {
    // Load room
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");

    // Load participants
    const targetParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.targetUserId }
    );
    if (!targetParticipant) {
      return { success: true }; // nothing to do
    }

    const requesterParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.requesterId }
    );

    const isCreator = room.creatorId === args.requesterId;
    const isSameCompany = room.companyId === args.requesterCompanyId;
    const isRequesterModerator = requesterParticipant?.role === "moderator";

    // Determine company-admin status of target and requester via Whop
    const company = await ctx.runQuery(api.companies.getCompanyById, {
      companyId: room.companyId,
    });
    const targetUser = await ctx.runQuery(api.users.getUser, {
      userId: args.targetUserId,
    });
    const requesterUser = await ctx.runQuery(api.users.getUser, {
      userId: args.requesterId,
    });

    let targetIsCompanyAdmin = false;
    let requesterIsCompanyAdmin = false;
    if (company?.whopCompanyId) {
      try {
        if (targetUser?.whopUserId) {
          const res = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
            whopUserId: targetUser.whopUserId,
            whopCompanyId: company.whopCompanyId,
          });
          targetIsCompanyAdmin = res?.isAdmin === true;
        }
        if (requesterUser?.whopUserId) {
          const resReq = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
            whopUserId: requesterUser.whopUserId,
            whopCompanyId: company.whopCompanyId,
          });
          requesterIsCompanyAdmin = resReq?.isAdmin === true && isSameCompany;
        }
      } catch {
        // If admin verification fails, be conservative for moderator targets
        if (targetParticipant.role === "moderator") {
          throw new Error("Unable to verify admin status for kick");
        }
      }
    }

    // Cannot kick creator
    if (room.creatorId === args.targetUserId) {
      throw new Error("Cannot kick the lounge creator");
    }
    // Cannot kick company admins at all
    if (targetIsCompanyAdmin) {
      throw new Error("Cannot kick a company admin");
    }

    // Authorization
    if (targetParticipant.role === "moderator") {
      if (!(isCreator || requesterIsCompanyAdmin)) {
        throw new Error("Not authorized to kick a moderator");
      }
    } else {
      if (!(isCreator || requesterIsCompanyAdmin || isRequesterModerator)) {
        throw new Error("Not authorized to kick this user");
      }
    }

    // Emit kicked event (actor/target) before removal
    try {
      console.log("emitting kicked event", requesterUser, targetUser);
      if (requesterUser && targetUser && !targetUser.isAnonymous) {
        console.log("emitting kicked event", requesterUser, targetUser);
        await createLoungeEvent(ctx, {
          roomId: args.roomId,
          eventType: EVENT_TYPES.USER_KICKED,
          actorUserId: args.requesterId,
          targetUserId: args.targetUserId,
          eventData: {
            actorUserName: getFirstName(requesterUser.fullName),
            targetUserName: getFirstName(targetUser.fullName),
          },
        });
      }
    } catch {}

    // Delete participant WITHOUT emitting USER_LEFT
    await ctx.runMutation(api.participants.removeParticipantNoEvent, {
      roomId: args.roomId,
      userId: args.targetUserId,
    });

    // Eject from LiveKit (best-effort)
    try {
      if (targetUser?.whopUserId) {
        await ctx.runAction(api.livekit.removeParticipantFromLiveKit, {
          roomName: args.roomId as unknown as string,
          participantIdentity: targetUser.whopUserId,
        });
      }
    } catch {}

    return { success: true };
  },
});

// Get all participants in a room
export const getRoomParticipants = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const participants = await ctx.db
      .query("participants")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    // Get user details for each participant
    const participantsWithUsers = await Promise.all(
      participants.map(async (participant) => {
        const user = await ctx.db.get(participant.userId);
        return {
          ...participant,
          user,
        };
      })
    );

    return participantsWithUsers;
  },
});

// Get active participants (not left)
export const getActiveRoomParticipants = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const participants = await ctx.db
      .query("participants")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    // Get user details for each participant
    const participantsWithUsers = await Promise.all(
      participants.map(async (participant) => {
        const user = await ctx.db.get(participant.userId);
        return {
          ...participant,
          user,
        };
      })
    );

    return participantsWithUsers;
  },
});

// Get specific participant by room and user
export const getParticipantByRoomAndUser = query({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q) =>
        q.eq("roomId", args.roomId).eq("userId", args.userId)
      )
      .first();
  },
});

// Get all participants for a room
export const getParticipantsByRoom = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("participants")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
  },
});
