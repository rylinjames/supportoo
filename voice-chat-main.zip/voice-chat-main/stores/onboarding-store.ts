import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface OnboardingFormData {
  name: string;
  description: string;
  category: string;
  roomImage: string;
  isPublic: boolean;
  roomCode: string;
  isTemporary?: boolean;
  discoverListed?: boolean;
  autoSpeakersEnabled?: boolean;
}

interface OnboardingStore {
  // Form state
  formData: OnboardingFormData;
  currentStep: "basic" | "category" | "image" | "complete";

  // Actions
  setFormData: (data: Partial<OnboardingFormData>) => void;
  setCurrentStep: (step: "basic" | "category" | "image" | "complete") => void;
  resetStore: () => void;

  // Navigation
  goToNextStep: () => void;
  goToPreviousStep: () => void;
}

const initialFormData: OnboardingFormData = {
  name: "",
  description: "",
  category: "other",
  roomImage: "",
  isPublic: true,
  roomCode: "",
  isTemporary: true,
  discoverListed: false,
  autoSpeakersEnabled: false,
};

const steps: ("basic" | "category" | "image" | "complete")[] = [
  "basic",
  "category",
  "image",
  "complete",
];

export const useOnboardingStore = create<OnboardingStore>()(
  persist(
    (set, get) => ({
      // Initial state
      formData: initialFormData,
      currentStep: "basic",

      // Actions
      setFormData: (data) => {
        set((state) => ({
          formData: { ...state.formData, ...data },
        }));
      },

      setCurrentStep: (step) => {
        set({ currentStep: step });
      },

      resetStore: () => {
        set({
          formData: initialFormData,
          currentStep: "basic",
        });
      },

      // Navigation
      goToNextStep: () => {
        const { currentStep } = get();
        const currentIndex = steps.indexOf(currentStep);
        const nextIndex = Math.min(currentIndex + 1, steps.length - 1);
        const nextStep = steps[nextIndex];
        set({ currentStep: nextStep });
      },

      goToPreviousStep: () => {
        const { currentStep } = get();
        const currentIndex = steps.indexOf(currentStep);
        const prevIndex = Math.max(currentIndex - 1, 0);
        const prevStep = steps[prevIndex];
        set({ currentStep: prevStep });
      },
    }),
    {
      name: "lounge-onboarding-storage",

      partialize: (state) => ({
        formData: {
          ...state.formData,
          roomCode: "", // Exclude room code from persistence
        },
        currentStep: state.currentStep,
      }),
    }
  )
);
