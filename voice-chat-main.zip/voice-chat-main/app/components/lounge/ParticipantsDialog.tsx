"use client";

import { motion } from "motion/react";
import { Users, X, Crown, Mic } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ParticipantSection } from "./participant-section";
import { Participant } from "./types";

interface ParticipantsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  participants: Participant[];
  currentUserRole?: string;
  currentUserId?: string;
  roomCreatorId?: string;
  roomId: string;
  onAddToSpeakers?: (participantId: string) => void;
  onRemoveFromSpeakers?: (participantId: string) => void;
  onKickFromLounge?: (participantId: string) => void;
  onPromoteToModerator?: (participantId: string) => void;
  onDemoteModeratorToSpeaker?: (participantId: string) => void;
  canManageModerators?: boolean;
  whopCompanyId?: string;
}

export function ParticipantsDialog({
  isOpen,
  onClose,
  participants,
  currentUserRole,
  currentUserId,
  roomCreatorId,
  roomId,
  onAddToSpeakers,
  onRemoveFromSpeakers,
  onKickFromLounge,
  onPromoteToModerator,
  onDemoteModeratorToSpeaker,
  canManageModerators,
  whopCompanyId,
}: ParticipantsDialogProps) {
  // Mobile detection
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 1024);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Sort participants by role
  const moderators = participants.filter(
    (p) => p.role === "moderator" || p.whopUserId === roomCreatorId
  );
  const speakers = participants.filter(
    (p) => p.role === "speaker" && p.whopUserId !== roomCreatorId
  );
  const listeners = participants.filter((p) => p.role === "listener");

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent
        className={`
        ${
          isMobile
            ? "max-w-[95vw] max-h-[85vh] mx-2 rounded-lg"
            : "max-w-xl max-h-[70vh]"
        } 
        flex flex-col
      `}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Participants ({participants.length})
          </DialogTitle>
        </DialogHeader>

        {/* Scrollable Content */}
        <div
          className={`
          flex-1 overflow-y-auto space-y-4 
          ${isMobile ? "pr-1 -webkit-overflow-scrolling-touch" : "pr-2"}
        `}
        >
          {/* Moderators Section */}
          {moderators.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0 }}
            >
              <ParticipantSection
                title="Moderators"
                icon={<Crown className="w-5 h-5 text-primary" />}
                participants={moderators}
                currentUserRole={currentUserRole}
                currentUserId={currentUserId}
                roomCreatorId={roomCreatorId}
                roomId={roomId}
                onAddToSpeakers={onAddToSpeakers}
                onRemoveFromSpeakers={onRemoveFromSpeakers}
                onKickFromLounge={onKickFromLounge}
                onPromoteToModerator={onPromoteToModerator}
                onDemoteModeratorToSpeaker={onDemoteModeratorToSpeaker}
                canManageModerators={canManageModerators}
                whopCompanyId={whopCompanyId}
              />
            </motion.div>
          )}

          {/* Speakers Section */}
          {speakers.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <ParticipantSection
                title="Speakers"
                icon={<Mic className="w-5 h-5 text-emerald-600" />}
                participants={speakers}
                currentUserRole={currentUserRole}
                currentUserId={currentUserId}
                roomCreatorId={roomCreatorId}
                roomId={roomId}
                onAddToSpeakers={onAddToSpeakers}
                onRemoveFromSpeakers={onRemoveFromSpeakers}
                onKickFromLounge={onKickFromLounge}
                onPromoteToModerator={onPromoteToModerator}
                onDemoteModeratorToSpeaker={onDemoteModeratorToSpeaker}
                canManageModerators={canManageModerators}
                whopCompanyId={whopCompanyId}
              />
            </motion.div>
          )}

          {/* Listeners Section */}
          {listeners.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <ParticipantSection
                title="Listeners"
                icon={<Users className="w-5 h-5 text-neutral-400" />}
                participants={listeners}
                currentUserRole={currentUserRole}
                currentUserId={currentUserId}
                roomCreatorId={roomCreatorId}
                roomId={roomId}
                onAddToSpeakers={onAddToSpeakers}
                onRemoveFromSpeakers={onRemoveFromSpeakers}
                onKickFromLounge={onKickFromLounge}
                onPromoteToModerator={onPromoteToModerator}
                onDemoteModeratorToSpeaker={onDemoteModeratorToSpeaker}
                canManageModerators={canManageModerators}
                whopCompanyId={whopCompanyId}
              />
            </motion.div>
          )}

          {/* Empty State */}
          {participants.length === 0 && (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No participants in this lounge</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
