import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { Id } from "./_generated/dataModel";
import { createLoungeEvent, EVENT_TYPES, getFirstName } from "./events";

// Permission validation helper - pure function for performance
const validateScreenSharePermission = async (
  ctx: any,
  userId: Id<"users">,
  roomId: Id<"rooms">
) => {
  // Single read for user
  const user = await ctx.db.get(userId);
  if (!user?.isActive) {
    throw new Error("User not found or inactive");
  }

  // Single read for room
  const room = await ctx.db.get(roomId);
  if (!room?.isActive) {
    throw new Error("Room not found or inactive");
  }

  // Single read for company
  const company = await ctx.db.get(room.companyId);
  if (!company) {
    throw new Error("Company not found");
  }

  // Check moderator permissions
  const isRoomCreator = room.creatorId === userId;
  const isCompanyOwner = company.owner === userId;

  if (!isRoomCreator && !isCompanyOwner) {
    throw new Error("Only moderators can control screen sharing");
  }

  return { user, room, company };
};

// Start screen share - single atomic operation
export const startScreenShare = mutation({
  args: {
    roomId: v.id("rooms"),
    presenterId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    try {
      // Validate permissions (3 DB reads)
      await validateScreenSharePermission(ctx, args.presenterId, args.roomId);

      // Get current room state
      const room = await ctx.db.get(args.roomId);
      if (room?.screenShareActive) {
        throw new Error("Screen sharing is already active in this room");
      }

      // Single atomic write
      await ctx.db.patch(args.roomId, {
        screenShareActive: true,
        currentPresenter: args.presenterId,
        screenShareStartedAt: now,
        updatedAt: now,
      });

      // Get presenter user for event
      const presenter = await ctx.db.get(args.presenterId);
      if (presenter) {
        // Create live feed event
        await createLoungeEvent(ctx, {
          roomId: args.roomId,
          eventType: EVENT_TYPES.SCREEN_SHARE_STARTED,
          userId: args.presenterId,
          eventData: {
            userName: getFirstName(presenter.fullName),
          },
        });
      }

      return { success: true };
    } catch (error) {
      console.error("Screen share start failed:", {
        roomId: args.roomId,
        presenterId: args.presenterId,
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: now,
      });
      throw error;
    }
  },
});

// Stop screen share - graceful cleanup
export const stopScreenShare = mutation({
  args: {
    roomId: v.id("rooms"),
    presenterId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    try {
      // Validate permissions
      await validateScreenSharePermission(ctx, args.presenterId, args.roomId);

      // Get current room state
      const room = await ctx.db.get(args.roomId);
      if (!room?.screenShareActive) {
        // Already stopped - return success (idempotent)
        return { success: true, alreadyStopped: true };
      }

      if (room.currentPresenter !== args.presenterId) {
        throw new Error("Only the current presenter can stop screen sharing");
      }

      // Get presenter user for event before cleanup
      const presenter = await ctx.db.get(args.presenterId);

      // Single atomic cleanup
      await ctx.db.patch(args.roomId, {
        screenShareActive: false,
        currentPresenter: undefined,
        screenShareStartedAt: undefined,
        updatedAt: now,
      });

      // Create live feed event
      if (presenter) {
        await createLoungeEvent(ctx, {
          roomId: args.roomId,
          eventType: EVENT_TYPES.SCREEN_SHARE_STOPPED,
          userId: args.presenterId,
          eventData: {
            userName: getFirstName(presenter.fullName),
          },
        });
      }

      return { success: true };
    } catch (error) {
      console.error("Screen share stop failed:", {
        roomId: args.roomId,
        presenterId: args.presenterId,
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: now,
      });
      throw error;
    }
  },
});

// Takeover screen share - zero-downtime handoff
export const takeoverScreenShare = mutation({
  args: {
    roomId: v.id("rooms"),
    newPresenterId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    try {
      // Validate permissions for new presenter
      await validateScreenSharePermission(
        ctx,
        args.newPresenterId,
        args.roomId
      );

      // Get current room state
      const room = await ctx.db.get(args.roomId);
      if (!room?.screenShareActive) {
        throw new Error("No active screen sharing to take over");
      }

      // Atomic takeover - zero downtime
      await ctx.db.patch(args.roomId, {
        currentPresenter: args.newPresenterId,
        screenShareStartedAt: now, // Reset start time
        updatedAt: now,
        // screenShareActive stays true - no interruption
      });

      return { success: true };
    } catch (error) {
      console.error("Screen share takeover failed:", {
        roomId: args.roomId,
        newPresenterId: args.newPresenterId,
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: now,
      });
      throw error;
    }
  },
});

// Get screen share state - efficient read
export const getScreenShareState = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);

    if (!room?.screenShareActive) {
      return {
        isActive: false,
        presenter: null,
        startedAt: null,
      };
    }

    // Only fetch presenter details when actually needed
    const presenter = room.currentPresenter
      ? await ctx.db.get(room.currentPresenter)
      : null;

    return {
      isActive: true,
      presenterId: room.currentPresenter,
      presenter: presenter
        ? {
            id: presenter._id,
            name: presenter.fullName,
            username: presenter.whopUsername,
          }
        : null,
      startedAt: room.screenShareStartedAt,
    };
  },
});
