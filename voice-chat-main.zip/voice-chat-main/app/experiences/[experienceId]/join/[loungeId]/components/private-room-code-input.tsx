"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { REGEXP_ONLY_DIGITS_AND_CHARS } from "input-otp";

interface PrivateRoomCodeInputProps {
  onSubmit: (code: string) => void;
  isLoading?: boolean;
  error?: string | null;
  creatorName?: string;
  disabled?: boolean;
}

export function PrivateRoomCodeInput({
  onSubmit,
  isLoading = false,
  error = null,
  creatorName,
  disabled = false,
}: PrivateRoomCodeInputProps) {
  const [roomCode, setRoomCode] = useState("");

  const handleCodeChange = (value: string) => {
    setRoomCode(value);
  };

  const handleCodeComplete = (value: string) => {
    setRoomCode(value);
    // Auto-submit when 8 characters are entered
    if (value.length === 8 && !isLoading) {
      onSubmit(value);
    }
  };

  const handleManualSubmit = () => {
    if (roomCode.length === 8 && !isLoading) {
      onSubmit(roomCode);
    }
  };

  const isInputDisabled = disabled || isLoading;
  const isSubmitDisabled = isInputDisabled || roomCode.length !== 8;

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center space-y-4">
        <InputOTP
          maxLength={8}
          value={roomCode}
          onChange={handleCodeChange}
          onComplete={handleCodeComplete}
          pattern={REGEXP_ONLY_DIGITS_AND_CHARS}
          disabled={isInputDisabled}
          autoFocus
        >
          <InputOTPGroup>
            <InputOTPSlot index={0} />
            <InputOTPSlot index={1} />
            <InputOTPSlot index={2} />
            <InputOTPSlot index={3} />
          </InputOTPGroup>
          <InputOTPGroup>
            <InputOTPSlot index={4} />
            <InputOTPSlot index={5} />
            <InputOTPSlot index={6} />
            <InputOTPSlot index={7} />
          </InputOTPGroup>
        </InputOTP>

        <p className="text-xs text-neutral-500 dark:text-neutral-400 text-center">
          Enter the 8-character code
          {creatorName && <> shared by {creatorName.split(" ")[0]}</>}
        </p>
      </div>

      {/* Error Message */}
      {error && (
        <div className="text-center">
          <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
        </div>
      )}

      {/* Manual Submit Button */}
      <div className="text-center">
        <Button
          onClick={handleManualSubmit}
          disabled={isSubmitDisabled}
          className="w-full"
        >
          {isLoading ? "Joining..." : "Join Lounge"}
        </Button>
      </div>
    </div>
  );
}
