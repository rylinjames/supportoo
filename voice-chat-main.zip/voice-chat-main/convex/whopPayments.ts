"use node";

import { action } from "./_generated/server";
import { v } from "convex/values";
import { api } from "./_generated/api";

function sha256(input: string): string {
  const crypto = require("crypto") as typeof import("crypto");
  return crypto.createHash("sha256").update(input).digest("hex");
}

export const ingestWhopWebhook = action({
  args: { raw: v.string() },
  handler: async (
    ctx,
    args
  ): Promise<{ success: boolean; error?: string; dedupe?: boolean }> => {
    try {
      // Compute a stable id for idempotency in Node env
      const eventId = sha256(args.raw);
      let parsed: any;
      try {
        parsed = JSON.parse(args.raw);
      } catch (e) {
        console.error("Failed to parse webhook JSON:", e);
        return { success: false, error: "invalid_json" };
      }

      const actionName = parsed.action || "unknown";
      const data = parsed.data || {};

      console.log(`🔄 Action calling mutation: ${actionName}`);
      console.log(`📦 Data being passed:`, JSON.stringify(data));

      // Pass to mutation for durable DB writes
      const result = await ctx.runMutation(
        api.whopPaymentsMutations.applyWhopEvent,
        {
          eventId,
          action: actionName,
          data,
        }
      );

      console.log(`✅ Mutation result:`, result);
      return result ?? { success: false, error: "mutation_failed" };
    } catch (error) {
      console.error("❌ Action error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "unknown_error",
      };
    }
  },
});
