"use client";



import React from "react";
import { useRouter } from "next/navigation";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, Gift } from "lucide-react";

interface PromoData {
  id: string;
  title: string;
  subtitle: string;
  discountCode: string;
  discountPercent: number;
  targetTier: string;
  benefits: string[];
  urgency: string;
  cta: {
    primary: string;
    secondary: string;
  };
  expiresAt: number;
}

interface PromoDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onMaybeLater: () => void;
  promo: PromoData;
  experienceId: string;
}

export function PromoDialog({
  isOpen,
  onClose,
  onMaybeLater,
  promo,
  experienceId,
}: PromoDialogProps) {
  const router = useRouter();

  const handleClaimDiscount = () => {
    router.push(
      `/experiences/${experienceId}/plans?promo=${promo.discountCode}&tier=${promo.targetTier}`
    );
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-8 text-center">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Gift illustration */}
        <div className="mb-6">
          <div className="w-16 h-16 mx-auto bg-primary/10 dark:bg-primary/20 rounded-2xl flex items-center justify-center mb-4">
            <Gift className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-xl font-semibold text-neutral-900 dark:text-white mb-2">
            Enjoy Voice Lounge Creator
          </h2>
          <p className="text-sm text-neutral-600 dark:text-neutral-400">
            Scale your community with unlimited voice rooms
          </p>
        </div>

        {/* Benefits list */}
        <div className="mb-6">
          <div className="space-y-3">
            {promo.benefits.map((benefit, index) => (
              <div
                key={index}
                className="flex items-start space-x-3 text-sm text-neutral-700 dark:text-neutral-300"
              >
                <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                <span>{benefit}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Promo code section */}
        <div className="mb-6 text-center">
          <p className="text-sm text-neutral-600 dark:text-neutral-400 mb-2">
            Use promo code at checkout:
          </p>
          <div className="inline-block bg-neutral-100 dark:bg-neutral-800 px-4 py-2 rounded-lg">
            <code className="text-primary font-mono font-semibold text-lg">
              {promo.discountCode}
            </code>
          </div>
        </div>

        {/* Price section */}
        {/* <div className="mb-8">
          <div className="flex items-baseline justify-center gap-2 mb-2">
            <span className="text-4xl font-bold text-primary">
              ${promo.discountPercent === 100 ? "0" : "0.99"}
            </span>
            <div className="text-right">
              <div className="bg-primary text-white text-xs px-2 py-1 rounded font-medium">
                {promo.discountPercent}% OFF
              </div>
              <div className="text-sm text-neutral-600 dark:text-neutral-400 mt-1">
                First month
              </div>
            </div>
          </div>
        </div> */}

        {/* Action buttons */}
        <div className="space-y-3">
          <Button
            onClick={handleClaimDiscount}
            size={"lg"}
            className="w-full bg-primary hover:bg-primary/90 text-white py-3 font-medium"
          >
            {promo.cta.primary} 100% off
          </Button>
          <button
            onClick={onMaybeLater}
            className="w-full text-neutral-600 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 py-2 font-medium transition-colors"
          >
            {promo.cta.secondary}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
