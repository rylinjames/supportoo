import { mutation, query } from "./_generated/server";
import { api } from "./_generated/api";
import { Id } from "./_generated/dataModel";
import { v } from "convex/values";

export type PlanTier = "free" | "starter" | "pro" | "creator";

export function getNextMonthStartUtc(nowMs: number): number {
  const d = new Date(nowMs);
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth();
  const next = new Date(Date.UTC(y, m + 1, 1, 0, 0, 0, 0));
  return next.getTime();
}

// Helper function to get plan tier name from plan ID
async function getPlanTierName(
  ctx: any,
  planId: Id<"plans"> | undefined
): Promise<PlanTier> {
  if (!planId) return "free";

  const plan = await ctx.db.get(planId);
  if (!plan) return "free";

  return plan.tier;
}

// Read-only: expose complete catalog to clients/admin UI
export const getCatalog = query({
  args: {},
  handler: async (ctx) => {
    const plans = await ctx.db
      .query("plans")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .order("asc")
      .collect();

    // Transform to complete format with all fields needed by UI
    const catalog: Record<
      string,
      {
        name: string;
        description: string;
        price: string;
        includedMinutes: number;
        features: string[];
        maxSavedLounges?: number;
      }
    > = {};

    for (const plan of plans) {
      catalog[plan.tier] = {
        name: plan.name,
        description: plan.description,
        price: `$${plan.priceUsd}`,
        includedMinutes: plan.includedMinutes,
        features: plan.features,
        maxSavedLounges: plan.maxSavedLounges,
      };
    }

    return catalog;
  },
});

// Helper: clamp minutes to non-negative
function clampMinutes(n: number | undefined): number {
  if (!n || n < 0) return 0;
  return Math.floor(n);
}

// Read: plan settings for a company (now reads from company fields directly)
export const getCompanyPlanSettings = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId as Id<"companies">);
    if (!company) throw new Error("Company not found");

    // Get plan details for tier name and minutes
    const plan = company.planTier ? await ctx.db.get(company.planTier) : null;
    const planTierName = plan?.tier ?? "free";
    const effectiveIncludedMinutes = plan?.includedMinutes ?? 200; // fallback to free tier

    // Features read directly from plan record
    const features = {
      maxSavedLounges: plan?.maxSavedLounges,
      adminsOnlyCreate: plan?.tier !== "free",
      canListOnDiscover: plan?.tier === "creator",
      canUploadCustomImages:
        plan?.tier && ["starter", "pro", "creator"].includes(plan.tier),
      allowMembersToCreateLounges: company.allowMembersToCreateLounges ?? false,
    };

    return {
      planTier: planTierName,
      effectiveIncludedMinutes,
      features,
      planOwner: company.planOwner,
    };
  },
});

// Read: usage summary for a company (without live accruals yet)
export const getCompanyUsageSummary = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId as Id<"companies">);
    if (!company) throw new Error("Company not found");

    // Get plan details from database using planTier ID
    const plan = company.planTier ? await ctx.db.get(company.planTier) : null;
    const planTierName = plan?.tier ?? "free";

    const included = plan?.includedMinutes ?? 200; // fallback to free tier
    const used = clampMinutes(
      company.minutesUsedThisMonth as number | undefined
    );
    // Sum credits
    const credits = await ctx.db
      .query("companyMinuteCredits")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();
    const creditsRemainingTotal = credits.reduce(
      (acc, c) => acc + clampMinutes(c.remainingMinutes),
      0
    );
    const available = Math.max(0, included - used) + creditsRemainingTotal;
    const renewalAt = company.planRenewsAt ?? getNextMonthStartUtc(Date.now());
    return { used, included, creditsRemainingTotal, available, renewalAt };
  },
});

// Enhanced analytics data with historical trends and insights
export const getCompanyAnalytics = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId as Id<"companies">);
    if (!company) throw new Error("Company not found");

    // Get current usage summary
    const usageSummary: {
      used: number;
      included: number;
      creditsRemainingTotal: number;
      available: number;
      renewalAt: number;
    } = await ctx.runQuery(api.plans.getCompanyUsageSummary, {
      companyId: args.companyId,
    });

    // Get plan details
    const plan = company.planTier ? await ctx.db.get(company.planTier) : null;
    const planTierName = plan?.tier ?? "free";

    // Get credit breakdown
    const credits = await ctx.db
      .query("companyMinuteCredits")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();

    const creditBreakdown = credits.map((credit) => ({
      id: credit._id,
      source: credit.source,
      originalMinutes: credit.minutes,
      remainingMinutes: credit.remainingMinutes,
      usedMinutes: credit.minutes - credit.remainingMinutes,
      purchasedAt: credit.purchasedAt,
      expiresAt: credit.expiresAt,
      isExpired: credit.expiresAt ? credit.expiresAt < Date.now() : false,
    }));

    // Get last 6 months of usage data for trends
    const now = Date.now();
    const currentDate = new Date(now);
    const monthlyData = [];

    for (let i = 5; i >= 0; i--) {
      const targetDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() - i,
        1
      );
      const yearMonth = `${targetDate.getFullYear()}-${String(targetDate.getMonth() + 1).padStart(2, "0")}`;

      const monthlyUsage = await ctx.db
        .query("companyUsageMonthly")
        .withIndex("by_company_and_month", (q) =>
          q.eq("companyId", args.companyId).eq("yearMonth", yearMonth)
        )
        .first();

      monthlyData.push({
        yearMonth,
        displayName: targetDate.toLocaleDateString("en-US", {
          month: "short",
          year: "numeric",
        }),
        totalMinutes: monthlyUsage?.totalMinutes ?? 0,
        includedMinutes:
          monthlyUsage?.includedMinutesAtStart ?? usageSummary.included,
        planTier: monthlyUsage?.planTierAtStart ?? planTierName,
      });
    }

    // Calculate efficiency metrics
    const totalCreditsUsed = creditBreakdown.reduce(
      (acc, credit) => acc + credit.usedMinutes,
      0
    );
    const totalCreditsPurchased = creditBreakdown.reduce(
      (acc, credit) => acc + credit.originalMinutes,
      0
    );
    const creditUtilization =
      totalCreditsPurchased > 0
        ? (totalCreditsUsed / totalCreditsPurchased) * 100
        : 0;

    // Usage patterns
    const averageMonthlyUsage =
      monthlyData.reduce((acc, month) => acc + month.totalMinutes, 0) / 6;
    const currentMonthUsage = usageSummary.used;
    const usageTrend =
      currentMonthUsage > averageMonthlyUsage
        ? "increasing"
        : currentMonthUsage < averageMonthlyUsage
          ? "decreasing"
          : "stable";

    // Efficiency insights
    const planUtilization = (usageSummary.used / usageSummary.included) * 100;
    const isUnderUtilized = planUtilization < 30;
    const isOverUtilized = planUtilization > 90;

    return {
      // Current state
      usageSummary,
      planTierName,

      // Credit analysis
      creditBreakdown,
      totalCreditsPurchased,
      totalCreditsUsed,
      creditUtilization,

      // Historical trends
      monthlyData,
      averageMonthlyUsage,
      usageTrend,

      // Efficiency metrics
      planUtilization,
      isUnderUtilized,
      isOverUtilized,

      // Recommendations
      recommendations: {
        shouldUpgrade: isOverUtilized && planTierName !== "creator",
        shouldDowngrade: isUnderUtilized && planTierName !== "free",
        shouldBuyCredits: usageSummary.available < 60, // Less than 1 hour remaining
        needsBetterPlanning:
          usageTrend === "increasing" && usageSummary.available < 240, // Less than 4 hours
      },
    };
  },
});

// Simple chat eligibility
export const isChatEnabled = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId as Id<"companies">);

    // Get plan details from database using planTier ID
    const plan = company?.planTier ? await ctx.db.get(company.planTier) : null;
    const tier = plan?.tier ?? "free";

    return { enabled: tier === "pro" || tier === "creator" };
  },
});

// Get plan owner details
export const getPlanOwnerDetails = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId);
    if (!company || !company.planOwner) return null;

    // Find user by Whop user ID
    const user = await ctx.db
      .query("users")
      .withIndex("by_whop_user_id", (q) =>
        q.eq("whopUserId", company.planOwner!)
      )
      .first();

    if (!user) return null;

    return {
      whopUserId: user.whopUserId,
      whopUsername: user.whopUsername,
      fullName: user.fullName,
    };
  },
});

// Check if company can upload custom images (Starter tier and above)
export const canCompanyUploadImages = query({
  args: { companyId: v.id("companies") },
  handler: async (
    ctx,
    args
  ): Promise<{
    canUpload: boolean;
    currentTier: string;
    reason: string | null;
  }> => {
    const company = await ctx.db.get(args.companyId);
    if (!company) {
      return {
        canUpload: false,
        currentTier: "unknown",
        reason: "Company not found",
      };
    }

    // Get plan and tier name for display
    const plan = company.planTier ? await ctx.db.get(company.planTier) : null;
    const currentTier = plan?.tier ?? "free";

    // Allow uploads in development environment OR if plan tier allows it
    const isDevelopment = process.env.NODE_ENV === "development";
    const planAllowsUploads = plan?.tier
      ? ["starter", "pro", "creator"].includes(plan.tier)
      : false;
    const canUpload = isDevelopment || planAllowsUploads;

    return {
      canUpload,
      currentTier,
      reason: canUpload ? null : "Image uploads require Starter tier or higher",
    };
  },
});

// Transfer plan ownership to a new admin
export const transferPlanOwnership = mutation({
  args: {
    companyId: v.id("companies"),
    newOwnerWhopUserId: v.string(),
  },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId);
    if (!company) throw new Error("Company not found");

    // Verify the new owner exists
    const newOwner = await ctx.db
      .query("users")
      .withIndex("by_whop_user_id", (q) =>
        q.eq("whopUserId", args.newOwnerWhopUserId)
      )
      .first();

    if (!newOwner) throw new Error("New owner not found");

    // Update the company with new plan owner
    await ctx.db.patch(args.companyId, {
      planOwner: args.newOwnerWhopUserId,
      updatedAt: Date.now(),
    });

    console.log(
      `👑 Plan ownership transferred to ${args.newOwnerWhopUserId} for company ${args.companyId}`
    );

    return { success: true };
  },
});

// Note: Monthly rollover mutation has been removed
/* export const monthlyRollover = mutation({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const companies = await ctx.db.query("companies").collect();
    let rolled = 0;
    for (const c of companies) {
      const renewAt = (c as any).planRenewsAt as number | undefined;
      if (renewAt && renewAt <= now) {
        const ym = `${new Date(now).getUTCFullYear()}-${String(
          new Date(now).getUTCMonth() + 1
        ).padStart(2, "0")}`;
        const settings = await ctx.runQuery(api.plans.getCompanyPlanSettings, {
          companyId: c._id,
        });
        const existing = await ctx.db
          .query("companyUsageMonthly")
          .withIndex("by_company_and_month", (q) =>
            q.eq("companyId", c._id).eq("yearMonth", ym)
          )
          .first();
        if (!existing) {
          await ctx.db.insert("companyUsageMonthly", {
            companyId: c._id,
            yearMonth: ym,
            totalMinutes: 0,
            includedMinutesAtStart: settings.effectiveIncludedMinutes,
            planTierAtStart: settings.planTier,
            createdAt: now,
            updatedAt: now,
          });
        }
        await ctx.db.patch(c._id, {
          minutesUsedThisMonth: 0,
          planRenewsAt: getNextMonthStartUtc(now),
          updatedAt: now,
        });

        // Note: Scheduled plan changes are no longer used
        // All plan changes are now handled immediately via webhooks

        rolled += 1;
      }
    }
    return { rolled };
  },
}); */

// One-time/idempotent migration: initialize missing company plan fields
export const backfillCompanyPlanDefaults = mutation({
  args: {},
  handler: async (ctx) => {
    const companies = await ctx.db.query("companies").collect();
    let updated = 0;
    const now = Date.now();

    // Get the free plan ID to use as default
    const freePlan = await ctx.db
      .query("plans")
      .withIndex("by_tier", (q) => q.eq("tier", "free"))
      .filter((q) => q.eq(q.field("isActive"), true))
      .first();

    for (const c of companies) {
      const patch: Record<string, unknown> = {};

      // plan tier default - now references plans table ID
      if (!("planTier" in c) || c.planTier === undefined) {
        patch.planTier = freePlan?._id; // Use free plan ID instead of string literal
      }

      // minutes used guard
      if (
        !("minutesUsedThisMonth" in c) ||
        c.minutesUsedThisMonth === undefined
      ) {
        patch.minutesUsedThisMonth = 0;
      } else if (
        typeof c.minutesUsedThisMonth === "number" &&
        c.minutesUsedThisMonth < 0
      ) {
        patch.minutesUsedThisMonth = 0;
      }

      // renewal boundary
      if (!("planRenewsAt" in c) || !c.planRenewsAt) {
        patch.planRenewsAt = getNextMonthStartUtc(now);
      }

      // creation toggle default
      if (
        !("allowMembersToCreateLounges" in c) ||
        c.allowMembersToCreateLounges === undefined
      ) {
        patch.allowMembersToCreateLounges = false;
      }

      if (Object.keys(patch).length > 0) {
        patch.updatedAt = now;
        await ctx.db.patch(c._id, patch);
        updated += 1;
      }
    }
    return { updated };
  },
});
