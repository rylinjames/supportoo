"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useWhopPayments } from "@/app/providers/whop-payments-provider";
import { useAction } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useSessionStore } from "@/stores/session-store";
import { toast } from "sonner";
import { Loader2, CreditCard, AlertCircle } from "lucide-react";

interface CheckoutModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  planId?: string; // Whop planId used by checkout links (works for plans and packs)
  amount?: number; // Amount in dollars
  title?: string;
  description?: string;
  onComplete?: () => void;
  // Payment metadata for tracking
  metadata?: {
    type: "plan" | "credits";
    planTier?: string;
    credits?: number;
  };
}

// New charge + iframe SDK modal
export default function CheckoutModal({
  open,
  onOpenChange,
  planId,
  amount,
  title = "Secure Checkout",
  description,
  onComplete,
  metadata,
}: CheckoutModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { chargeUserWithModal, isLoaded } = useWhopPayments();
  const createCharge = useAction(api.whop.createCharge);
  const { session } = useSessionStore();

  const handlePurchase = async () => {
    if (
      !planId ||
      !amount ||
      !session?.whopUserId ||
      !session?.whopExperienceId
    ) {
      setError("Missing required payment information");
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      // 1. Create server-side charge
      console.log("Creating charge...", { planId, amount, title });

      const chargeResult = await createCharge({
        userId: session.whopUserId,
        experienceId: session.whopExperienceId,
        planId,
        amount,
        title,
        metadata: {
          type: metadata?.type || "plan",
          planTier: metadata?.planTier,
          credits: metadata?.credits,
          traceId: `web_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`,
          ...(session?.whopCompanyId && { companyId: session.whopCompanyId }),
        },
      });

      if (!chargeResult.success) {
        throw new Error(chargeResult.error || "Failed to create charge");
      }

      if (!chargeResult.session) {
        throw new Error("No session data received");
      }

      console.log("Charge created, opening modal...", chargeResult.session);

      // 2. Open native Whop modal
      const paymentResult = await chargeUserWithModal(chargeResult.session);

      if (paymentResult.success) {
        console.log("Payment completed successfully", {
          receiptId: paymentResult.receiptId,
        });
        toast.success("Payment successful! Your plan will be updated shortly.");

        // Close modal and trigger completion callback
        onOpenChange(false);
        onComplete?.();
      } else {
        throw new Error(
          paymentResult.error || "Payment was cancelled or failed"
        );
      }
    } catch (error) {
      console.error("Payment failed:", error);
      const errorMessage =
        error instanceof Error ? error.message : "Payment failed";
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClose = () => {
    if (!isProcessing) {
      onOpenChange(false);
      setError(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-background max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            {title}
          </DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Plan/Pack Details */}
          {planId && amount && (
            <div className="p-4 bg-neutral-200 dark:bg-neutral-800 rounded-lg">
              <div className="flex justify-between items-center text-neutral-800 dark:text-white">
                <span className="font-medium">{title}</span>
                <span className="text-lg font-bold">${amount.toFixed(2)}</span>
              </div>
              {metadata?.type === "plan" && metadata?.planTier && (
                <p className="text-sm text-muted-foreground mt-1">
                  {metadata.planTier.charAt(0).toUpperCase() +
                    metadata.planTier.slice(1)}{" "}
                  Plan
                </p>
              )}
            </div>
          )}

          {/* Error Display */}
          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-800 dark:text-red-200">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          {/* SDK Loading State */}
          {!isLoaded && (
            <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg text-blue-800 dark:text-blue-200">
              <Loader2 className="w-4 h-4 animate-spin" />
              <p className="text-sm">Loading payment system...</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={isProcessing}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handlePurchase}
              disabled={isProcessing || !isLoaded || !planId || !amount}
              className="flex-1"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <CreditCard className="w-4 h-4 mr-2" />
                  Pay ${amount?.toFixed(2) || "0.00"}
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
