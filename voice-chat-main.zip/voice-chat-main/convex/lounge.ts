import { v } from "convex/values";
import { query } from "./_generated/server";
import { Id } from "./_generated/dataModel";

// Comprehensive lounge data query for the new architecture
export const getLoungeData = query({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    companyId: v.id("companies"),
  },
  handler: async (ctx, args) => {
    // Fetch all required data in parallel for optimal performance
    const [room, user, company, participant] = await Promise.all([
      // Room data
      ctx.db.get(args.roomId),

      // User data
      ctx.db.get(args.userId),

      // Company data
      ctx.db.get(args.companyId),

      // Participant data for this user in this room
      ctx.db
        .query("participants")
        .withIndex("by_room_and_user", (q) =>
          q.eq("roomId", args.roomId).eq("userId", args.userId)
        )
        .first(),
    ]);

    // Validate that room exists
    if (!room) {
      return null;
    }

    // Validate that user exists
    if (!user) {
      throw new Error("User not found");
    }

    // Validate that company exists
    if (!company) {
      throw new Error("Company not found");
    }

    // Compute derived fields
    const isCreator = room.creatorId === args.userId;
    const userRole =
      participant?.role || (isCreator ? "moderator" : "listener");
    const canJoin = room.isActive || isCreator; // Creators can boot up inactive rooms
    const hasParticipant = !!participant;

    // Return comprehensive lounge data
    return {
      // Core entities
      room: {
        id: room._id,
        name: room.name,
        description: room.description,
        category: room.category,
        roomImage: room.roomImage,
        isPublic: room.isPublic,
        isActive: room.isActive,
        participantCount: room.participantCount,
        maxParticipants: room.maxParticipants,
        creatorId: room.creatorId,
        companyId: room.companyId,
        createdAt: room.createdAt,
        // Room shutdown tracking
        shutdownReason: room.shutdownReason,
        shutdownAt: room.shutdownAt,
        // TODO: Private room fields when implemented
        // roomCodeHash: room.roomCodeHash,
        // allowedUsers: room.allowedUsers,
      },

      user: {
        id: user._id,
        whopUserId: user.whopUserId,
        whopUsername: user.whopUsername,
        fullName: user.fullName,
        avatarUrl: user.avatarUrl,
        isActive: user.isActive,
      },

      company: {
        id: company._id,
        name: company.name,
        whopCompanyId: company.whopCompanyId,
        whopExperienceId: company.whopExperienceId,
        isActive: company.isActive,
      },

      participant: participant
        ? {
            id: participant._id,
            role: participant.role,
            isSpeaking: participant.isSpeaking,
            isMuted: participant.isMuted,
            isCreator: participant.isCreator,
            joinedAt: participant.joinedAt,
            leftAt: participant.leftAt,
          }
        : null,

      // Computed fields for easy access
      computed: {
        isCreator,
        userRole,
        canJoin,
        hasParticipant,
        isRoomCreator: isCreator,
        canManageRoom: isCreator, // For future moderation features
        roomStatus: room.isActive ? "active" : "inactive",
        userStatus: hasParticipant ? "joined" : "not_joined",
      },
    };
  },
});

// Optional: Get basic room info for quick checks (lighter query)
export const getRoomInfo = query({
  args: {
    roomId: v.id("rooms"),
  },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);

    if (!room) {
      return null;
    }

    return {
      id: room._id,
      name: room.name,
      isPublic: room.isPublic,
      isActive: room.isActive,
      participantCount: room.participantCount,
      maxParticipants: room.maxParticipants,
      creatorId: room.creatorId,
    };
  },
});
