"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useMutation, useAction, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useOnboardingStore } from "@/stores/onboarding-store";
import { BasicStep } from "./basic-step";
import { CategoryStep } from "./category-step";
import { ImageStep } from "./image-step";
import { ReviewStep } from "./review-step";
import { Id } from "@/convex/_generated/dataModel";
import { toast } from "sonner";

interface LoungeOnboardingProps {
  experienceId: string;
  companyId: string;
  userId: string;
  experienceImage?: string;
  onCreationStart?: () => void;
  onOnboardingStart?: () => void;
  usageSummary?: {
    used: number;
    included: number;
    creditsRemainingTotal: number;
    available: number;
    renewalAt: number;
  };
}

export function LoungeOnboarding({
  experienceId,
  companyId,
  userId,
  experienceImage,
  onCreationStart,
  onOnboardingStart,
  usageSummary,
}: LoungeOnboardingProps) {
  const [isCreating, setIsCreating] = useState(false);
  const router = useRouter();

  // Notify parent that onboarding has started
  useEffect(() => {
    onOnboardingStart?.();
  }, [onOnboardingStart]);

  // Convex mutations and actions
  const createRoomMutation = useMutation(api.rooms.createRoom);
  const getRoomDetailsAction = useAction(api.rooms.getRoomDetailsAction);

  // Determine if current user is company owner (admin)
  const isOwner = useQuery(api.companies.isCompanyOwner, {
    companyId: companyId as Id<"companies">,
    userId: userId as Id<"users">,
  });
  const company = useQuery(api.companies.getCompanyById, {
    companyId: companyId as Id<"companies">,
  });
  const companyRoomCount = useQuery(api.companies.getCompanyRoomCount, {
    companyId: companyId as Id<"companies">,
  });
  // Get company plan settings for discover toggle
  const planSettings = useQuery(api.plans.getCompanyPlanSettings, {
    companyId: companyId as Id<"companies">,
  });

  // TODO: Private room mutations
  // const generateRoomCodeAction = useMutation(api.rooms.generateRoomCodeAction);

  // Zustand store
  const {
    formData: storeFormData,
    currentStep,
    setFormData,
    goToNextStep,
    goToPreviousStep,
  } = useOnboardingStore();

  const handleDataChange = (data: any) => {
    setFormData(data);
  };

  const handleBasicSubmit = (data: any) => {
    setFormData(data);
    goToNextStep();
  };

  const handleCategorySubmit = (data: any) => {
    setFormData(data);
    goToNextStep();
  };

  const handleCategorySkip = () => {
    setFormData({ category: "other" });
    goToNextStep();
  };

  const handleImageSkip = () => {
    setFormData({ roomImage: experienceImage || "" });
    goToNextStep();
  };

  const handleImageContinue = (uploadedImageUrl?: string) => {
    // If an image was uploaded, use it; otherwise keep existing
    if (uploadedImageUrl) {
      setFormData({ roomImage: uploadedImageUrl });
    }
    goToNextStep();
  };

  const handleUpgradeToPro = () => {
    // TODO: Implement upgrade flow
  };

  const handleFinalSubmit = async () => {
    // Notify parent that creation is starting
    onCreationStart?.();
    setIsCreating(true);
    try {
      const finalRoomImage =
        storeFormData.roomImage || experienceImage || "/images/whop-logo.png";

      // TODO: Private room code generation
      // let roomCode = "";
      // if (!storeFormData.isPublic) {
      //   roomCode = await generateRoomCodeAction();
      // }

      // Create the room
      const roomId = await createRoomMutation({
        name: storeFormData.name,
        description: storeFormData.description || "",
        category: storeFormData.category || "other",
        roomImage: finalRoomImage,
        companyId: companyId as Id<"companies">,
        userId: userId as Id<"users">,
        isPublic: storeFormData.isPublic,
        roomCode: storeFormData.roomCode,
        isTemporary: storeFormData.isTemporary ?? true,
        discoverListed: storeFormData.discoverListed || false,
        autoSpeakersEnabled: storeFormData.autoSpeakersEnabled || false,
      });

      // Small delay to ensure clean navigation without error flashes
      setTimeout(() => {
        router.push(`/experiences/${experienceId}/join/${roomId}`);
      }, 100);
    } catch (error) {
      console.error("Failed to create room:", error);

      // Handle specific error messages
      const errorMessage =
        error instanceof Error ? error.message : String(error);
      const lowerError = errorMessage.toLowerCase();

      if (
        lowerError.includes("saved lounge limit reached") ||
        lowerError.includes("maximum") ||
        lowerError.includes("limit") ||
        lowerError.includes("reached their plan limit") ||
        lowerError.includes("reached the maximum")
      ) {
        // Extract company name from error if present
        const companyName = company?.name || "Your company";
        toast.error(
          `${companyName} has reached its lounge limit. Please upgrade your plan or delete an existing lounge to create a new one.`,
          { duration: 6000 }
        );
      } else if (lowerError.includes("insufficient minutes")) {
        toast.error(
          "Insufficient minutes to create a lounge. Please upgrade your plan."
        );
      } else {
        toast.error("Failed to create room. Please try again.");
      }
    } finally {
      setIsCreating(false);
    }
  };

  // Basic Info Step
  if (currentStep === "basic") {
    return (
      <BasicStep
        initialData={{
          name: storeFormData.name,
          isPublic: storeFormData.isPublic,
          roomCode: storeFormData.roomCode,
          isTemporary: storeFormData.isTemporary,
          discoverListed: storeFormData.discoverListed || false,
        }}
        canEditLifecycle={Boolean(isOwner)}
        onSubmit={handleBasicSubmit}
        onDataChange={handleDataChange}
        experienceId={experienceId}
        companyName={company?.name}
        companyRoomCount={companyRoomCount}
        isOwner={Boolean(isOwner)}
        planSettings={planSettings}
        usageSummary={usageSummary}
      />
    );
  }

  // Category Step
  if (currentStep === "category") {
    return (
      <CategoryStep
        initialData={{
          description: storeFormData.description,
          category: storeFormData.category,
        }}
        onSubmit={handleCategorySubmit}
        onBack={goToPreviousStep}
        onSkip={handleCategorySkip}
        onDataChange={handleDataChange}
      />
    );
  }

  // Image Step
  if (currentStep === "image") {
    const effectiveImage =
      experienceImage || storeFormData.roomImage || "/images/whop-logo.png";
    const usingDefault = effectiveImage === "/images/whop-logo.png";
    return (
      <ImageStep
        roomImage={effectiveImage}
        usingDefault={usingDefault}
        companyId={companyId}
        onContinue={handleImageContinue}
        onBack={goToPreviousStep}
        onSkip={handleImageSkip}
        onUpgradeToPro={handleUpgradeToPro}
      />
    );
  }

  // Review Step
  const finalRoomImage =
    storeFormData.roomImage || experienceImage || "/images/whop-logo.png";

  return (
    <ReviewStep
      formData={{
        name: storeFormData.name,
        description: storeFormData.description,
        category: storeFormData.category,
        roomImage: finalRoomImage,
        isPublic: storeFormData.isPublic,
        roomCode: storeFormData.roomCode,
        discoverListed: storeFormData.discoverListed || false,
      }}
      onBack={goToPreviousStep}
      onSubmit={handleFinalSubmit}
      isCreating={isCreating}
    />
  );
}
