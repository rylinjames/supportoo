import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { Id } from "@/convex/_generated/dataModel";

interface VoiceChatSession {
  // Essential Convex references
  convexUserId: Id<"users">;
  convexCompanyId: Id<"companies">;

  // Whop context (for auth and redirects)
  whopUserId: string;
  whopExperienceId: string;
  whopCompanyId: string; // add canonical Whop company id for deep links
  whopAccessLevel: "admin" | "customer" | "no_access";
  experienceImage: string;

  // Cache timestamp
  syncedAt: number;
}

interface SessionStore {
  session: VoiceChatSession | null;
  _hasHydrated: boolean;

  // Actions
  setSession: (session: VoiceChatSession) => void;
  clearSession: () => void;
  setHasHydrated: (hasHydrated: boolean) => void;
  isSessionValid: () => boolean;
}

export const useSessionStore = create<SessionStore>()(
  persist(
    (set, get) => ({
      session: null,
      _hasHydrated: false,

      setSession: (session) => set({ session }),
      clearSession: () => set({ session: null }),
      setHasHydrated: (hasHydrated) => set({ _hasHydrated: hasHydrated }),
      isSessionValid: () => {
        const { session } = get();
        // Keep validity focused on core identifiers; UI assets like images are optional
        return !!(
          session?.convexUserId &&
          session?.convexCompanyId &&
          session?.whopUserId &&
          session?.whopExperienceId &&
          session?.syncedAt
        );
      },
    }),
    {
      name: "voice-chat-session",
      storage: createJSONStorage(() => localStorage),
      onRehydrateStorage: (state) => {
        return (state, error) => {
          if (!error) {
            state?.setHasHydrated(true);
          }
        };
      },
      partialize: (state) => ({
        session: state.session,
        // _hasHydrated is not persisted - managed by onRehydrateStorage
      }),
    }
  )
);
