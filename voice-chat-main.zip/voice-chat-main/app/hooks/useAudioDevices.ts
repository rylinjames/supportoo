import { useState, useEffect, useCallback } from "react";

export interface AudioDevice {
  deviceId: string;
  label: string;
  kind: "audioinput" | "audiooutput";
  groupId?: string;
}

interface UseAudioDevicesReturn {
  inputDevices: AudioDevice[];
  outputDevices: AudioDevice[];
  isLoading: boolean;
  error: string | null;
  refreshDevices: () => Promise<void>;
  hasPermission: boolean;
}

export function useAudioDevices(): UseAudioDevicesReturn {
  const [inputDevices, setInputDevices] = useState<AudioDevice[]>([]);
  const [outputDevices, setOutputDevices] = useState<AudioDevice[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasPermission, setHasPermission] = useState(false);

  const enumerateDevices = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Check if we have permission by trying to get user media
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        setHasPermission(true);
      } catch (permissionError) {
        setHasPermission(false);
      }

      // Enumerate all devices
      const devices = await navigator.mediaDevices.enumerateDevices();

      // Filter and format audio devices
      const audioInputs = devices
        .filter((device) => device.kind === "audioinput")
        .map((device) => ({
          deviceId: device.deviceId,
          label: device.label || `Microphone ${device.deviceId.slice(0, 8)}...`,
          kind: "audioinput" as const,
          groupId: device.groupId,
        }));

      const audioOutputs = devices
        .filter((device) => device.kind === "audiooutput")
        .map((device) => ({
          deviceId: device.deviceId,
          label: device.label || `Speaker ${device.deviceId.slice(0, 8)}...`,
          kind: "audiooutput" as const,
          groupId: device.groupId,
        }));

      setInputDevices(audioInputs);
      setOutputDevices(audioOutputs);
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to enumerate devices";
      setError(errorMessage);
      console.error("Device enumeration error:", err);
    } finally {
      setIsLoading(false);
    }
  }, [hasPermission]);

  const refreshDevices = useCallback(async () => {
    await enumerateDevices();
  }, [enumerateDevices]);

  // Listen for device changes
  useEffect(() => {
    const handleDeviceChange = () => {
      enumerateDevices();
    };

    navigator.mediaDevices.addEventListener("devicechange", handleDeviceChange);

    return () => {
      navigator.mediaDevices.removeEventListener(
        "devicechange",
        handleDeviceChange
      );
    };
  }, [enumerateDevices]);

  // Initial device enumeration
  useEffect(() => {
    enumerateDevices();
  }, [enumerateDevices]);

  return {
    inputDevices,
    outputDevices,
    isLoading,
    error,
    refreshDevices,
    hasPermission,
  };
}
