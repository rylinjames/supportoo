"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils";

interface TabsProps {
  children: React.ReactNode;
  defaultTab?: string;
  className?: string;
}

interface TabProps {
  value: string;
  children: React.ReactNode;
}

interface TabListProps {
  children: React.ReactNode;
  className?: string;
}

interface TabTriggerProps {
  value: string;
  children: React.ReactNode;
  isActive?: boolean;
  onClick?: () => void;
}

interface TabContentProps {
  value: string;
  children: React.ReactNode;
  isActive?: boolean;
  className?: string;
}

// Tab Context
const TabContext = React.createContext<{
  activeTab: string;
  setActiveTab: (tab: string) => void;
} | null>(null);

// Main Tabs Component
export function Tabs({
  children,
  defaultTab = "live-feed",
  className,
}: TabsProps) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  return (
    <TabContext.Provider value={{ activeTab, setActiveTab }}>
      <div className={cn("w-full", className)}>{children}</div>
    </TabContext.Provider>
  );
}

// Tab List Component
export function TabList({ children, className }: TabListProps) {
  return (
    <div
      className={cn(
        "flex border-b border-neutral-200 dark:border-neutral-800",
        className
      )}
    >
      {children}
    </div>
  );
}

// Tab Trigger Component
export function TabTrigger({
  value,
  children,
  isActive,
  onClick,
}: TabTriggerProps) {
  const context = React.useContext(TabContext);
  const isActiveTab = isActive ?? context?.activeTab === value;

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else if (context) {
      context.setActiveTab(value);
    }
  };

  return (
    <button
      onClick={handleClick}
      className={cn(
        "flex-1 px-4 py-2 cursor-pointer text-sm font-medium transition-colors",
        "border-b-2 border-transparent",
        isActiveTab ? " border-primary" : "text-neutral-400"
      )}
    >
      {children}
    </button>
  );
}

// Tab Content Component
export function TabContent({
  value,
  children,
  isActive,
  className,
}: TabContentProps) {
  const context = React.useContext(TabContext);
  const isActiveTab = isActive ?? context?.activeTab === value;

  if (!isActiveTab) return null;

  return <div className={cn("flex-1", className)}>{children}</div>;
}

// Hook for using tabs
export function useTabs() {
  const context = React.useContext(TabContext);
  if (!context) {
    throw new Error("useTabs must be used within a Tabs component");
  }
  return context;
}
