"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { ROOM_CATEGORIES } from "@/convex/categories";
import { ArrowLeft } from "lucide-react";
import { ThemeToggler } from "../../shared/theme-toggler";

const categorySchema = z.object({
  description: z.string().optional(),
  category: z.string(),
});

type CategoryFormData = z.infer<typeof categorySchema>;

interface CategoryStepProps {
  initialData: {
    description?: string;
    category: string;
  };
  onSubmit: (data: CategoryFormData) => void;
  onBack: () => void;
  onSkip: () => void;
  onDataChange: (data: Partial<CategoryFormData>) => void;
}

export function CategoryStep({
  initialData,
  onSubmit,
  onBack,
  onSkip,
  onDataChange,
}: CategoryStepProps) {
  const form = useForm<CategoryFormData>({
    resolver: zodResolver(categorySchema),
    defaultValues: initialData,
  });

  const { watch } = form;

  const handleCategorySelect = (categoryId: string) => {
    form.setValue("category", categoryId);
    onDataChange({ category: categoryId });
  };

  const handleSkip = () => {
    form.setValue("category", "other");
    onDataChange({ category: "other" });
    onSkip();
  };

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-foreground flex items-center justify-center p-4 relative">
      <div className="w-full max-w-[800px]">
        <div className="bg-white dark:bg-neutral-800 rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">
              Choose a Category
            </h1>
            <p className="text-neutral-600 dark:text-neutral-400">
              Help others discover your lounge
            </p>
          </div>

          <Form {...form}>
            <div className="space-y-8">
              {/* Description Field */}
              <div className="space-y-4">
                <Label className="text-sm font-medium text-neutral-900 dark:text-white">
                  Description (Optional)
                </Label>
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input
                          placeholder="Describe what your lounge is about..."
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            onDataChange({ description: e.target.value });
                          }}
                          className="w-full"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Category Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium text-neutral-900 dark:text-white">
                    Category
                  </Label>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleSkip}
                  >
                    Skip
                  </Button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {ROOM_CATEGORIES.map((category) => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => handleCategorySelect(category.id)}
                      className={`p-4 rounded-lg border transition-all ${
                        watch("category") === category.id
                          ? "border-orange-500"
                          : "border-neutral-200 dark:border-neutral-700 hover:border-neutral-300 dark:hover:border-neutral-600"
                      }`}
                    >
                      <div className="text-center">
                        <div className="text-2xl mb-2">{category.icon}</div>
                        <p className="text-sm font-medium text-neutral-900 dark:text-white text-wrap">
                          {category.name}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="flex gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={onBack}
                    className="flex-1"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </Button>
                  <Button
                    onClick={form.handleSubmit(onSubmit)}
                    disabled={!watch("category")}
                    className="flex-1 text-white"
                  >
                    Continue
                  </Button>
                </div>
              </div>
            </div>
          </Form>
        </div>
      </div>
      <div className="absolute top-4 right-4">
        <ThemeToggler />
      </div>
    </div>
  );
}
