const crypto = require("crypto");
const https = require("https");

// Your webhook secret from environment
const WEBHOOK_SECRET =
  process.env.WHOP_WEBHOOK_SECRET || "your_webhook_secret_here";

// Test webhook endpoint (update with your actual URL)
const WEBHOOK_URL = "http://localhost:3000/api/webhook/whop/payments";

// Sample webhook payloads
const testPayloads = {
  // Test successful subscription payment
  subscription_success: {
    action: "app_payment.succeeded",
    api_version: "2024-01-01",
    data: {
      id: "pay_test_123",
      billing_reason: "subscription",
      final_amount: 1500, // $15.00
      currency: "usd",
      paid_at: Math.floor(Date.now() / 1000),
      product_id: "plan_yCWz1EmLIMHj1", // starter plan
      plan_id: "plan_yCWz1EmLIMHj1",
      company_buyer_id: "biz_test_company_123",
      metadata: {
        tier: "starter",
        companyId: "biz_test_company_123",
      },
    },
  },

  // Test successful minute pack payment
  minute_pack_success: {
    action: "app_payment.succeeded",
    api_version: "2024-01-01",
    data: {
      id: "pay_test_456",
      billing_reason: "one_time",
      final_amount: 1000, // $10.00
      currency: "usd",
      paid_at: Math.floor(Date.now() / 1000),
      product_id: "plan_CmumhNcVdm2cR",
      company_buyer_id: "biz_test_company_123",
      metadata: {
        minutes: 20000,
        companyId: "biz_test_company_123",
      },
    },
  },

  // Test failed payment
  payment_failed: {
    action: "app_payment.failed",
    api_version: "2024-01-01",
    data: {
      id: "pay_test_789",
      billing_reason: "subscription",
      final_amount: 1500,
      currency: "usd",
      error: "insufficient_funds",
      company_buyer_id: "biz_test_company_123",
    },
  },
};

// Generate webhook signature
function generateSignature(payload, secret) {
  const timestamp = Math.floor(Date.now() / 1000);
  const payloadString = JSON.stringify(payload);
  const signature = crypto
    .createHmac("sha256", secret)
    .update(`${timestamp}.${payloadString}`)
    .digest("hex");

  return `t=${timestamp},v1=${signature}`;
}

// Send webhook request
function sendWebhook(payload, signature) {
  const payloadString = JSON.stringify(payload);

  const options = {
    hostname: "localhost",
    port: 3000,
    path: "/api/webhook/whop/payments",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-whop-signature": signature,
      "Content-Length": Buffer.byteLength(payloadString),
    },
  };

  const req = https.request(options, (res) => {
    let data = "";
    res.on("data", (chunk) => {
      data += chunk;
    });
    res.on("end", () => {
      console.log(`✅ Response: ${res.statusCode}`);
      console.log(`📄 Response body: ${data}`);
    });
  });

  req.on("error", (error) => {
    console.error(`❌ Request error: ${error.message}`);
  });

  req.write(payloadString);
  req.end();
}

// Test all payloads
async function runTests() {
  console.log("🧪 Testing webhook payloads...\n");

  for (const [testName, payload] of Object.entries(testPayloads)) {
    console.log(`📤 Testing: ${testName}`);
    const signature = generateSignature(payload, WEBHOOK_SECRET);

    try {
      sendWebhook(payload, signature);
      console.log(`   Signature: ${signature.substring(0, 50)}...`);
      console.log(
        `   Payload: ${JSON.stringify(payload).substring(0, 100)}...\n`
      );

      // Wait a bit between requests
      await new Promise((resolve) => setTimeout(resolve, 1000));
    } catch (error) {
      console.error(`   ❌ Error: ${error.message}\n`);
    }
  }
}

// Run tests if this file is executed directly
if (require.main === module) {
  if (!WEBHOOK_SECRET || WEBHOOK_SECRET === "your_webhook_secret_here") {
    console.error("❌ Please set WHOP_WEBHOOK_SECRET environment variable");
    process.exit(1);
  }

  runTests();
}

module.exports = { testPayloads, generateSignature, sendWebhook };
