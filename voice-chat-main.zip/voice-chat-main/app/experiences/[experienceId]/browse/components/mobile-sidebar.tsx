"use client";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { CircleDollarSign, Menu } from "lucide-react";
import Link from "next/link";
import AdminSettingsDialog from "./admin-settings-dialog";
import AnalyticsDialog from "./analytics-dialog";
import { useSessionStore } from "@/stores/session-store";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";

export default function MobileSidebar({
  whopExperienceId,
  syncState,
}: {
  whopExperienceId: string;
  syncState: "idle" | "syncing" | "success" | "error";
}) {
  const { session } = useSessionStore();

  // Get plan owner details
  const planOwnerDetails = useQuery(
    api.plans.getPlanOwnerDetails,
    session?.convexCompanyId ? { companyId: session.convexCompanyId } : "skip"
  );

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="xl:hidden border-none bg-background!"
          aria-label="Open menu"
        >
          <Menu className="size-6 text-neutral-800 dark:text-white hover:text-neutral-600 dark:hover:text-neutral-300" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-72 px-4 md:px-8">
        <SheetHeader>
          <SheetTitle className="hidden">Menu</SheetTitle>
        </SheetHeader>

        {/* Menu Section */}
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-3">
              Menu
            </h3>
            <div className="space-y-2">
              <SheetClose asChild>
                <Link
                  href={`/experiences/${whopExperienceId}/browse`}
                  className="block px-3 py-2 rounded-md text-sm text-neutral-800 dark:text-white hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
                >
                  Your Lounges
                </Link>
              </SheetClose>
              <SheetClose asChild>
                <Link
                  href={`/experiences/${whopExperienceId}/explore`}
                  className="block px-3 py-2 rounded-md text-sm text-neutral-800 dark:text-white hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
                >
                  Explore Lounges
                </Link>
              </SheetClose>
              <SheetClose asChild>
                <Link
                  href={`/experiences/${whopExperienceId}/create`}
                  className={`block px-3 py-2 rounded-md text-sm transition-colors ${
                    syncState === "success"
                      ? "text-neutral-800 dark:text-white hover:text-neutral-600 dark:hover:text-neutral-300"
                      : "text-neutral-400 cursor-not-allowed"
                  }`}
                  onClick={(e) => {
                    if (syncState !== "success") {
                      e.preventDefault();
                    }
                  }}
                >
                  Create Lounge
                </Link>
              </SheetClose>
            </div>
          </div>

          <Separator className="my-4" />

          {/* Admin Section */}
          <div>
            <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-3">
              Admin
            </h3>
            <div className="space-y-2 flex flex-col">
              <SheetClose asChild>
                <Link
                  href={`/experiences/${whopExperienceId}/plans`}
                  className="flex px-3 py-2 items-center rounded-md text-sm text-neutral-800 dark:text-white hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
                >
                  <CircleDollarSign className="w-4 h-4 mr-4" />
                  View Pricing Plans
                </Link>
              </SheetClose>

              {/* Analytics Dialog */}
              {session?.convexCompanyId && (
                <div className="block">
                  <AnalyticsDialog companyId={session.convexCompanyId} />
                </div>
              )}

              {/* Admin Settings Dialog */}
              {session?.convexCompanyId && (
                <div className="block">
                  <AdminSettingsDialog
                    whopExperienceId={whopExperienceId}
                    companyId={session.convexCompanyId}
                    currentUserId={session.whopUserId}
                    planOwnerDetails={planOwnerDetails || undefined}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
