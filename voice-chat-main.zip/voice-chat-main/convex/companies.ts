import { mutation, query } from "./_generated/server";
import { api } from "./_generated/api";
import { v } from "convex/values";

// Get company by Whop company ID
export const getCompanyByWhopId = query({
  args: { whopCompanyId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("companies")
      .withIndex("by_whop_company_id", (q) =>
        q.eq("whopCompanyId", args.whopCompanyId)
      )
      .first();
  },
});

// Get company by Whop experience ID
export const getCompanyByExperienceId = query({
  args: { whopExperienceId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("companies")
      .withIndex("by_whop_experience_id", (q) =>
        q.eq("whopExperienceId", args.whopExperienceId)
      )
      .first();
  },
});

// Get company by ID
export const getCompanyById = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.companyId);
  },
});

// Admin-only toggle to allow members to create lounges
export const setAllowMembersToCreateLounges = mutation({
  args: {
    companyId: v.id("companies"),
    requesterId: v.id("users"),
    allow: v.boolean(),
  },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId);
    if (!company) throw new Error("Company not found");
    const requester = await ctx.db.get(args.requesterId);
    if (!requester) throw new Error("Requester not found");

    const isOwner = company.owner === args.requesterId;
    if (!isOwner) {
      throw new Error("Only the company owner can change this setting");
    }

    await ctx.db.patch(args.companyId, {
      allowMembersToCreateLounges: args.allow,
      updatedAt: Date.now(),
    });

    // Return success status
    return { success: true };
  },
});

// Check if user is company owner
export const isCompanyOwner = query({
  args: {
    companyId: v.id("companies"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId);
    return company?.owner === args.userId;
  },
});

// Count total rooms for a company (active and inactive)
export const getCompanyRoomCount = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const rooms = await ctx.db
      .query("rooms")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();
    return rooms.length;
  },
});

// Get active room for company (only one allowed)
export const getActiveRoomForCompany = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("rooms")
      .withIndex("by_company_and_active", (q) =>
        q.eq("companyId", args.companyId).eq("isActive", true)
      )
      .first();
  },
});

// Check if company can create a new room (no active room exists)
export const canCreateRoomForCompany = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const activeRoom = await ctx.db
      .query("rooms")
      .withIndex("by_company_and_active", (q) =>
        q.eq("companyId", args.companyId).eq("isActive", true)
      )
      .first();

    return !activeRoom; // Can create if no active room exists
  },
});

// Create company (for initial setup)
export const createCompany = mutation({
  args: {
    whopCompanyId: v.string(),
    whopExperienceId: v.string(),
    name: v.string(),
    owner: v.id("users"),
  },
  handler: async (ctx, args) => {
    // Check if company with Whop ID already exists
    const existing = await ctx.db
      .query("companies")
      .withIndex("by_whop_company_id", (q) =>
        q.eq("whopCompanyId", args.whopCompanyId)
      )
      .first();

    if (existing) {
      throw new Error("Company with this Whop ID already exists");
    }

    // Get the free plan ID to use as default
    const freePlan = await ctx.db
      .query("plans")
      .withIndex("by_tier", (q) => q.eq("tier", "free"))
      .filter((q) => q.eq(q.field("isActive"), true))
      .first();

    if (!freePlan) {
      throw new Error("Free plan not found in database");
    }

    const companyId = await ctx.db.insert("companies", {
      whopCompanyId: args.whopCompanyId,
      whopExperienceId: args.whopExperienceId,
      name: args.name,
      owner: args.owner,
      isActive: true,
      planTier: freePlan._id, // Use plan ID reference instead of string literal
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    return companyId;
  },
});

// Update company
export const updateCompany = mutation({
  args: {
    companyId: v.id("companies"),
    name: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { companyId, ...updates } = args;

    return await ctx.db.patch(companyId, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

// Deactivate company
export const deactivateCompany = mutation({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    return await ctx.db.patch(args.companyId, {
      isActive: false,
      updatedAt: Date.now(),
    });
  },
});

// Get all companies
export const getAllCompanies = query({
  handler: async (ctx) => {
    return await ctx.db.query("companies").collect();
  },
});
