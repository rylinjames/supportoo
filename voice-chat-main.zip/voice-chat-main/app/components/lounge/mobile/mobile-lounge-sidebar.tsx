import {
  Popover,
  PopoverTrigger,
  PopoverContent,
} from "@/components/animate-ui/radix/popover";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Menu,
  Heart,
  MessageCircle,
  Share,
  Users,
  TvMinimal,
  MonitorX,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import SettingsModal from "../settings-modal";
import { ParticipantsDialog } from "../ParticipantsDialog";
import { Participant } from "../types";

// Define reactions locally since the import path is unclear
const REACTIONS = [
  { emoji: "❤️", label: "Love" },
  { emoji: "👍", label: "Thumbs Up" },
  { emoji: "🎉", label: "Celebrate" },
  { emoji: "🔥", label: "Fire" },
  { emoji: "😂", label: "Laugh" },
  { emoji: "🤔", label: "Think" },
];

interface MobileLoungeSidebarProps {
  roomId: string;
  currentUserRole: string;
  whopUserData: {
    _id: string;
    whopUserId: string;
    whopUsername: string;
    fullName: string;
    isAnonymous?: boolean;
  };
  roomDetails: any;
  localParticipant: any;
  handleReaction: (emoji: string) => void;
  canRequestToSpeak: boolean;
  handleRequestToSpeak: () => void;
  openResetConfirmation: () => void;
  isReactionOpen: boolean;
  setIsReactionOpen: (open: boolean) => void;
  // Screen share props
  canScreenShare?: boolean;
  isSharing?: boolean;
  screenShareLoading?: boolean;
  screenShareActive?: boolean;
  screenShareError?: string | null;
  participantCount?: number;
  participants?: Participant[];
  onStartScreenShare?: () => void;
  onStopScreenShare?: () => void;
  onTakeoverScreenShare?: () => void;
  // Participant management functions
  onAddToSpeakers?: (participantId: string) => void;
  onRemoveFromSpeakers?: (participantId: string) => void;
  onKickFromLounge?: (participantId: string) => void;
  onPromoteToModerator?: (participantId: string) => void;
  onDemoteModeratorToSpeaker?: (participantId: string) => void;
  canManageModerators?: boolean;
}

const MobileLoungeSidebar = ({
  roomId,
  currentUserRole,
  whopUserData,
  roomDetails,
  localParticipant,
  handleReaction,
  canRequestToSpeak,
  handleRequestToSpeak,
  openResetConfirmation,
  isReactionOpen,
  setIsReactionOpen,
  // Screen share props
  canScreenShare,
  isSharing,
  screenShareLoading,
  screenShareActive,
  screenShareError,
  participantCount,
  participants,
  onStartScreenShare,
  onStopScreenShare,
  onTakeoverScreenShare,
  // Participant management functions
  onAddToSpeakers,
  onRemoveFromSpeakers,
  onKickFromLounge,
  onPromoteToModerator,
  onDemoteModeratorToSpeaker,
  canManageModerators,
}: MobileLoungeSidebarProps) => {
  const [showParticipantsDialog, setShowParticipantsDialog] = useState(false);

  return (
    <Sheet>
      <SheetTrigger>
        <Menu className="size-5 text-neutral-600 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-white xl:hidden" />
      </SheetTrigger>
      <SheetContent className="bg-background h-screen">
        <div className="p-6 flex-shrink-0 h-full flex flex-col">
          <h2 className="text-lg font-semibold mb-4 text-neutral-800 dark:text-white">
            Lounge Actions
          </h2>
          <div className="space-y-3">
            <div className="relative">
              <Popover>
                <PopoverTrigger className="w-full">
                  <Button
                    onClick={() => setIsReactionOpen(!isReactionOpen)}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    React to Lounge
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 max-w-[250px]">
                  <div className="flex gap-2 flex-wrap">
                    {REACTIONS.map(
                      (reaction: { emoji: string; label: string }) => (
                        <Button
                          key={reaction.emoji}
                          variant="ghost"
                          size="icon"
                          onClick={() => handleReaction(reaction.emoji)}
                          className="w-8 h-8 p-0 hover:bg-neutral-700"
                          title={reaction.label}
                        >
                          <span className="text-lg">{reaction.emoji}</span>
                        </Button>
                      )
                    )}
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            {canRequestToSpeak && (
              <Button
                onClick={handleRequestToSpeak}
                className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Request to Speak
              </Button>
            )}
            <Button
              onClick={() => {
                navigator.clipboard.writeText(
                  "https://whop.com/joined/bookoo-apps-developers/voice-lounge-38vFgHuUHA2kxg/app/"
                );
                toast.info("Link copied to clipboard");
              }}
              className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
            >
              <Share className="w-4 h-4 mr-2" />
              Share Space
            </Button>
            <SettingsModal
              currentUserRole={currentUserRole}
              roomId={roomId}
              whopUserData={whopUserData}
              roomDetails={roomDetails}
              localParticipant={localParticipant}
            />

            {/* Screen Share Controls - Moderator Only */}
            {canScreenShare && (
              <>
                {/* Start Screen Share Button */}
                {!screenShareActive && (
                  <Button
                    onClick={onStartScreenShare}
                    disabled={screenShareLoading}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    {screenShareLoading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <TvMinimal className="w-4 h-4 mr-2" />
                    )}
                    Share Screen
                  </Button>
                )}

                {/* Stop Sharing Button (only if current user is sharing) */}
                {isSharing && (
                  <Button
                    onClick={onStopScreenShare}
                    disabled={screenShareLoading}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    {screenShareLoading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <MonitorX className="w-4 h-4 mr-2" />
                    )}
                    Stop Sharing Screen
                  </Button>
                )}

                {/* Take Over Button (when someone else is sharing) */}
                {screenShareActive && !isSharing && (
                  <Button
                    onClick={onTakeoverScreenShare}
                    disabled={screenShareLoading}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    {screenShareLoading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <TvMinimal className="w-4 h-4 mr-2" />
                    )}
                    Take Over Screen
                  </Button>
                )}

                {/* View Participants Button - Shows when screen sharing is active */}
                {screenShareActive && (
                  <Button
                    onClick={() => setShowParticipantsDialog(true)}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    View Participants ({participantCount || 0})
                  </Button>
                )}

                {/* Error Display */}
                {screenShareError && (
                  <div className="text-red-400 text-sm px-2 py-1 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded">
                    {screenShareError}
                  </div>
                )}
              </>
            )}

            {/* Moderator-only actions */}
            {currentUserRole === "moderator" && (
              <Button
                onClick={openResetConfirmation}
                className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
              >
                <Users className="w-4 h-4 mr-2" />
                Reset All Speakers
              </Button>
            )}
          </div>
          <div className="mt-auto justify-self-end">
            <div className="text-center">
              <p className=" text-neutral-800 dark:text-white font-medium">
                Voice Lounge
              </p>
              <p className="text-xs mt-1 text-neutral-600 dark:text-neutral-400">
                Powered by{" "}
                <span className="text-neutral-800 dark:text-white">
                  Bookoo Apps
                </span>
              </p>
            </div>
          </div>
        </div>
      </SheetContent>

      {/* Participants Dialog */}
      <ParticipantsDialog
        isOpen={showParticipantsDialog}
        onClose={() => setShowParticipantsDialog(false)}
        participants={participants || []}
        currentUserRole={currentUserRole}
        currentUserId={whopUserData.whopUserId}
        roomCreatorId={roomDetails?.creatorId}
        roomId={roomId}
        onAddToSpeakers={onAddToSpeakers}
        onRemoveFromSpeakers={onRemoveFromSpeakers}
        onKickFromLounge={onKickFromLounge}
        onPromoteToModerator={onPromoteToModerator}
        onDemoteModeratorToSpeaker={onDemoteModeratorToSpeaker}
        canManageModerators={canManageModerators}
        whopCompanyId={whopUserData._id}
      />
    </Sheet>
  );
};

export default MobileLoungeSidebar;
