import { v } from "convex/values";
import { mutation, query, action } from "./_generated/server";
import { Id } from "./_generated/dataModel";
import { createLoungeEvent, EVENT_TYPES, getFirstName } from "./events";
import {
  ROOM_CATEGORIES,
  ROOM_TAGS,
  isValidCategory,
  isValidTag,
} from "./categories";
import { api } from "./_generated/api";
// no internalAction needed

// Activation buffer ratio (block new starts when available minutes are below this % of included)
const ACTIVATION_MIN_BUFFER_RATIO = 0.05; // 5%

// Private room code generation
const generateRoomCode = () => {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

// Action to generate room code for frontend
export const generateRoomCodeAction = action({
  args: {},
  handler: async () => {
    // Generate a unique 8-character room code
    const code = generateRoomCode();

    // Return the code to the frontend
    return code;
  },
});

// Delete a room and all associated data. Also attempts to delete LiveKit room by name (roomId string)
export const deleteRoom = mutation({
  args: { roomId: v.id("rooms"), requesterId: v.id("users") },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");

    const requester = await ctx.db.get(args.requesterId);
    if (!requester) throw new Error("Requester not found");

    // Auth: creator or company owner
    const company = await ctx.db.get(room.companyId);
    const isCreator = room.creatorId === args.requesterId;
    const isCompanyOwner = company?.owner === args.requesterId;
    if (!isCreator && !isCompanyOwner) {
      throw new Error("Not authorized to delete this room");
    }

    // Clean participants
    const participants = await ctx.db
      .query("participants")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const p of participants) {
      await ctx.db.delete(p._id);
    }

    // Clean reactions
    const reactions = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const r of reactions) {
      await ctx.db.delete(r._id);
    }

    // Clean reaction history
    const reactionHistory = await ctx.db
      .query("reactionHistory")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const h of reactionHistory) {
      await ctx.db.delete(h._id);
    }

    // Clean lounge events
    const events = await ctx.db
      .query("loungeEvents")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const e of events) {
      await ctx.db.delete(e._id);
    }

    // Clean invitations
    const invites = await ctx.db
      .query("invitations")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const inv of invites) {
      await ctx.db.delete(inv._id);
    }

    // Remove room from creator's registeredRooms
    const creator = await ctx.db.get(room.creatorId);
    if (creator) {
      await ctx.db.patch(room.creatorId, {
        registeredRooms: (creator.registeredRooms || []).filter(
          (id) => id !== args.roomId
        ),
      });
    }

    // Attempt to delete LiveKit room (room.name is set to roomId string in our system)
    try {
      // Run LiveKit deletion via action
      await ctx.scheduler.runAfter(0, api.livekit.deleteLiveKitRoom, {
        roomName: room._id as unknown as string,
      });
    } catch (err) {
      // Non-fatal
    }

    // Finally delete the room
    await ctx.db.delete(args.roomId);

    return { success: true };
  },
});

// Internal delete without auth.
export const internalDeleteRoom = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");

    // Clean participants
    const participants = await ctx.db
      .query("participants")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const p of participants) {
      await ctx.db.delete(p._id);
    }

    // Clean reactions
    const reactions = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const r of reactions) {
      await ctx.db.delete(r._id);
    }

    // Clean reaction history
    const reactionHistory = await ctx.db
      .query("reactionHistory")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const h of reactionHistory) {
      await ctx.db.delete(h._id);
    }

    // Clean lounge events
    const events = await ctx.db
      .query("loungeEvents")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const e of events) {
      await ctx.db.delete(e._id);
    }

    // Clean invitations
    const invites = await ctx.db
      .query("invitations")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();
    for (const inv of invites) {
      await ctx.db.delete(inv._id);
    }

    // Remove room from creator's registeredRooms
    const creator = await ctx.db.get(room.creatorId);
    if (creator) {
      await ctx.db.patch(room.creatorId, {
        registeredRooms: (creator.registeredRooms || []).filter(
          (id) => id !== args.roomId
        ),
      });
    }

    // Attempt to delete LiveKit room
    try {
      await ctx.scheduler.runAfter(0, api.livekit.deleteLiveKitRoom, {
        roomName: room._id as unknown as string,
      });
    } catch {}

    await ctx.db.delete(args.roomId);
    return { success: true };
  },
});

// Action to fetch room details for debugging
export const getRoomDetailsAction = action({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args): Promise<any> => {
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    return room;
  },
});

// Authorize via Whop and then delete via internal mutation
export const authorizeAndDeleteRoom = action({
  args: {
    roomId: v.id("rooms"),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
    isWhopAdmin: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    // Load room and related docs
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");
    if (room.creatorId === args.requesterId) {
      await ctx.runMutation(api.rooms.internalDeleteRoom, {
        roomId: args.roomId,
      });
      return { success: true };
    }

    // Load company and requester
    const company = await ctx.runQuery(api.companies.getCompanyById, {
      companyId: room.companyId,
    });
    if (!company) throw new Error("Company not found");

    const requester = await ctx.runQuery(api.users.getUser, {
      userId: args.requesterId,
    });
    if (!requester) throw new Error("Requester not found");

    // Authorization: allow if creator, company owner, or Whop company admin within same company
    const isSameCompany = room.companyId === args.requesterCompanyId;
    const isOwner = company.owner === args.requesterId;
    const isWhopAdmin = args.isWhopAdmin === true;
    if (!isSameCompany || (!isOwner && !isWhopAdmin)) {
      throw new Error("Not authorized to delete this room");
    }

    await ctx.runMutation(api.rooms.internalDeleteRoom, {
      roomId: args.roomId,
    });
    return { success: true };
  },
});

// Hash room code (server-side) for secure storage
const hashRoomCode = async (creatorId: string, code: string) => {
  const input = `${creatorId}_${code}_${process.env.PRIVATE_LOUNGE_SECRET}`;
  const encoder = new TextEncoder();
  const data = encoder.encode(input);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
};

// Create a new room
export const createRoom = mutation({
  args: {
    name: v.string(),
    description: v.string(),
    category: v.string(),
    roomImage: v.optional(v.string()),
    companyId: v.id("companies"),
    userId: v.id("users"), // Creator user ID
    isPublic: v.boolean(),
    discoverListed: v.optional(v.boolean()),
    roomCode: v.optional(v.string()), // Required for private rooms
    // Temp vs Permanent rooms
    isTemporary: v.optional(v.boolean()),
    // Auto speakers configuration
    autoSpeakersEnabled: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    // Check if user exists
    const user = await ctx.db.get(args.userId);
    if (!user) {
      throw new Error("User not found");
    }

    // Check if company has sufficient minutes before allowing creation
    const summary = await ctx.runQuery(api.plans.getCompanyUsageSummary, {
      companyId: args.companyId,
    });
    const available = summary.available || 0;
    if (available < 1) {
      throw new Error(
        "Your Whop has insufficient minutes to create a lounge. Please upgrade your plan to continue."
      );
    }

    // Validate category
    if (!isValidCategory(args.category)) {
      throw new Error(`Invalid category: ${args.category}`);
    }

    // Enforce plan-based creation policy (tier limits & admin rights)
    const plan = await ctx.runQuery(api.plans.getCompanyPlanSettings, {
      companyId: args.companyId,
    });
    const companyDoc = await ctx.db.get(args.companyId);
    const isOwner = companyDoc?.owner === args.userId;
    // In mutations we cannot call external actions; treat company owner as admin here.
    const requesterIsCompanyAdmin = false; // external admin check only available in actions
    const membersCanCreate = plan.features.allowMembersToCreateLounges === true;
    if (!isOwner && !membersCanCreate) {
      throw new Error("Members cannot create lounges for this company");
    }

    // Max saved lounges per tier (read directly from plan)
    if (plan.features.maxSavedLounges != null) {
      // != null catches both null and undefined
      const existingForCompany = await ctx.db
        .query("rooms")
        .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
        .collect();
      if (existingForCompany.length >= plan.features.maxSavedLounges) {
        throw new Error(
          `Saved lounge limit reached for your plan (max ${plan.features.maxSavedLounges})`
        );
      }
    }

    // Private room validation
    if (!args.isPublic && !args.roomCode) {
      throw new Error("Private rooms require a room code");
    }

    // Hash room code for private lounges
    let roomCodeHash: string | undefined;
    let allowedUsers: string[] | undefined;
    if (!args.isPublic && args.roomCode) {
      roomCodeHash = await hashRoomCode(args.userId, args.roomCode);
      allowedUsers = []; // Start with empty allowedUsers array
    }

    // Determine temporary vs permanent
    // Only company owner (admin) can create a permanent room
    const company = companyDoc; // reuse
    const isOwnerFinal = company?.owner === args.userId;
    const finalIsTemporary =
      args.isTemporary === false && isOwnerFinal ? false : true;

    // Enforce discover rules at create-time
    let discoverListed = false;
    if (args.discoverListed === true) {
      // Only Creator tier admin (owner) and public rooms
      if (plan.planTier !== "creator") {
        throw new Error("Discover is only available on the Creator plan");
      }
      if (!args.isPublic) {
        throw new Error("Only public rooms can be discoverable");
      }
      if (!isOwner) {
        throw new Error("Only company admins can list on Discover");
      }
      discoverListed = true;
    }

    // Create room record
    const roomId = await ctx.db.insert("rooms", {
      name: args.name,
      description: args.description,
      category: args.category,
      roomImage: args.roomImage,
      companyId: args.companyId,
      creatorId: args.userId, // Use userId as creatorId
      isPublic: args.isPublic,
      discoverListed,
      maxParticipants: 50,
      maxSpeakers: 10,
      featured: false,
      participantCount: 0,
      maxParticipantsEverReached: 0,
      lastActivityAt: Date.now(),
      isActive: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      // Private room fields
      roomCodeHash: roomCodeHash,
      allowedUsers: allowedUsers,
      // Temporary vs permanent rooms
      isTemporary: finalIsTemporary,
      // Auto speakers configuration
      autoSpeakersEnabled: args.autoSpeakersEnabled,
    });

    // Register room to user's collection
    const currentRegisteredRooms = user.registeredRooms || [];
    await ctx.db.patch(args.userId, {
      registeredRooms: [...currentRegisteredRooms, roomId],
      updatedAt: Date.now(),
    });

    // Create event for lounge started (skip if moderator is anonymous)
    if (!user.isAnonymous) {
      await createLoungeEvent(ctx, {
        roomId,
        eventType: EVENT_TYPES.LOUNGE_STARTED,
        userId: args.userId,
        eventData: {
          moderatorName: getFirstName(user.fullName),
        },
      });
    }

    return roomId;
  },
});

// Toggle discover listing on a room (Creator tier, admin-only, public rooms only)
export const setDiscoverListed = mutation({
  args: {
    roomId: v.id("rooms"),
    requesterId: v.id("users"),
    enabled: v.boolean(),
  },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");
    const company = await ctx.db.get(room.companyId);
    if (!company) throw new Error("Company not found");
    const requesterIsOwner = company.owner === args.requesterId;

    // Plan & policy checks
    const plan = await ctx.runQuery(api.plans.getCompanyPlanSettings, {
      companyId: room.companyId,
    });
    if (plan.planTier !== "creator") {
      throw new Error("Discover is only available on the Creator plan");
    }
    if (!requesterIsOwner) {
      throw new Error("Only company admins can change discover listing");
    }
    if (args.enabled && !room.isPublic) {
      throw new Error("Only public rooms can be discoverable");
    }

    await ctx.db.patch(args.roomId, {
      discoverListed: args.enabled,
      updatedAt: Date.now(),
    });
    return { success: true, discoverListed: args.enabled };
  },
});

// Toggle discover status from lounge card (company admin only, creator tier)
export const toggleDiscoverStatus = mutation({
  args: {
    roomId: v.id("rooms"),
    requesterId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");

    // Check if requester is company admin (not just room creator)
    const company = await ctx.db.get(room.companyId);
    if (!company) throw new Error("Company not found");
    const requesterIsCompanyAdmin = company.owner === args.requesterId;

    if (!requesterIsCompanyAdmin) {
      throw new Error("Only company admins can toggle discover status");
    }

    // Check if room is public
    if (!room.isPublic) {
      throw new Error("Only public rooms can be discoverable");
    }

    // Check company plan tier
    const plan = await ctx.runQuery(api.plans.getCompanyPlanSettings, {
      companyId: room.companyId,
    });
    if (plan.planTier !== "creator") {
      throw new Error("Discover is only available on the Creator plan");
    }

    // Toggle the discover status
    const newDiscoverStatus = !room.discoverListed;

    await ctx.db.patch(args.roomId, {
      discoverListed: newDiscoverStatus,
      updatedAt: Date.now(),
    });

    return {
      success: true,
      discoverListed: newDiscoverStatus,
      message: newDiscoverStatus
        ? "Lounge is now discoverable in explore page! 🎉"
        : "Lounge is now hidden from explore page",
    };
  },
});

// TODO: Generate room code for private lounges (called from form)
// export const generateRoomCodeAction = action({
//   args: {},
//   handler: async (ctx) => {
//     const code = generateRoomCode();
//     console.log(`Generated room code: ${code}`);
//     return code;
//   },
// });

// Get all active rooms
export const listActiveRooms = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("rooms")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .order("desc")
      .collect();
  },
});

// Get active room for a specific company (only one allowed)
export const getActiveRoomForCompany = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("rooms")
      .withIndex("by_company_and_active", (q) =>
        q.eq("companyId", args.companyId).eq("isActive", true)
      )
      .first();
  },
});

// Get any room for company (active or inactive)
export const getAnyRoomForCompany = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("rooms")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .first();
  },
});

// Get a specific room
export const getRoom = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.roomId);
  },
});

// Get room data for join page
export const getRoomForJoin = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) return null;

    const creator = await ctx.db.get(room.creatorId);

    return {
      id: room._id,
      name: room.name,
      description: room.description,
      category: room.category,
      roomImage: room.roomImage,
      creatorId: room.creatorId,
      creatorName: creator?.fullName || creator?.whopUsername || "Unknown",
      isPublic: room.isPublic,
      isActive: room.isActive,
      participantCount: room.participantCount,
      maxParticipants: room.maxParticipants,
      createdAt: room.createdAt,
    };
  },
});

// Get rooms created by a specific user
export const getRoomsByUser = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("rooms")
      .withIndex("by_creator", (q) => q.eq("creatorId", args.userId))
      .order("desc")
      .collect();
  },
});

// Update room
export const updateRoom = mutation({
  args: {
    roomId: v.id("rooms"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    maxParticipants: v.optional(v.number()),
    settings: v.optional(
      v.object({
        allowListeners: v.optional(v.boolean()),
        requireApproval: v.optional(v.boolean()),
        recordingEnabled: v.optional(v.boolean()),
        chatEnabled: v.optional(v.boolean()),
      })
    ),
  },
  handler: async (ctx, args) => {
    const { roomId, ...updates } = args;
    return await ctx.db.patch(roomId, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

// Update room settings
export const updateRoomSettings = mutation({
  args: {
    roomId: v.id("rooms"),
    name: v.optional(v.string()),
    maxParticipants: v.optional(v.number()),
    maxSpeakers: v.optional(v.number()),
    autoSpeakersEnabled: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { roomId, ...updates } = args;

    // Get current room data to check if name is changing
    const currentRoom = await ctx.db.get(roomId);
    if (!currentRoom) {
      throw new Error("Room not found");
    }

    // Validate inputs
    if (updates.maxParticipants !== undefined) {
      if (updates.maxParticipants < 5 || updates.maxParticipants > 100) {
        throw new Error("Max participants must be between 5 and 100");
      }
    }

    if (updates.maxSpeakers !== undefined) {
      if (updates.maxSpeakers < 1 || updates.maxSpeakers > 20) {
        throw new Error("Max speakers must be between 1 and 20");
      }
    }

    if (updates.name !== undefined) {
      if (updates.name.trim().length === 0) {
        throw new Error("Room name cannot be empty");
      }
      if (updates.name.length > 50) {
        throw new Error("Room name must be 50 characters or less");
      }
    }

    // Update the room
    await ctx.db.patch(roomId, {
      ...updates,
      updatedAt: Date.now(),
    });

    // Create event for room name change
    if (updates.name !== undefined && updates.name !== currentRoom.name) {
      await createLoungeEvent(ctx, {
        roomId,
        eventType: EVENT_TYPES.ROOM_RENAMED,
        eventData: {
          oldRoomName: currentRoom.name,
          newRoomName: updates.name,
        },
      });
    }

    return roomId;
  },
});

// Activate an inactive room after minutes preflight
type ActivateRoomResult =
  | { ok: true; alreadyActive?: boolean }
  | {
      ok: false;
      reason: "room_not_found" | "minutes_exhausted";
      available?: number;
      minRequired?: number;
      included?: number;
    };

export const activateRoom: any = mutation({
  args: { roomId: v.id("rooms"), requesterId: v.id("users") },
  handler: async (ctx, args): Promise<ActivateRoomResult> => {
    const room = await ctx.db.get(args.roomId);
    if (!room) return { ok: false as const, reason: "room_not_found" as const };
    if (room.isActive) return { ok: true as const, alreadyActive: true };

    // Minutes preflight
    const summary = (await ctx.runQuery(api.plans.getCompanyUsageSummary, {
      companyId: room.companyId,
    })) as {
      used: number;
      included: number;
      creditsRemainingTotal: number;
      available: number;
      renewalAt: number;
    };
    const included = summary.included || 0;
    const available: number = summary.available || 0;
    const minRequired = Math.ceil(included * ACTIVATION_MIN_BUFFER_RATIO);
    if (available <= minRequired) {
      return {
        ok: false as const,
        reason: "minutes_exhausted" as const,
        available,
        minRequired,
        included,
      };
    }

    await ctx.db.patch(args.roomId, {
      isActive: true,
      lastActivityAt: Date.now(),
      updatedAt: Date.now(),
    });

    return { ok: true as const };
  },
});

// Deactivate room and delete all participants
export const deactivateRoom = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    // First, delete all participants in this room
    const participants = await ctx.db
      .query("participants")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    // Delete each participant
    for (const participant of participants) {
      await ctx.db.delete(participant._id);
    }

    // Clean up all reactions for this room
    const roomReactions = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    // Delete all reactions for this room
    for (const reaction of roomReactions) {
      await ctx.db.delete(reaction._id);
    }

    // Clean up all reaction history for this room
    const roomReactionHistory = await ctx.db
      .query("reactionHistory")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    // Delete all reaction history for this room
    for (const historyItem of roomReactionHistory) {
      await ctx.db.delete(historyItem._id);
    }

    // Clean up all lounge events for this room
    const roomEvents = await ctx.db
      .query("loungeEvents")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .collect();

    // Delete all lounge events for this room
    for (const event of roomEvents) {
      await ctx.db.delete(event._id);
    }

    // Then deactivate the room
    return await ctx.db.patch(args.roomId, {
      isActive: false,
      updatedAt: Date.now(),
    });
  },
});

// Reactivate room (set back to active) with minute checks
export const reactivateRoom = mutation({
  args: { roomId: v.id("rooms"), requesterId: v.id("users") },
  handler: async (ctx, args): Promise<ActivateRoomResult> => {
    const room = await ctx.db.get(args.roomId);
    if (!room) return { ok: false as const, reason: "room_not_found" as const };
    if (room.isActive) return { ok: true as const, alreadyActive: true };

    // Minutes preflight (same as activateRoom)
    const summary = (await ctx.runQuery(api.plans.getCompanyUsageSummary, {
      companyId: room.companyId,
    })) as {
      used: number;
      included: number;
      creditsRemainingTotal: number;
      available: number;
      renewalAt: number;
    };
    const included = summary.included || 0;
    const available: number = summary.available || 0;
    const minRequired = Math.ceil(included * ACTIVATION_MIN_BUFFER_RATIO);
    if (available <= minRequired) {
      return {
        ok: false as const,
        reason: "minutes_exhausted" as const,
        available,
        minRequired,
        included,
      };
    }

    await ctx.db.patch(args.roomId, {
      isActive: true,
      lastActivityAt: Date.now(),
      updatedAt: Date.now(),
    });

    return { ok: true as const };
  },
});

// Shutdown room due to minute exhaustion
export const shutdownRoomForMinutes = mutation({
  args: {
    roomId: v.id("rooms"),
    reason: v.string(),
  },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) {
      console.log(`Cannot shutdown room ${args.roomId}: room not found`);
      return { success: false, reason: "room_not_found" };
    }

    if (!room.isActive) {
      console.log(`Room ${args.roomId} is already inactive`);
      return { success: true, reason: "already_inactive" };
    }

    console.log(
      `🚨 SHUTTING DOWN ROOM: ${room.name} (${args.roomId}) - ${args.reason}`
    );

    try {
      // 1. Stop all participant billing timers by calling stopParticipantBilling for each participant
      const participants = await ctx.db
        .query("participants")
        .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
        .collect();

      for (const participant of participants) {
        try {
          await ctx.runMutation(api.participantBilling.stopParticipantBilling, {
            participantId: participant._id,
          });
        } catch (error) {
          console.error(
            `Failed to stop billing for participant ${participant._id}:`,
            error
          );
          // Continue with shutdown even if individual billing stops fail
        }
      }

      // 2. Use existing deactivateRoom logic to clean up participants, reactions, events
      await ctx.runMutation(api.rooms.deactivateRoom, {
        roomId: args.roomId,
      });

      // 3. Add shutdown reason to room record
      await ctx.db.patch(args.roomId, {
        shutdownReason: args.reason,
        shutdownAt: Date.now(),
        updatedAt: Date.now(),
      });

      console.log(
        `✅ Room ${args.roomId} successfully shutdown due to ${args.reason}`
      );
      return { success: true, reason: args.reason };
    } catch (error) {
      console.error(`❌ Failed to shutdown room ${args.roomId}:`, error);
      return { success: false, error: String(error) };
    }
  },
});

// Ban a user from a room
export const banUserFromRoom = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const { roomId, userId } = args;

    // Get the current room
    const room = await ctx.db.get(roomId);
    if (!room) {
      throw new Error("Room not found");
    }

    // Get current banned users or initialize empty array
    const currentBannedUsers = room.bannedUsers || [];

    // Check if user is already banned
    if (currentBannedUsers.includes(userId)) {
      throw new Error("User is already banned from this room");
    }

    // Get user info for event
    const user = await ctx.db.get(userId);
    if (!user) {
      throw new Error("User not found");
    }

    // Add user to banned list
    const updatedBannedUsers = [...currentBannedUsers, userId];

    // Update the room with new banned users list
    await ctx.db.patch(roomId, {
      bannedUsers: updatedBannedUsers,
      updatedAt: Date.now(),
    });

    // Create event for user ban (skip if user is anonymous)
    if (!user.isAnonymous) {
      await createLoungeEvent(ctx, {
        roomId,
        eventType: EVENT_TYPES.USER_BANNED,
        targetUserId: userId,
        eventData: {
          targetUserName: getFirstName(user.fullName),
        },
      });
    }

    return { success: true, bannedUsers: updatedBannedUsers };
  },
});

// Check if a user is banned from a room
export const isUserBannedFromRoom = query({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const { roomId, userId } = args;

    const room = await ctx.db.get(roomId);
    if (!room) {
      return false; // Room doesn't exist, so user can't be banned
    }

    const bannedUsers = room.bannedUsers || [];
    return bannedUsers.includes(userId);
  },
});

// Get banned users for a room
export const getBannedUsersForRoom = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const { roomId } = args;

    const room = await ctx.db.get(roomId);
    if (!room) {
      return [];
    }

    const bannedUserIds = room.bannedUsers || [];

    // Get user details for each banned user ID
    const bannedUsers = [];
    for (const userId of bannedUserIds) {
      const user = await ctx.db.get(userId);
      if (user) {
        bannedUsers.push(user);
      }
    }

    return bannedUsers;
  },
});

// Unban a specific user from a room
export const unbanUserFromRoom = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const { roomId, userId } = args;

    const room = await ctx.db.get(roomId);
    if (!room) {
      throw new Error("Room not found");
    }

    const currentBannedUsers = room.bannedUsers || [];

    // Remove user from banned list
    const updatedBannedUsers = currentBannedUsers.filter((id) => id !== userId);

    // Update the room
    await ctx.db.patch(roomId, {
      bannedUsers: updatedBannedUsers,
      updatedAt: Date.now(),
    });

    return { success: true, bannedUsers: updatedBannedUsers };
  },
});

// Unban all users from a room
export const unbanAllUsersFromRoom = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    const { roomId } = args;

    const room = await ctx.db.get(roomId);
    if (!room) {
      throw new Error("Room not found");
    }

    // Clear all banned users
    await ctx.db.patch(roomId, {
      bannedUsers: [],
      updatedAt: Date.now(),
    });

    return { success: true, bannedUsers: [] };
  },
});

// Secure ban/unban actions
export const authorizeAndBanUser = action({
  args: {
    roomId: v.id("rooms"),
    targetUserId: v.id("users"),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
  },
  handler: async (ctx, args) => {
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");
    const isCreator = room.creatorId === args.requesterId;
    const isSameCompany = room.companyId === args.requesterCompanyId;

    const company = await ctx.runQuery(api.companies.getCompanyById, {
      companyId: room.companyId,
    });
    const requester = await ctx.runQuery(api.users.getUser, {
      userId: args.requesterId,
    });
    const target = await ctx.runQuery(api.users.getUser, {
      userId: args.targetUserId,
    });

    let requesterIsCompanyAdmin = false;
    let targetIsCompanyAdmin = false;
    if (company?.whopCompanyId) {
      try {
        if (requester?.whopUserId) {
          const resReq = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
            whopUserId: requester.whopUserId,
            whopCompanyId: company.whopCompanyId,
          });
          requesterIsCompanyAdmin = resReq?.isAdmin === true && isSameCompany;
        }
        if (target?.whopUserId) {
          const resTgt = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
            whopUserId: target.whopUserId,
            whopCompanyId: company.whopCompanyId,
          });
          targetIsCompanyAdmin = resTgt?.isAdmin === true;
        }
      } catch {}
    }

    if (room.creatorId === args.targetUserId) {
      throw new Error("Cannot ban the lounge creator");
    }
    if (targetIsCompanyAdmin) {
      throw new Error("Cannot ban a company admin");
    }
    if (!(isCreator || requesterIsCompanyAdmin)) {
      throw new Error("Not authorized to ban users");
    }

    await ctx.runMutation(api.rooms.banUserFromRoom, {
      roomId: args.roomId,
      userId: args.targetUserId,
    });
    return { success: true };
  },
});

export const authorizeAndUnbanUser = action({
  args: {
    roomId: v.id("rooms"),
    targetUserId: v.id("users"),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
  },
  handler: async (ctx, args) => {
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");
    const isCreator = room.creatorId === args.requesterId;
    const isSameCompany = room.companyId === args.requesterCompanyId;

    const company = await ctx.runQuery(api.companies.getCompanyById, {
      companyId: room.companyId,
    });
    const requester = await ctx.runQuery(api.users.getUser, {
      userId: args.requesterId,
    });
    let requesterIsCompanyAdmin = false;
    try {
      if (company?.whopCompanyId && requester?.whopUserId) {
        const resReq = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
          whopUserId: requester.whopUserId,
          whopCompanyId: company.whopCompanyId,
        });
        requesterIsCompanyAdmin = resReq?.isAdmin === true && isSameCompany;
      }
    } catch {}

    if (!(isCreator || requesterIsCompanyAdmin)) {
      throw new Error("Not authorized to unban users");
    }

    await ctx.runMutation(api.rooms.unbanUserFromRoom, {
      roomId: args.roomId,
      userId: args.targetUserId,
    });
    return { success: true };
  },
});

// Get all rooms
export const getAllRooms = query({
  handler: async (ctx) => {
    return await ctx.db.query("rooms").collect();
  },
});

// Get active rooms for testing
export const getActiveRoomsForTest = query({
  handler: async (ctx) => {
    return await ctx.db
      .query("rooms")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .collect();
  },
});

// Get rooms by company
export const getRoomsByCompany = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("rooms")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();
  },
});

// Create an invitation for a private lounge
export const createInvite = mutation({
  args: {
    roomId: v.id("rooms"),
    inviterId: v.id("users"),
    inviteeWhopUsername: v.string(),
  },
  handler: async (ctx, args) => {
    const room = await ctx.db.get(args.roomId);
    if (!room) return { ok: false as const, reason: "room_not_found" as const };
    if (room.isPublic)
      return { ok: false as const, reason: "not_private" as const };

    // Permission: only creator can invite for now
    if (room.creatorId !== args.inviterId) {
      return { ok: false as const, reason: "not_creator" as const };
    }

    // If invitee already has access (allow-list or is creator), block invite
    const inviteeUsername = args.inviteeWhopUsername;
    const creatorUser = await ctx.db.get(room.creatorId);
    const alreadyAllowed = (room.allowedUsers || []).includes(inviteeUsername);
    const isCreatorUser = creatorUser?.whopUsername === inviteeUsername;
    if (alreadyAllowed || isCreatorUser) {
      return { ok: false as const, reason: "already_allowed" as const };
    }

    // Prevent duplicate pending invite to same whop user for this room
    const existing = await ctx.db
      .query("invitations")
      .withIndex("by_room_and_invitee", (q) =>
        q
          .eq("roomId", args.roomId)
          .eq("inviteeWhopUsername", args.inviteeWhopUsername)
      )
      .first();

    if (existing && existing.status === "pending") {
      return { ok: true as const, invitationId: existing._id };
    }

    const invitationId = await ctx.db.insert("invitations", {
      roomId: args.roomId,
      inviterId: args.inviterId,
      inviteeWhopUsername: args.inviteeWhopUsername,
      status: "pending",
      createdAt: Date.now(),
    });

    // Fire-and-forget: send a DM to the invitee with room name and link
    try {
      const inviter = await ctx.db.get(args.inviterId);
      const company = await ctx.db.get(room.companyId);
      const inviterWhopUsername = inviter?.whopUsername || undefined;
      const inviterWhopUserId = inviter?.whopUserId || undefined;
      const experienceId = company?.whopExperienceId || "";
      if (experienceId) {
        await ctx.scheduler.runAfter(0, api.whop.sendInviteDm, {
          inviteeWhopUsername: args.inviteeWhopUsername,
          inviterWhopUsername,
          inviterWhopUserId,
          roomName: room.name,
          experienceId,
          roomId: args.roomId,
          whopCompanyId: company?.whopCompanyId,
          companyName: company?.name,
        });
      }
    } catch (err) {
      // Non-fatal if DM fails
    }

    return { ok: true as const, invitationId };
  },
});

// List pending invitations for a whop user
export const getInvitesForWhopUser = query({
  args: { inviteeWhopUsername: v.string() },
  handler: async (ctx, args) => {
    const invites = await ctx.db
      .query("invitations")
      .withIndex("by_invitee", (q) =>
        q.eq("inviteeWhopUsername", args.inviteeWhopUsername)
      )
      .collect();

    // Only return pending invites
    const pendingInvites = invites.filter((i) => i.status === "pending");

    // Enrich with room and inviter minimal info
    const enriched = await Promise.all(
      pendingInvites.map(async (inv) => {
        const room = await ctx.db.get(inv.roomId);
        const inviter = await ctx.db.get(inv.inviterId);
        return {
          ...inv,
          room: room
            ? {
                _id: room._id,
                name: room.name,
                companyId: room.companyId,
                isPublic: room.isPublic,
              }
            : null,
          inviter: inviter
            ? {
                _id: inviter._id,
                fullName: inviter.fullName,
                whopUsername: inviter.whopUsername,
              }
            : null,
        };
      })
    );

    return enriched;
  },
});

// Accept an invitation: adds the user to allowedUsers and marks invite accepted
export const acceptInvite = mutation({
  args: {
    inviteId: v.id("invitations"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const invite = await ctx.db.get(args.inviteId);
    if (!invite) throw new Error("Invitation not found");
    if (invite.status !== "pending")
      throw new Error("Invitation is not pending");

    const user = await ctx.db.get(args.userId);
    if (!user) throw new Error("User not found");
    if (user.whopUsername !== invite.inviteeWhopUsername) {
      throw new Error("This invitation was not addressed to the current user");
    }

    const room = await ctx.db.get(invite.roomId);
    if (!room) throw new Error("Room not found");
    if (room.isPublic)
      throw new Error("Invitation applies only to private lounges");

    const currentAllowed = Array.isArray(room.allowedUsers)
      ? room.allowedUsers
      : [];
    const alreadyAllowed = currentAllowed.includes(user.whopUsername);
    if (!alreadyAllowed) {
      await ctx.db.patch(invite.roomId, {
        allowedUsers: [...currentAllowed, user.whopUsername],
        updatedAt: Date.now(),
      });
    }

    // Remove the invite after successful accept to save space
    await ctx.db.delete(args.inviteId);
    return { roomId: invite.roomId };
  },
});

// Decline an invitation
export const declineInvite = mutation({
  args: {
    inviteId: v.id("invitations"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const invite = await ctx.db.get(args.inviteId);
    if (!invite) throw new Error("Invitation not found");

    const user = await ctx.db.get(args.userId);
    if (!user) throw new Error("User not found");
    if (user.whopUsername !== invite.inviteeWhopUsername) {
      throw new Error("This invitation was not addressed to the current user");
    }

    // Delete the invite to remove it entirely
    await ctx.db.delete(args.inviteId);
    return { success: true };
  },
});

// Revoke an invitation (inviter or room creator only)
export const revokeInvite = mutation({
  args: {
    inviteId: v.id("invitations"),
    inviterId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const invite = await ctx.db.get(args.inviteId);
    if (!invite) throw new Error("Invitation not found");

    const room = await ctx.db.get(invite.roomId);
    if (!room) throw new Error("Room not found");
    if (
      invite.inviterId !== args.inviterId &&
      room.creatorId !== args.inviterId
    ) {
      throw new Error("Not authorized to revoke this invitation");
    }

    if (invite.status === "pending") {
      await ctx.db.patch(args.inviteId, { status: "revoked" });
    }
    return { success: true };
  },
});

// Pending invite count for a whop user (for navbar badge)
export const getPendingInviteCount = query({
  args: { inviteeWhopUsername: v.string() },
  handler: async (ctx, args) => {
    const invites = await ctx.db
      .query("invitations")
      .withIndex("by_invitee", (q) =>
        q.eq("inviteeWhopUsername", args.inviteeWhopUsername)
      )
      .collect();
    const count = invites.filter((i) => i.status === "pending").length;
    return { count };
  },
});

// Reset all speakers to listeners
export const resetAllSpeakers = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    // Authorization: only creator or same-company company admin can reset
    const room = await ctx.db.get(args.roomId);
    if (!room) throw new Error("Room not found");

    // Find all speakers in this room
    const speakers = await ctx.db
      .query("participants")
      .withIndex("by_room", (q) => q.eq("roomId", args.roomId))
      .filter((q) => q.eq(q.field("role"), "speaker"))
      .collect();

    // Update all speakers to listeners
    for (const speaker of speakers) {
      await ctx.db.patch(speaker._id, {
        role: "listener",
        isMuted: true,
      });

      // Revoke LiveKit publish permission for each demoted user
      try {
        const user = await ctx.db.get(speaker.userId);
        if (user?.whopUserId) {
          await ctx.scheduler.runAfter(
            0,
            api.livekit.setParticipantPublishPermission,
            {
              roomName: args.roomId as unknown as string,
              participantIdentity: user.whopUserId,
              canPublish: false,
            }
          );
        }
      } catch {}
    }

    return speakers.length;
  },
});

// Authorize via Whop and requester role, then reset all speakers
export const authorizeAndResetSpeakers = action({
  args: {
    roomId: v.id("rooms"),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
  },
  handler: async (ctx, args): Promise<number> => {
    // Load room and related docs
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");

    const isCreator = room.creatorId === args.requesterId;
    const isSameCompany = room.companyId === args.requesterCompanyId;

    const company = await ctx.runQuery(api.companies.getCompanyById, {
      companyId: room.companyId,
    });
    const requester = await ctx.runQuery(api.users.getUser, {
      userId: args.requesterId,
    });

    let requesterIsCompanyAdmin = false;
    try {
      if (company?.whopCompanyId && requester?.whopUserId) {
        const res = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
          whopUserId: requester.whopUserId,
          whopCompanyId: company.whopCompanyId,
        });
        requesterIsCompanyAdmin = res?.isAdmin === true && isSameCompany;
      }
    } catch {
      requesterIsCompanyAdmin = false;
    }

    if (!(isCreator || requesterIsCompanyAdmin)) {
      throw new Error("Not authorized to reset speakers");
    }

    const count: number = await ctx.runMutation(api.rooms.resetAllSpeakers, {
      roomId: args.roomId,
    });

    return count;
  },
});

// ===== DISCOVER PAGE FUNCTIONS =====

// Get room categories for discover page
export const getRoomCategories = query({
  handler: async (ctx) => {
    return ROOM_CATEGORIES;
  },
});

// Get room tags for discover page
export const getRoomTags = query({
  handler: async (ctx) => {
    return ROOM_TAGS;
  },
});

// Get discoverable rooms with filters
export const getDiscoverableRooms = query({
  args: {
    category: v.optional(v.string()),
    status: v.optional(
      v.union(v.literal("active"), v.literal("inactive"), v.literal("all"))
    ),
    search: v.optional(v.string()),
    limit: v.optional(v.number()),
    offset: v.optional(v.number()),
    featured: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const {
      category,
      status = "all",
      search,
      limit = 20,
      offset = 0,
      featured,
    } = args;

    // Start with base query for public active rooms
    let rooms = await ctx.db
      .query("rooms")
      .withIndex("by_public_and_active", (q) =>
        q.eq("isPublic", true).eq("isActive", true)
      )
      .collect();

    // Apply category filter
    if (category && isValidCategory(category)) {
      rooms = rooms.filter((room) => room.category === category);
    }

    // Apply featured filter
    if (featured !== undefined) {
      rooms = rooms.filter((room) => room.featured === featured);
    }

    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      rooms = rooms.filter(
        (room) =>
          room.name.toLowerCase().includes(searchLower) ||
          (room.description &&
            room.description.toLowerCase().includes(searchLower))
      );
    }

    // Apply status filter
    if (status !== "all") {
      const isActive = status === "active";
      rooms = rooms.filter((room) => room.isActive === isActive);
    }

    // Sort by featured first, then by last activity
    rooms.sort((a, b) => {
      // Featured rooms first
      if (a.featured && !b.featured) return -1;
      if (!a.featured && b.featured) return 1;

      // Then by last activity (newest first)
      const aActivity = a.lastActivityAt || a.createdAt;
      const bActivity = b.lastActivityAt || b.createdAt;
      return bActivity - aActivity;
    });

    // Apply pagination
    const paginatedRooms = rooms.slice(offset, offset + limit);

    return {
      rooms: paginatedRooms,
      total: rooms.length,
      hasMore: offset + limit < rooms.length,
    };
  },
});

// Get discover page statistics
export const getDiscoverStats = query({
  handler: async (ctx) => {
    // Get total public rooms
    const totalPublicRooms = await ctx.db
      .query("rooms")
      .withIndex("by_public_and_active", (q) =>
        q.eq("isPublic", true).eq("isActive", true)
      )
      .collect();

    // Get featured rooms count
    const featuredRooms = totalPublicRooms.filter((room) => room.featured);

    // Get rooms by category
    const categoryStats = ROOM_CATEGORIES.map((category) => ({
      category: category.id,
      name: category.name,
      count: totalPublicRooms.filter((room) => room.category === category.id)
        .length,
    }));

    // Get total participants across all public rooms
    const totalParticipants = totalPublicRooms.reduce(
      (sum, room) => sum + (room.participantCount || 0),
      0
    );

    return {
      totalRooms: totalPublicRooms.length,
      featuredRooms: featuredRooms.length,
      totalParticipants,
      categoryStats,
    };
  },
});

// Update room metadata for discover page
export const updateRoomMetadata = mutation({
  args: {
    roomId: v.id("rooms"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    category: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    isPublic: v.optional(v.boolean()),
    roomImage: v.optional(v.string()),
    featured: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { roomId, ...updates } = args;

    // Validate category if provided
    if (updates.category && !isValidCategory(updates.category)) {
      throw new Error(`Invalid category: ${updates.category}`);
    }

    // Validate tags if provided
    if (updates.tags) {
      for (const tag of updates.tags) {
        if (!isValidTag(tag)) {
          throw new Error(`Invalid tag: ${tag}`);
        }
      }
    }

    // Update the room
    await ctx.db.patch(roomId, {
      ...updates,
      updatedAt: Date.now(),
    });

    return { success: true };
  },
});

// Update room participant count
export const updateParticipantCount = mutation({
  args: {
    roomId: v.id("rooms"),
    count: v.number(),
  },
  handler: async (ctx, args) => {
    const { roomId, count } = args;

    // Get current room to check if we need to update max participants
    const room = await ctx.db.get(roomId);
    if (!room) return { success: false, error: "Room not found" };

    const currentMax = room.maxParticipantsEverReached || 0;
    const newMax = Math.max(currentMax, count);

    await ctx.db.patch(roomId, {
      participantCount: count,
      maxParticipantsEverReached: newMax,
      lastActivityAt: Date.now(),
      updatedAt: Date.now(),
    });

    return { success: true };
  },
});

// Update room last activity
export const updateRoomActivity = mutation({
  args: {
    roomId: v.id("rooms"),
  },
  handler: async (ctx, args) => {
    const { roomId } = args;

    await ctx.db.patch(roomId, {
      lastActivityAt: Date.now(),
      updatedAt: Date.now(),
    });

    return { success: true };
  },
});

// Update room code for private rooms
export const updateRoomCode = mutation({
  args: {
    roomId: v.id("rooms"),
    newRoomCode: v.string(),
  },
  handler: async (ctx, args) => {
    const { roomId, newRoomCode } = args;

    // Get current room
    const room = await ctx.db.get(roomId);
    if (!room) {
      throw new Error("Room not found");
    }

    // Verify room is private
    if (room.isPublic) {
      throw new Error("Cannot update code for public rooms");
    }

    // Verify user is the creator (you may need to pass userId and verify)
    // For now, we'll assume the mutation is only called by authorized users

    // Hash the new room code
    const newRoomCodeHash = await hashRoomCode(room.creatorId, newRoomCode);

    // Update room with new code hash and clear allowed users
    await ctx.db.patch(roomId, {
      roomCodeHash: newRoomCodeHash,
      allowedUsers: [], // Clear existing allowed users since code changed
    });

    // Create a room event for the code change
    await createLoungeEvent(ctx, {
      roomId: roomId,
      eventType: EVENT_TYPES.ROOM_CODE_UPDATED,
      userId: room.creatorId,
      eventData: {
        newRoomName: room.name, // Using existing field
        moderatorName: "Room Creator",
      },
    });

    return { success: true };
  },
});
