import { headers } from "next/headers";
import {
  verifyUserToken,
  getUserInfo,
  getExperienceInfo,
  getUserCompanyAccess,
  getCompanyLogoForExperience,
} from "@/whop/server/sdk";
import { LoungeBrowseClient } from "./browse-client";
import LoadingScreen from "@/app/components/shared/loading-screen";

export default async function BrowsePage({
  params,
}: {
  params: Promise<{ experienceId: string }>;
}) {
  const { experienceId } = await params;
  console.log("experienceId", experienceId);
  const headersList = await headers();
  const userToken = headersList.get("x-whop-user-token");

  if (!userToken) {
    return (
      <div className="min-h-screen w-full">
        <LoadingScreen
          message="Please open this app from your Whop experience so we can verify your account."
          error={true}
        />
      </div>
    );
  }

  const verification = await verifyUserToken();

  if (verification.error || (verification.success && !verification.userId)) {
    return (
      <div className="min-h-screen w-full grid place-items-center">
        <LoadingScreen
          message="Could not verify your account. Please opening this app from your Whop experience again."
          error={true}
        />
      </div>
    );
  }

  const whopUserId = verification.userId!;
  const userInfo = await getUserInfo(whopUserId);

  if (!userInfo.success || !userInfo.user) {
    return (
      <div className="min-h-screen w-full">
        <LoadingScreen
          message="Could not fetch your user information. Please try again."
          error={true}
        />
      </div>
    );
  }

  const experienceInfo = await getExperienceInfo(experienceId);
  if (!experienceInfo.success || !experienceInfo.experience) {
    return (
      <div className="min-h-screen w-full">
        <LoadingScreen
          message="Could not fetch experience information. Please check configuration."
          error={true}
        />
      </div>
    );
  }

  const whopCompanyId = experienceInfo.experience.company.id;
  const companyName = experienceInfo.experience.company.title;

  const access = await getUserCompanyAccess(whopUserId, whopCompanyId);
  const whopAccessLevel =
    access.success && access.access?.accessLevel
      ? access.access.accessLevel
      : null;

  const whopUsername = userInfo.user.username;
  const fullName = userInfo.user.name || "";
  const avatarUrl = userInfo.user.profilePicture?.sourceUrl || "";

  const logoRes = await getCompanyLogoForExperience(experienceId);

  if (logoRes.success || logoRes.error) {
    return (
      <LoungeBrowseClient
        whopUserId={whopUserId}
        whopUsername={whopUsername}
        fullName={fullName}
        avatarUrl={avatarUrl}
        whopCompanyId={whopCompanyId}
        whopExperienceId={experienceId}
        companyName={companyName}
        companyLogo={"/images/whop-logo.png"}
        whopAccessLevel={whopAccessLevel}
      />
    );
  }
}
