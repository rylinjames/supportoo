import { v } from "convex/values";
import { query } from "./_generated/server";
import { Id } from "./_generated/dataModel";

export const getActivePromo = query({
  args: {
    companyId: v.id("companies"),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId);
    if (!company) {
      return null;
    }

    // Only show promo to company owners/admins
    const isCompanyOwner = company.owner === args.userId;
    if (!isCompanyOwner) {
      return null;
    }

    // Get company's current plan
    const plan = company.planTier ? await ctx.db.get(company.planTier) : null;
    const currentTier = plan?.tier || "free";

    // Only show promo to free tier companies
    if (currentTier !== "free") {
      return null;
    }

    // Return active promo data
    return {
      id: "creator_launch_discount",
      title: "Unlock Voice Lounge Creator",
      subtitle: "Scale your community with unlimited voice rooms",
      discountCode: "VOICELAUNCH",
      discountPercent: 100,
      targetTier: "creator",
      benefits: [
        "Create unlimited voice lounges for your community",
        "Get your lounges featured on the explore page",
        "Tons of minutes - never worry about running out",
      ],
      urgency: "Limited time launch offer",
      cta: {
        primary: "Claim Free Month",
        secondary: "Maybe Later",
      },
      // Promo expires in 30 days (can be updated easily)
      expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
    };
  },
});

/**
 * Get promo for plans page pre-selection
 * Used when user clicks "Claim Discount" to highlight the target tier
 */
export const getPromoForPlans = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const company = await ctx.db.get(args.companyId);
    if (!company) return null;

    const plan = company.planTier ? await ctx.db.get(company.planTier) : null;
    const currentTier = plan?.tier || "free";

    // Only return promo info for free tier users
    if (currentTier !== "free") return null;

    return {
      targetTier: "creator",
      discountCode: "VOICELAUNCH",
      discountPercent: 100,
      highlightMessage: "🎉 Free Month Applied!",
    };
  },
});
