"use client";

import { LoungeOnboarding } from "@/app/components/lounge/onboarding/lounge-onboarding";
import LoadingScreen from "@/app/components/shared/loading-screen";
import { useSessionStore } from "@/stores/session-store";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useState, useEffect } from "react";

const CreatePage = () => {
  const { isSessionValid, session, _hasHydrated } = useSessionStore();

  // Query user data to check lounge limits
  const userData = useQuery(
    api.users.getUser,
    session?.convexUserId ? { userId: session.convexUserId } : "skip"
  );

  // Check if user is in the process of creating a lounge
  const [isCreating, setIsCreating] = useState(false);
  // Track if user has started the onboarding flow
  const [hasStartedOnboarding, setHasStartedOnboarding] = useState(false);

  // Company-level cap checks
  const company = useQuery(
    api.companies.getCompanyById,
    session?.convexCompanyId ? { companyId: session.convexCompanyId } : "skip"
  );
  const companyRoomCount = useQuery(
    api.companies.getCompanyRoomCount,
    session?.convexCompanyId ? { companyId: session.convexCompanyId } : "skip"
  );
  const isCompanyOwner = useQuery(
    api.companies.isCompanyOwner,
    session?.convexCompanyId && session?.convexUserId
      ? { companyId: session.convexCompanyId, userId: session.convexUserId }
      : "skip"
  );
  // Plan-based lounge limits
  const planSettings = useQuery(
    api.plans.getCompanyPlanSettings,
    session?.convexCompanyId ? { companyId: session.convexCompanyId } : "skip"
  );

  // Minute usage summary for creation checks
  const usageSummary = useQuery(
    api.plans.getCompanyUsageSummary,
    session?.convexCompanyId ? { companyId: session.convexCompanyId } : "skip"
  );

  // Handle hydrating state - show loading until localStorage is read
  if (!_hasHydrated) {
    return <LoadingScreen />;
  }

  // Session validation
  if (!isSessionValid() || !session) {
    return (
      <LoadingScreen
        message="Your session has expired. Please sync your account again."
        error={true}
      />
    );
  }

  // Loading user data and plan settings
  if (!userData || !planSettings || !usageSummary) {
    return <LoadingScreen />;
  }

  // CRITICAL MINUTE CHECK: Block creation if < 1 minute available
  const available = usageSummary.available || 0;
  if (available < 1) {
    return (
      <LoadingScreen
        message="Your Whop has insufficient minutes to create a lounge. Please upgrade your plan to continue."
        error={true}
      />
    );
  }

  // Check lounge limits (skip if user has started onboarding) - read directly from plan
  if (planSettings.features.maxSavedLounges != null && !hasStartedOnboarding) {
    // != null catches both null and undefined
    const maxLimit = planSettings.features.maxSavedLounges;
    if (
      companyRoomCount !== undefined &&
      typeof companyRoomCount === "number" &&
      companyRoomCount >= maxLimit
    ) {
      const name = company?.name || "This company";
      return (
        <LoadingScreen
          message={`${name} has reached their limit of ${maxLimit} lounges. ${isCompanyOwner ? "Upgrade your plan to create more lounges." : "Please contact your admin to upgrade the plan."}`}
          info={true}
        />
      );
    }
  }

  // Success: User and company can create a lounge

  return (
    <LoungeOnboarding
      experienceId={session?.whopExperienceId}
      companyId={session?.convexCompanyId}
      userId={session?.convexUserId}
      experienceImage={session?.experienceImage}
      onCreationStart={() => setIsCreating(true)}
      onOnboardingStart={() => setHasStartedOnboarding(true)}
      usageSummary={usageSummary}
    />
  );
};

export default CreatePage;
