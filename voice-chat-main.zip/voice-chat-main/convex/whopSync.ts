import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// Sync Whop user data to Convex
export const syncWhopUser = mutation({
  args: {
    whopUserId: v.string(),
    whopUsername: v.string(),
    fullName: v.string(),
    avatarUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { whopUserId, whopUsername, fullName, avatarUrl } = args;

    // Check if user already exists
    const existingUser = await ctx.db
      .query("users")
      .withIndex("by_whop_user_id", (q) => q.eq("whopUserId", whopUserId))
      .first();

    if (existingUser) {
      // Update existing user
      await ctx.db.patch(existingUser._id, {
        whopUsername,
        fullName,
        avatarUrl,
        updatedAt: Date.now(),
      });
      return existingUser._id; // Return the existing user ID
    } else {
      // Create new user
      return await ctx.db.insert("users", {
        whopUserId,
        whopUsername,
        fullName,
        avatarUrl,
        isActive: true,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    }
  },
});

// Sync Whop company/experience data to Convex
export const syncWhopCompany = mutation({
  args: {
    whopCompanyId: v.string(),
    whopExperienceId: v.string(),
    name: v.string(),
    ownerUserId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const { whopCompanyId, whopExperienceId, name, ownerUserId } = args;

    // Check if company already exists
    const existingCompany = await ctx.db
      .query("companies")
      .withIndex("by_whop_company_id", (q) =>
        q.eq("whopCompanyId", whopCompanyId)
      )
      .first();

    if (existingCompany) {
      // Update existing company
      return await ctx.db.patch(existingCompany._id, {
        whopExperienceId,
        name,
        owner: ownerUserId,
        updatedAt: Date.now(),
      });
    } else {
      // Create new company with default Free tier settings
      // Get the free plan ID to use as default
      const freePlan = await ctx.db
        .query("plans")
        .withIndex("by_tier", (q) => q.eq("tier", "free"))
        .filter((q) => q.eq(q.field("isActive"), true))
        .first();

      if (!freePlan) {
        throw new Error("Free plan not found in database");
      }

      const companyId = await ctx.db.insert("companies", {
        whopCompanyId,
        whopExperienceId,
        name,
        owner: ownerUserId,
        isActive: true,
        planTier: freePlan._id, // Use plan ID reference instead of string literal
        planRenewsAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days from now
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });

      // Create experience mapping
      await ctx.db.insert("experienceMappings", {
        whopExperienceId,
        companyId,
        createdAt: Date.now(),
      });

      return companyId;
    }
  },
});

// Get user by Whop user ID
export const getUserByWhopId = query({
  args: { whopUserId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("users")
      .withIndex("by_whop_user_id", (q) => q.eq("whopUserId", args.whopUserId))
      .first();
  },
});

// Get company by Whop company ID
export const getCompanyByWhopId = query({
  args: { whopCompanyId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("companies")
      .withIndex("by_whop_company_id", (q) =>
        q.eq("whopCompanyId", args.whopCompanyId)
      )
      .first();
  },
});

// Get company by Whop experience ID
export const getCompanyByExperienceId = query({
  args: { whopExperienceId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("companies")
      .withIndex("by_whop_experience_id", (q) =>
        q.eq("whopExperienceId", args.whopExperienceId)
      )
      .first();
  },
});
