"use client";

import { useState, useEffect, useRef } from "react";
import { useAudioDevices, AudioDevice } from "@/app/hooks/useAudioDevices";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RefreshCw, Mic, Volume2 } from "lucide-react";
import { toast } from "sonner";

interface AudioDevicesSectionProps {
  onDeviceChange?: (inputDeviceId: string, outputDeviceId: string) => void;
  localParticipant?: any; // LiveKit local participant
}

// Utility function to check if setSinkId is supported
const isSetSinkIdSupported = () => {
  const audio = document.createElement("audio");
  return "setSinkId" in audio;
};

// Utility function to check if audio context is active
const isAudioContextActive = () => {
  try {
    const audioContext = new (window.AudioContext ||
      (window as any).webkitAudioContext)();
    return audioContext.state === "running";
  } catch {
    return false;
  }
};

// Utility function to check if device is still available
const isDeviceAvailable = async (deviceId: string, devices: AudioDevice[]) => {
  return devices.some((device) => device.deviceId === deviceId);
};

// Utility function to switch output device on all audio elements with retry logic
const switchOutputDevice = async (
  deviceId: string,
  maxRetries = 3
): Promise<boolean> => {
  const audioElements = document.querySelectorAll("audio, video");
  let successCount = 0;
  let totalAttempts = 0;

  for (const element of audioElements) {
    if ("setSinkId" in element) {
      totalAttempts++;
      let retries = 0;

      while (retries < maxRetries) {
        try {
          await (element as any).setSinkId(deviceId);
          successCount++;
          break; // Success, move to next element
        } catch (error) {
          retries++;
          console.warn(
            `Failed to set output device on element (attempt ${retries}/${maxRetries}):`,
            error
          );

          if (retries === maxRetries) {
            console.error(
              `Failed to set output device on element after ${maxRetries} attempts:`,
              error
            );
          } else {
            // Wait a bit before retrying
            await new Promise((resolve) => setTimeout(resolve, 100 * retries));
          }
        }
      }
    }
  }

  return successCount > 0; // Return true if at least one element was successfully switched
};

export function AudioDevicesSection({
  onDeviceChange,
  localParticipant,
}: AudioDevicesSectionProps) {
  const { inputDevices, outputDevices, isLoading, error, refreshDevices } =
    useAudioDevices();

  const [selectedInputDevice, setSelectedInputDevice] = useState<string>("");
  const [selectedOutputDevice, setSelectedOutputDevice] = useState<string>("");
  const [isChangingDevices, setIsChangingDevices] = useState(false);
  const [supportsOutputSwitching, setSupportsOutputSwitching] = useState(false);

  // Refs for timing management
  const deviceChangeTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastDeviceChangeRef = useRef<{
    deviceId: string;
    timestamp: number;
  } | null>(null);

  // Check browser support for output device switching
  useEffect(() => {
    setSupportsOutputSwitching(isSetSinkIdSupported());
  }, []);

  // Load saved device preferences from localStorage
  useEffect(() => {
    const savedInputDevice = localStorage.getItem("selectedInputDevice");
    const savedOutputDevice = localStorage.getItem("selectedOutputDevice");

    if (savedInputDevice) {
      setSelectedInputDevice(savedInputDevice);
    }
    if (savedOutputDevice) {
      setSelectedOutputDevice(savedOutputDevice);
    }
  }, []);

  // Set default devices when devices are loaded
  useEffect(() => {
    if (inputDevices.length > 0 && !selectedInputDevice) {
      // Try to find a default device or use the first one
      const defaultInput =
        inputDevices.find((d) => d.label.includes("Default")) ||
        inputDevices[0];
      setSelectedInputDevice(defaultInput?.deviceId || "");
    }

    if (outputDevices.length > 0 && !selectedOutputDevice) {
      // Try to find a default device or use the first one
      const defaultOutput =
        outputDevices.find((d) => d.label.includes("Default")) ||
        outputDevices[0];
      setSelectedOutputDevice(defaultOutput?.deviceId || "");
    }
  }, [inputDevices, outputDevices, selectedInputDevice, selectedOutputDevice]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (deviceChangeTimeoutRef.current) {
        clearTimeout(deviceChangeTimeoutRef.current);
      }
    };
  }, []);

  // Debounced output device switching to prevent race conditions
  const debouncedOutputDeviceSwitch = async (deviceId: string) => {
    // Clear any pending timeout
    if (deviceChangeTimeoutRef.current) {
      clearTimeout(deviceChangeTimeoutRef.current);
    }

    // Check if this is a duplicate request within 500ms
    const now = Date.now();
    if (
      lastDeviceChangeRef.current &&
      lastDeviceChangeRef.current.deviceId === deviceId &&
      now - lastDeviceChangeRef.current.timestamp < 500
    ) {
      return; // Skip duplicate request
    }

    // Set timeout for debounced execution
    deviceChangeTimeoutRef.current = setTimeout(async () => {
      try {
        // Check device availability
        const isAvailable = await isDeviceAvailable(deviceId, outputDevices);
        if (!isAvailable) {
          toast.error("Selected output device is no longer available");
          return;
        }

        // Check audio context state
        if (!isAudioContextActive()) {
          toast.warning(
            "Audio context not active. Some audio may not switch immediately."
          );
        }

        // Perform the device switch
        const success = await switchOutputDevice(deviceId);

        if (success) {
          lastDeviceChangeRef.current = { deviceId, timestamp: now };
          toast.success("Output device changed successfully");
        } else {
          toast.error("Failed to change output device");
        }
      } catch (error) {
        console.error("Error in debounced output device switch:", error);
        toast.error("Failed to change output device");
      }
    }, 300); // 300ms debounce
  };

  const handleInputDeviceChange = async (deviceId: string) => {
    setIsChangingDevices(true);
    try {
      setSelectedInputDevice(deviceId);
      localStorage.setItem("selectedInputDevice", deviceId);

      // Switch the actual LiveKit device if localParticipant is available
      if (localParticipant && deviceId) {
        // First disable microphone
        await localParticipant.setMicrophoneEnabled(false);

        // Then enable with new device constraints
        await localParticipant.setMicrophoneEnabled(true, {
          deviceId: { exact: deviceId },
        });
      }

      // Notify parent component about device change
      if (onDeviceChange) {
        onDeviceChange(deviceId, selectedOutputDevice);
      }

      toast.success("Input device changed successfully");
    } catch (error) {
      console.error("Failed to change input device:", error);
      toast.error("Failed to change input device");
    } finally {
      setIsChangingDevices(false);
    }
  };

  const handleOutputDeviceChange = async (deviceId: string) => {
    setIsChangingDevices(true);
    try {
      setSelectedOutputDevice(deviceId);
      localStorage.setItem("selectedOutputDevice", deviceId);

      // Switch the actual output device if supported
      if (isSetSinkIdSupported() && deviceId) {
        await debouncedOutputDeviceSwitch(deviceId);
      }

      // Notify parent component about device change
      if (onDeviceChange) {
        onDeviceChange(selectedInputDevice, deviceId);
      }
    } catch (error) {
      console.error("Failed to change output device:", error);
      toast.error("Failed to change output device");
    } finally {
      setIsChangingDevices(false);
    }
  };

  const handleRefreshDevices = async () => {
    try {
      await refreshDevices();
      toast.success("Device list refreshed");
    } catch (error) {
      console.error("Failed to refresh devices:", error);
      toast.error("Failed to refresh devices");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium text-neutral-900 dark:text-neutral-100">
          Audio Devices
        </h4>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRefreshDevices}
          disabled={isLoading}
          className="h-8 w-8 p-0"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
        </Button>
      </div>

      <div className="space-y-3">
        {/* Input Device Selection */}
        <div className="space-y-2">
          <label className="text-sm text-neutral-800 dark:text-neutral-400 flex items-center gap-2">
            <Mic className="w-4 h-4" />
            Input Device (Microphone)
          </label>
          {isLoading ? (
            <div className="w-full px-3 py-2 border border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed">
              Fetching your microphone devices...
            </div>
          ) : error ? (
            <div className="w-full px-3 py-2 border border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed">
              Failed to load devices: {error}
            </div>
          ) : (
            <Select
              onValueChange={handleInputDeviceChange}
              value={selectedInputDevice}
            >
              <SelectTrigger className="w-full px-3 py-2 border border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed">
                <SelectValue placeholder="Select microphone..." />
              </SelectTrigger>
              <SelectContent>
                {inputDevices.map((device) => (
                  <SelectItem key={device.deviceId} value={device.deviceId}>
                    {device.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Output Device Selection */}
        {supportsOutputSwitching && (
          <div className="space-y-2">
            <label className="text-sm text-neutral-800 dark:text-neutral-400 flex items-center gap-2">
              <Volume2 className="w-4 h-4" />
              Output Device (Speakers)
            </label>
            {isLoading ? (
              <div className="w-full px-3 py-2 border border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed">
                Fetching your speaker devices...
              </div>
            ) : error ? (
              <div className="w-full px-3 py-2 border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white">
                Failed to load devices: {error}
              </div>
            ) : (
              <Select
                onValueChange={handleOutputDeviceChange}
                value={selectedOutputDevice}
              >
                <SelectTrigger className="w-full px-3 py-2 border border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed">
                  <SelectValue placeholder="Select speakers..." />
                </SelectTrigger>
                <SelectContent>
                  {outputDevices.map((device) => (
                    <SelectItem key={device.deviceId} value={device.deviceId}>
                      {device.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        )}

        {/* Device Status */}
        <div className="text-xs text-neutral-600 dark:text-neutral-400">
          {isLoading && "Fetching your microphone and speaker devices..."}
          {!isLoading && !error && (
            <>
              {inputDevices.length} input device
              {inputDevices.length !== 1 ? "s" : ""} available
              {supportsOutputSwitching && outputDevices.length > 0 && (
                <>
                  , {outputDevices.length} output device
                  {outputDevices.length !== 1 ? "s" : ""} available
                </>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
