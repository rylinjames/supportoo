import { mutation } from "./_generated/server";
import { v } from "convex/values";
import { Id } from "./_generated/dataModel";
import { api } from "./_generated/api";

// Helper mutation for user validation in actions
export const validateUserForCharge = mutation({
  args: {
    userId: v.string(),
    experienceId: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const user = await ctx.db
        .query("users")
        .withIndex("by_whop_user_id", (q) => q.eq("whopUserId", args.userId))
        .first();

      if (!user) {
        return {
          success: false,
          error: "User not found",
        };
      }

      // TODO: Add experience access validation if needed
      // const hasAccess = await validateExperienceAccess(user, args.experienceId);

      return {
        success: true,
        convexUserId: user._id,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : "Validation failed",
      };
    }
  },
});

// Helper function to get plan tier index for comparison
function getPlanTierIndex(tier: string): number {
  const tierOrder = { free: 0, starter: 1, pro: 2, creator: 3 };
  return tierOrder[tier as keyof typeof tierOrder] ?? 0;
}

export const applyWhopEvent = mutation({
  args: {
    eventId: v.string(),
    action: v.string(),
    data: v.any(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const { eventId, action, data } = args as any;

    // Only process the app-scoped invalidation and payment succeeded
    const isPayment = action === "payment.succeeded";
    const isAppInvalidation = action === "app_membership_went_invalid";
    if (!isPayment && !isAppInvalidation) {
      return { success: true, ignored: true };
    }

    // Filter out zero-value payments immediately (payments only)
    if (isPayment) {
      const subtotal = data.subtotal ?? 0;
      if (subtotal <= 0) {
        return { success: true, ignored: true };
      }
    }

    console.log(
      `🔄 Processing webhook: ${action} (${eventId.substring(0, 8)}...)` +
        (isPayment ? ` | $${data.subtotal ?? 0}` : "")
    );

    // Simple idempotency: use eventId as a processing marker
    // For critical events, we rely on Whop's retry mechanism and our business logic to handle duplicates

    try {
      if (isPayment) {
        console.log(`💰 Processing successful payment:`, {
          paymentId: data.id,
          chargeId: data.charge_id,
          traceId: data.metadata?.traceId,
          type: data.metadata?.type,
        });

        const billingReason: string = (data.billing_reason || "").toString();
        const isOneTime = billingReason === "one_time";
        const isSubscriptionCreate = billingReason === "subscription_create";
        const isSubscriptionCycle = billingReason === "subscription_cycle"; // Renewal

        console.log(`🔍 [DEBUG] Payment type detection:`, {
          billingReason,
          isOneTime,
          isSubscriptionCreate,
          isSubscriptionCycle,
        });

        // Only process one_time (credit packs), subscription_create (new plans), or subscription_cycle (renewals)
        if (!isOneTime && !isSubscriptionCreate && !isSubscriptionCycle) {
          console.log(`🔇 Ignoring billing_reason: ${billingReason}`);
          return { success: true, ignored: true };
        }

        const companyWhopId: string | undefined =
          data.metadata?.companyId ||
          data.company_buyer_id ||
          data.company_id ||
          data.page_id;

        console.log(`🔍 [DEBUG] Company lookup:`, {
          companyWhopId,
          metadata_companyId: data.metadata?.companyId,
          company_buyer_id: data.company_buyer_id,
          company_id: data.company_id,
          page_id: data.page_id,
        });

        const company = await ctx.db
          .query("companies")
          .withIndex("by_whop_company_id", (q: any) =>
            q.eq("whopCompanyId", companyWhopId as string)
          )
          .first();

        if (!company) {
          console.error(
            `❌ [DEBUG] Company not found for whopCompanyId: ${companyWhopId}`
          );
          throw new Error("company_not_found");
        }

        console.log(`✅ [DEBUG] Company found:`, {
          companyId: company._id,
          companyName: company.name,
        });
        const paymentId: string = data.id;
        const productId: string | undefined =
          (data.product_id as string | undefined) || undefined;
        const planIdInPayload: string | undefined =
          (data.plan_id as string | undefined) || undefined;
        const catalogKey: string | undefined = planIdInPayload;
        const amount: number = data.final_amount ?? data.subtotal ?? 0;
        const currency: string = data.currency ?? "usd";
        const paidAt: number | undefined = data.paid_at
          ? Number(data.paid_at) * 1000
          : undefined;

        const normalizedReason: "one_time" | "subscription_create" = isOneTime
          ? "one_time"
          : isSubscriptionCreate
            ? "subscription_create"
            : "subscription_create"; // Treat renewal as subscription_create for receipt tracking

        const existingReceipt = await ctx.db
          .query("billingReceipts")
          .withIndex("by_receipt", (q) => q.eq("receiptId", paymentId))
          .first();
        const receiptDocId: Id<"billingReceipts"> = existingReceipt?._id
          ? (existingReceipt as any)._id
          : await ctx.db.insert("billingReceipts", {
              companyId: company._id,
              provider: "whop",
              receiptId: paymentId,
              billingReason: normalizedReason,
              status: "succeeded",
              amountUsd: amount,
              currency,
              planId:
                isSubscriptionCreate || isSubscriptionCycle
                  ? planIdInPayload
                  : undefined,
              packId: isOneTime ? catalogKey : undefined,
              creditId: undefined as any,
              paidAt,
              rawPayload: JSON.stringify(data),
              createdAt: now,
              updatedAt: now,
            });

        if (isOneTime) {
          console.log(
            `🔍 [DEBUG] One-time payment detected, resolving minutes...`
          );

          // Resolve minutes from metadata first, else from database lookup
          let minutes: number | undefined = undefined;
          const metaMinutes = (data.metadata &&
            (data.metadata.minutes || data.metadata.MINUTES)) as
            | string
            | number
            | undefined;

          console.log(`🔍 [DEBUG] Metadata minutes:`, {
            metaMinutes,
            fullMetadata: data.metadata,
          });

          if (metaMinutes !== undefined && metaMinutes !== null) {
            const n = Number(metaMinutes);
            if (!Number.isNaN(n) && n > 0) {
              minutes = Math.floor(n);
              console.log(`✅ [DEBUG] Minutes from metadata: ${minutes}`);
            }
          }

          // If no metadata minutes, look up in database
          if (!minutes && catalogKey) {
            console.log(`🔍 [DEBUG] Looking up minute pack`, {
              catalogKey,
              productId,
              planIdInPayload,
            });

            const minutePack = await ctx.db
              .query("minutePacks")
              .withIndex("by_whop_plan_id", (q) =>
                q.eq("whopPlanId", catalogKey)
              )
              .filter((q) => q.eq(q.field("isActive"), true))
              .first();

            if (minutePack) {
              minutes = minutePack.minutes;
              console.log(`✅ [DEBUG] Minutes from database pack`, {
                minutes,
                packId: minutePack._id,
                packName: minutePack.name,
              });
            } else {
              console.error(`❌ [DEBUG] No minute pack found`, {
                catalogKey,
                productId,
                planIdInPayload,
              });
            }
          }

          if (minutes && minutes > 0) {
            console.log(`🔍 [DEBUG] Creating credit for minutes`, {
              minutes,
              companyId: company._id,
              paymentId,
            });

            const existingCredit = await ctx.db
              .query("companyMinuteCredits")
              .withIndex("by_receipt_ref", (q) => q.eq("receiptRef", paymentId))
              .first();

            if (!existingCredit) {
              const creditId = await ctx.db.insert("companyMinuteCredits", {
                companyId: company._id,
                minutes: minutes,
                remainingMinutes: minutes,
                source: "pack",
                receiptRef: paymentId,
                purchasedAt: now,
                expiresAt: undefined,
              });
              await ctx.db.patch(receiptDocId, { creditId, updatedAt: now });

              console.log(`✅ [DEBUG] Credit created successfully:`, {
                creditId,
                minutes,
                companyId: company._id,
                companyName: company.name,
              });
            } else {
              console.log(`⚠️ [DEBUG] Credit already exists for this payment`, {
                existingCreditId: existingCredit._id,
                paymentId,
              });
            }
          } else {
            console.error(
              `❌ [DEBUG] No minutes resolved! Cannot create credit.`,
              {
                minutes,
                catalogKey,
                productId,
                planIdInPayload,
                metaMinutes: data.metadata?.minutes || data.metadata?.MINUTES,
              }
            );
          }
        } else if (isSubscriptionCreate || isSubscriptionCycle) {
          const isRenewal = isSubscriptionCycle;
          console.log(
            `🔍 [DEBUG] Subscription ${isRenewal ? "renewal" : "create"} detected`
          );

          // Extract membership ID from payment data
          const whopMembershipId: string | undefined =
            data.membership_id ||
            data.membershipId ||
            data.subscription_id ||
            data.subscriptionId;

          console.log(`🔍 [DEBUG] Membership ID extraction:`, {
            whopMembershipId,
            membership_id: data.membership_id,
            membershipId: data.membershipId,
            subscription_id: data.subscription_id,
            subscriptionId: data.subscriptionId,
          });

          // Prefer metadata.tier if present; fallback to database lookup
          const metaTier = (data.metadata && data.metadata.tier) as
            | "free"
            | "starter"
            | "pro"
            | "creator"
            | undefined;
          let tier = metaTier;

          // If no metadata tier, look up in database
          if (!tier && planIdInPayload) {
            console.log(`🔍 [DEBUG] Looking up plan by Whop plan id`, {
              planIdInPayload,
            });
            const plan = await ctx.db
              .query("plans")
              .withIndex("by_whop_plan_id", (q) =>
                q.eq("whopPlanId", planIdInPayload)
              )
              .filter((q) => q.eq(q.field("isActive"), true))
              .first();
            if (plan) {
              tier = plan.tier;
              console.log(`✅ [DEBUG] Resolved tier from database`, {
                tier,
                planId: plan._id,
              });
            } else {
              console.error(
                `❌ [DEBUG] Could not resolve tier from planIdInPayload`,
                { planIdInPayload }
              );
            }
          }

          if (tier) {
            // Find the plan by tier to get the ID
            console.log(`🔍 [DEBUG] Resolving internal plan by tier`, { tier });
            const planToSet = await ctx.db
              .query("plans")
              .withIndex("by_tier", (q) => q.eq("tier", tier))
              .filter((q) => q.eq(q.field("isActive"), true))
              .first();

            if (planToSet) {
              // Check if user is authorized to make plan changes (only for new subscriptions)
              if (!isRenewal) {
                const currentPlan = company.planTier
                  ? await ctx.db.get(company.planTier)
                  : null;
                const currentTier = currentPlan?.tier ?? "free";
                console.log(`🔍 [DEBUG] Current vs new tier`, {
                  currentTier,
                  newTier: tier,
                });

                // If no plan owner exists, make this user the plan owner
                if (!company.planOwner) {
                  console.log(
                    `👑 Setting ${data.user_id} as plan owner for company ${company._id}`
                  );
                  await ctx.db.patch(company._id, {
                    planOwner: data.user_id,
                    updatedAt: now,
                  });
                  // Update company reference for subsequent checks
                  company.planOwner = data.user_id;
                }

                // Only allow plan changes from the plan owner (for new subscriptions)
                if (company.planOwner && data.user_id !== company.planOwner) {
                  console.log(
                    `⚠️ Plan change rejected: user ${data.user_id} is not the plan owner (${company.planOwner})`
                  );
                  return {
                    success: true,
                    ignored: true,
                    reason: "not_plan_owner",
                  };
                }
              }

              // Calculate billing period (30 days)
              const periodStart = now;
              const periodEnd = now + 30 * 24 * 60 * 60 * 1000; // 30 days from now

              // Determine if we should enable member lounge creation (only for new subscriptions)
              const shouldEnableMemberCreate =
                !isRenewal &&
                company.allowMembersToCreateLounges === undefined &&
                ["starter", "pro", "creator"].includes(tier);

              if (shouldEnableMemberCreate) {
                console.log(
                  `✅ Enabling member lounge creation for Starter+ tier`
                );
              }

              // Build update object with billing fields
              const updateFields: any = {
                planTier: planToSet._id,
                billingStatus: "active", // Mark as active
                currentPeriodStart: periodStart,
                currentPeriodEnd: periodEnd,
                planRenewsAt: periodEnd, // Set renewal boundary
                minutesUsedThisMonth: 0, // Reset usage counter
                updatedAt: now,
                ...(shouldEnableMemberCreate && {
                  allowMembersToCreateLounges: true,
                }),
              };

              // Store membership ID if available
              if (whopMembershipId) {
                updateFields.whopMembershipId = whopMembershipId;
                console.log(`✅ Storing membership ID: ${whopMembershipId}`);
              }

              // Clear scheduled plan change if it exists (user re-subscribed)
              if (company.scheduledPlanChangeAt || company.scheduledPlanId) {
                console.log(
                  `🔄 Clearing scheduled plan change (user re-subscribed)`
                );
                updateFields.scheduledPlanChangeAt = undefined;
                updateFields.scheduledPlanId = undefined;
              }

              await ctx.db.patch(company._id, updateFields);

              // Record billing event
              if (whopMembershipId) {
                try {
                  await ctx.db.insert("billing_events", {
                    companyId: company._id,
                    eventType: "payment_succeeded",
                    whopPaymentId: paymentId,
                    whopMembershipId,
                    whopUserId: data.user_id,
                    whopPlanId: planIdInPayload || "",
                    amount,
                    currency,
                    newPlanId: planToSet._id,
                    rawData: data,
                    createdAt: now,
                  });
                  console.log(`✅ Recorded billing event`);
                } catch (error) {
                  console.error(`⚠️ Failed to record billing event:`, error);
                  // Don't fail the webhook if event recording fails
                }
              }

              console.log(
                `🚀 ${isRenewal ? "Renewal" : "Plan change"} to ${tier} completed`
              );
            } else {
              console.error(`❌ [DEBUG] Could not find active plan for tier`, {
                tier,
              });
            }
          }
        }
        // End of payment branch
        return { success: true };
      }

      // Handle app-scoped membership invalidation (downgrade to free)
      if (isAppInvalidation) {
        const companyWhopId: string | undefined =
          data.company_buyer_id || data.company_id || data.page_id;

        const company = await ctx.db
          .query("companies")
          .withIndex("by_whop_company_id", (q: any) =>
            q.eq("whopCompanyId", companyWhopId as string)
          )
          .first();
        if (!company) {
          return { success: true, ignored: true, reason: "company_not_found" };
        }

        const freePlan = await ctx.db
          .query("plans")
          .withIndex("by_tier", (q) => q.eq("tier", "free"))
          .first();
        if (!freePlan) {
          return { success: false, error: "free_plan_missing" };
        }

        // Extract membership ID if available
        const whopMembershipId: string | undefined =
          data.membership_id || data.membershipId || company.whopMembershipId;

        // Update company to free plan
        await ctx.db.patch(company._id, {
          planTier: freePlan._id,
          billingStatus: "active", // Back to active on free plan
          whopMembershipId: undefined, // Clear membership ID
          updatedAt: now,
        });

        // Record billing event if we have membership ID
        if (whopMembershipId) {
          try {
            await ctx.db.insert("billing_events", {
              companyId: company._id,
              eventType: "subscription_cancelled",
              whopMembershipId,
              whopUserId: data.user_id || "",
              whopPlanId: "",
              newPlanId: freePlan._id,
              rawData: data,
              createdAt: now,
            });
            console.log(
              `✅ Recorded billing event for membership invalidation`
            );
          } catch (error) {
            console.error(`⚠️ Failed to record billing event:`, error);
            // Don't fail the webhook if event recording fails
          }
        }

        console.log(
          `❌ App membership invalid -> downgraded company ${company._id} to free`
        );
        return { success: true };
      }
    } catch (error) {
      console.error(`❌ Webhook processing failed:`, error);
      throw error;
    }

    return { success: true };
  },
});

/**
 * Record billing event for history
 */
export const recordBillingEvent = mutation({
  args: {
    companyId: v.id("companies"),
    eventType: v.union(
      v.literal("payment_succeeded"),
      v.literal("subscription_cancelled")
    ),
    whopPaymentId: v.optional(v.string()),
    whopMembershipId: v.string(),
    whopUserId: v.string(),
    whopPlanId: v.string(),
    amount: v.optional(v.number()),
    currency: v.optional(v.string()),
    newPlanId: v.id("plans"),
    rawData: v.optional(v.any()),
  },
  handler: async (
    ctx,
    {
      companyId,
      eventType,
      whopPaymentId,
      whopMembershipId,
      whopUserId,
      whopPlanId,
      amount,
      currency,
      newPlanId,
      rawData,
    }
  ) => {
    const eventId = await ctx.db.insert("billing_events", {
      companyId,
      eventType,
      whopPaymentId,
      whopMembershipId,
      whopUserId,
      whopPlanId,
      amount,
      currency,
      newPlanId,
      rawData,
      createdAt: Date.now(),
    });

    return eventId;
  },
});

/**
 * Schedule plan downgrade (when subscription cancelled)
 *
 * DON'T downgrade immediately - let them keep access until period ends
 */
export const schedulePlanDowngrade = mutation({
  args: {
    companyId: v.id("companies"),
    scheduledPlanId: v.id("plans"), // Usually free plan
    scheduledFor: v.number(), // currentPeriodEnd
  },
  handler: async (ctx, { companyId, scheduledPlanId, scheduledFor }) => {
    // Schedule the downgrade, don't execute it yet
    await ctx.db.patch(companyId, {
      billingStatus: "canceled", // Mark as canceled but still active
      scheduledPlanChangeAt: scheduledFor,
      scheduledPlanId,
      // Note: We keep whopMembershipId for reference (don't clear it yet)
      // It will be cleared when the downgrade executes
      updatedAt: Date.now(),
    });

    return { success: true };
  },
});

/**
 * Execute scheduled plan change (called by cron)
 *
 * This downgrades companies at the end of their billing period
 * after they've cancelled their subscription.
 */
export const executeScheduledPlanChange = mutation({
  args: {
    companyId: v.id("companies"),
  },
  handler: async (ctx, { companyId }) => {
    const company = await ctx.db.get(companyId);
    if (!company) {
      return { success: false, reason: "company_not_found" };
    }

    if (!company.scheduledPlanId || !company.scheduledPlanChangeAt) {
      return { success: false, reason: "no_scheduled_change" };
    }

    const now = Date.now();

    // Verify the scheduled change is actually due
    if (company.scheduledPlanChangeAt > now) {
      return { success: false, reason: "not_due_yet" };
    }

    // Get the plan to downgrade to
    const newPlan = await ctx.db.get(company.scheduledPlanId);
    if (!newPlan) {
      return { success: false, reason: "plan_not_found" };
    }

    console.log(
      `🔄 Executing scheduled plan change for ${company.name}: ${company.planTier} → ${newPlan.tier}`
    );

    // Calculate new billing period (30 days)
    const periodStart = now;
    const periodEnd = now + 30 * 24 * 60 * 60 * 1000; // 30 days from now

    // Execute the scheduled plan change
    await ctx.db.patch(companyId, {
      planTier: company.scheduledPlanId, // Downgrade to scheduled plan
      billingStatus: "active", // Back to active (on new plan)
      scheduledPlanChangeAt: undefined, // Clear scheduled change
      scheduledPlanId: undefined, // Clear scheduled plan
      currentPeriodStart: periodStart, // New billing period start
      currentPeriodEnd: periodEnd, // New billing period end
      whopMembershipId: undefined, // Clear membership ID (subscription ended)
      minutesUsedThisMonth: 0, // Reset usage counter
      planRenewsAt: periodEnd, // Set next renewal boundary
      updatedAt: now,
    });

    console.log(
      `✅ Successfully downgraded ${company.name} to ${newPlan.tier} plan`
    );

    return { success: true, newPlanTier: newPlan.tier };
  },
});
