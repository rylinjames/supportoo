import { useState, useEffect, useCallback, useRef } from "react";
import { Room } from "livekit-client";
import { ScreenShareManager } from "@/lib/livekit/ScreenShareManager";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";

interface UseScreenShareProps {
  room: Room | null;
  roomId: Id<"rooms">;
  userId: Id<"users">;
  canScreenShare: boolean;
}

interface UseScreenShareReturn {
  // State
  isSharing: boolean;
  isLoading: boolean;
  error: string | null;
  screenShareState: any; // From Convex query
  canScreenShare: boolean;

  // Actions
  startScreenShare: () => Promise<void>;
  stopScreenShare: () => Promise<void>;
  takeoverScreenShare: () => Promise<void>;
}

export function useScreenShare({
  room,
  roomId,
  userId,
  canScreenShare,
}: UseScreenShareProps): UseScreenShareReturn {
  // Local state
  const [screenShareManager, setScreenShareManager] =
    useState<ScreenShareManager | null>(null);
  const [isSharing, setIsSharing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Prevent stale closures
  const stateRef = useRef({ isSharing, isLoading });
  stateRef.current = { isSharing, isLoading };

  // Convex mutations
  const startScreenShareMutation = useMutation(
    api.screenShare.startScreenShare
  );
  const stopScreenShareMutation = useMutation(api.screenShare.stopScreenShare);
  const takeoverScreenShareMutation = useMutation(
    api.screenShare.takeoverScreenShare
  );

  // Convex query for screen share state
  const screenShareState = useQuery(api.screenShare.getScreenShareState, {
    roomId,
  });

  /**
   * Initialize ScreenShareManager when room is ready
   */
  useEffect(() => {
    if (room && !screenShareManager) {
      console.log("🔧 Initializing ScreenShareManager");
      const manager = new ScreenShareManager(room);
      setScreenShareManager(manager);

      // Cleanup on unmount
      return () => {
        console.log("🧹 Cleaning up ScreenShareManager");
      };
    }
  }, [room, screenShareManager]);

  /**
   * Start screen sharing
   */
  const startScreenShare = useCallback(async () => {
    if (!screenShareManager || !canScreenShare || stateRef.current.isLoading) {
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log("🚀 Starting screen share...");

      // Start screen capture
      await screenShareManager.startScreenShare();

      // Update backend
      await startScreenShareMutation({
        roomId,
        presenterId: userId,
      });

      setIsSharing(true);
      console.log("✅ Screen sharing started successfully");
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to start screen sharing";
      console.error("❌ Screen share start failed:", errorMessage);
      setError(errorMessage);
      setIsSharing(false);
    } finally {
      setIsLoading(false);
    }
  }, [
    screenShareManager,
    canScreenShare,
    roomId,
    userId,
    startScreenShareMutation,
  ]);

  /**
   * Stop screen sharing
   */
  const stopScreenShare = useCallback(async () => {
    if (
      !screenShareManager ||
      !stateRef.current.isSharing ||
      stateRef.current.isLoading
    ) {
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log("🛑 Stopping screen share...");

      // Stop screen capture
      await screenShareManager.stopScreenShare();

      // Update backend
      await stopScreenShareMutation({
        roomId,
        presenterId: userId,
      });

      setIsSharing(false);
      console.log("✅ Screen sharing stopped successfully");
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to stop screen sharing";
      console.error("❌ Screen share stop failed:", errorMessage);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [screenShareManager, roomId, userId, stopScreenShareMutation]);

  /**
   * Take over screen sharing from another presenter
   */
  const takeoverScreenShare = useCallback(async () => {
    if (!screenShareManager || !canScreenShare || stateRef.current.isLoading) {
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log("⚡ Taking over screen share...");

      // Start our screen capture
      await screenShareManager.startScreenShare();

      // Update backend (this will handle stopping the previous presenter)
      await takeoverScreenShareMutation({
        roomId,
        newPresenterId: userId,
      });

      setIsSharing(true);
      console.log("✅ Screen sharing takeover successful");
    } catch (err) {
      const errorMessage =
        err instanceof Error
          ? err.message
          : "Failed to take over screen sharing";
      console.error("❌ Screen share takeover failed:", errorMessage);
      setError(errorMessage);
      setIsSharing(false);
    } finally {
      setIsLoading(false);
    }
  }, [
    screenShareManager,
    canScreenShare,
    roomId,
    userId,
    takeoverScreenShareMutation,
  ]);

  /**
   * Clear error after a delay
   */
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        setError(null);
      }, 5000); // Clear error after 5 seconds

      return () => clearTimeout(timer);
    }
  }, [error]);

  return {
    // State
    isSharing,
    isLoading,
    error,
    screenShareState,
    canScreenShare,

    // Actions
    startScreenShare,
    stopScreenShare,
    takeoverScreenShare,
  };
}
