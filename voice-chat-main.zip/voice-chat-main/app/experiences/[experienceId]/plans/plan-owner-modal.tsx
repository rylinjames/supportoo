"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Crown, AlertCircle } from "lucide-react";

interface PlanOwnerModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  planOwnerName?: string;
  planOwnerUsername?: string;
}

export default function PlanOwnerModal({
  open,
  onOpenChange,
  planOwnerName,
  planOwnerUsername,
}: PlanOwnerModalProps) {
  const handleContactOwner = () => {
    // Close modal and could potentially open contact form or copy contact info
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-background border border-neutral-800 text-white max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <Crown className="w-6 h-6 text-yellow-500" />
            <DialogTitle className="text-xl font-semibold text-white">
              Plan Change Restricted
            </DialogTitle>
          </div>
          <DialogDescription className="text-neutral-400">
            Only the designated plan owner can make changes to your company's subscription plan.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-start gap-3 p-3 bg-neutral-800/50 rounded-lg border border-neutral-700">
            <AlertCircle className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-white">
                Current Plan Owner
              </p>
              <p className="text-sm text-neutral-300">
                {planOwnerName || planOwnerUsername || "Unknown"}
              </p>
              {planOwnerUsername && (
                <p className="text-xs text-neutral-500">
                  @{planOwnerUsername}
                </p>
              )}
            </div>
          </div>

          <div className="text-sm text-neutral-400 space-y-2">
            <p>
              To change your plan, please contact the plan owner listed above. 
              They have the authority to modify your subscription.
            </p>
            <p>
              If you need to become the plan owner, they can transfer ownership 
              to you through the admin settings.
            </p>
          </div>
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            onClick={handleContactOwner}
            className="flex-1 bg-primary hover:bg-primary/90 text-white"
          >
            Got It
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
