import { mutation } from "./_generated/server";
import { v } from "convex/values";
import { Id } from "./_generated/dataModel";
import { createLoungeEvent, EVENT_TYPES, getFirstName } from "./events";
import { api } from "./_generated/api";

function yearMonthUtc(ms: number): string {
  const d = new Date(ms);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}

async function consumeCreditsFifo(
  ctx: any,
  companyId: Id<"companies">,
  debitMinutes: number
): Promise<number> {
  if (debitMinutes <= 0) return 0;
  const credits = await ctx.db
    .query("companyMinuteCredits")
    .withIndex("by_company", (q: any) => q.eq("companyId", companyId))
    .collect();
  // Sort: earliest expiresAt first (nulls last), then purchasedAt ascending
  credits.sort((a: any, b: any) => {
    const ea = a.expiresAt ?? Number.POSITIVE_INFINITY;
    const eb = b.expiresAt ?? Number.POSITIVE_INFINITY;
    if (ea !== eb) return ea - eb;
    return (a.purchasedAt || 0) - (b.purchasedAt || 0);
  });
  let remaining = debitMinutes;
  for (const c of credits) {
    if (remaining <= 0) break;
    const take = Math.min(remaining, Math.max(0, c.remainingMinutes || 0));
    if (take > 0) {
      await ctx.db.patch(c._id, {
        remainingMinutes: (c.remainingMinutes || 0) - take,
      });
      remaining -= take;
    }
  }
  return debitMinutes - remaining; // actually consumed
}

async function incrementCompanyMinutes(
  ctx: any,
  companyId: Id<"companies">,
  deltaMinutes: number
): Promise<void> {
  // Use atomic billing to prevent race conditions
  await ctx.runMutation(api.atomicBilling.atomicIncrementCompanyMinutes, {
    companyId,
    deltaMinutes,
  });
}

// Handle participant joined webhook
export const handleParticipantJoined = mutation({
  args: {
    event: v.string(),
    room: v.object({
      name: v.string(),
    }),
    participant: v.object({
      identity: v.string(),
      name: v.string(),
    }),
  },
  handler: async (ctx, args) => {
    const { room, participant } = args;

    try {
      // Find the room in our database by LiveKit room name (which is actually the room ID)
      const dbRoom = await ctx.db.get(room.name as Id<"rooms">);

      if (!dbRoom) {
        console.log(
          `Room ${room.name} not found in database, skipping participant join`
        );
        return;
      }

      // Check if participant already exists by liveKitIdentity
      let existingParticipant = await ctx.db
        .query("participants")
        .withIndex("by_room_and_livekit_identity", (q) =>
          q.eq("roomId", dbRoom._id).eq("liveKitIdentity", participant.identity)
        )
        .first();

      if (!existingParticipant) {
        // Fallback: look up by userId via whopUserId mapping
        console.log(
          `Looking for user with whopUserId: ${participant.identity}`
        );
        const user = await ctx.db
          .query("users")
          .withIndex("by_whop_user_id", (q) =>
            q.eq("whopUserId", participant.identity)
          )
          .first();

        if (!user) {
          console.log(
            `User with whopUserId ${participant.identity} not found, skipping participant creation`
          );
          return;
        }

        // See if there's a participant by (roomId, userId)
        const participantByUser = await ctx.db
          .query("participants")
          .withIndex("by_room_and_user", (q) =>
            q.eq("roomId", dbRoom._id).eq("userId", user._id)
          )
          .first();

        if (participantByUser) {
          // Patch missing liveKitIdentity, clear leftAt if necessary
          await ctx.db.patch(participantByUser._id, {
            liveKitIdentity:
              participantByUser.liveKitIdentity ?? participant.identity,
            leftAt: undefined,
          });
          existingParticipant = participantByUser;
        } else {
          // Create new participant record (canonical upsert)
          await ctx.db.insert("participants", {
            roomId: dbRoom._id,
            liveKitIdentity: participant.identity,
            userId: user._id,
            role: "listener", // default role
            isSpeaking: false,
            isMuted: false,
            joinedAt: Date.now(),
            isCreator: false,
          });

          // Emit user_joined lounge event (only when we actually inserted)
          if (!user.isAnonymous) {
            await createLoungeEvent(ctx, {
              roomId: dbRoom._id,
              eventType: EVENT_TYPES.USER_JOINED,
              userId: user._id,
              eventData: {
                userName: getFirstName(user.fullName),
              },
            });
          }
        }
      }

      console.log(
        `Participant ${participant.identity} present in room ${room.name} (${dbRoom._id})`
      );
    } catch (error) {
      console.error("Error handling participant joined:", error);
    }
  },
});

// Handle participant left webhook
export const handleParticipantLeft = mutation({
  args: {
    event: v.string(),
    room: v.object({
      name: v.string(),
    }),
    participant: v.object({
      identity: v.string(),
    }),
  },
  handler: async (ctx, args) => {
    const { room, participant } = args;

    try {
      // Find the room in our database by LiveKit room name (which is actually the room ID)
      const dbRoom = await ctx.db.get(room.name as Id<"rooms">);

      if (!dbRoom) {
        console.log(
          `Room ${room.name} not found in database, skipping participant leave`
        );
        return;
      }

      // Find and remove participant (try by liveKitIdentity first)
      let participantToRemove = await ctx.db
        .query("participants")
        .withIndex("by_room_and_livekit_identity", (q) =>
          q.eq("roomId", dbRoom._id).eq("liveKitIdentity", participant.identity)
        )
        .first();

      if (!participantToRemove) {
        // Fallback: resolve user by whopUserId and remove by (roomId, userId)
        const user = await ctx.db
          .query("users")
          .withIndex("by_whop_user_id", (q) =>
            q.eq("whopUserId", participant.identity)
          )
          .first();
        if (user) {
          participantToRemove = await ctx.db
            .query("participants")
            .withIndex("by_room_and_user", (q) =>
              q.eq("roomId", dbRoom._id).eq("userId", user._id)
            )
            .first();
        }
      }

      if (participantToRemove) {
        // Resolve user for event emission
        const leavingUser = await ctx.db.get(participantToRemove.userId);

        // Check if the leaving participant was sharing screen and stop it BEFORE other events
        if (
          leavingUser &&
          dbRoom.screenShareActive &&
          dbRoom.currentPresenter === leavingUser._id
        ) {
          await ctx.runMutation(api.screenShare.stopScreenShare, {
            roomId: dbRoom._id,
            presenterId: leavingUser._id,
          });
          console.log(
            `Stopped screen sharing for leaving participant ${participant.identity} in room ${room.name}`
          );
        }

        // Stop real-time billing timer and apply final charge
        await ctx.runMutation(api.participantBilling.stopParticipantBilling, {
          participantId: participantToRemove._id,
        });

        await ctx.db.delete(participantToRemove._id);
        console.log(
          `Removed participant ${participant.identity} from room ${room.name} (${dbRoom._id})`
        );

        // Emit user_left lounge event (only when we actually deleted)
        if (leavingUser && !leavingUser.isAnonymous) {
          await createLoungeEvent(ctx, {
            roomId: dbRoom._id,
            eventType: EVENT_TYPES.USER_LEFT,
            userId: leavingUser._id,
            eventData: {
              userName: getFirstName(leavingUser.fullName),
            },
          });
        }

        // Check if room is now empty
        const remainingParticipants = await ctx.db
          .query("participants")
          .withIndex("by_room", (q) => q.eq("roomId", dbRoom._id))
          .collect();

        if (remainingParticipants.length === 0) {
          // Check if this is a temporary room
          const isTemporary = dbRoom.isTemporary ?? true;

          if (isTemporary) {
            // Immediate deletion for temporary rooms
            await ctx.runMutation(api.rooms.internalDeleteRoom, {
              roomId: dbRoom._id,
            });
            console.log(
              `Immediately deleted empty temporary room ${room.name} (${dbRoom._id})`
            );
          } else {
            // Mark permanent rooms as inactive
            await ctx.db.patch(dbRoom._id, {
              isActive: false,
              participantCount: 0,
            });
            console.log(
              `Permanent room ${room.name} (${dbRoom._id}) is now inactive but preserved`
            );
          }
        }
      } else {
        console.log(
          `Participant ${participant.identity} not found in room ${room.name}`
        );
      }
    } catch (error) {
      console.error("Error handling participant left:", error);
    }
  },
});

// Handle room deleted webhook
export const handleRoomDeleted = mutation({
  args: {
    event: v.string(),
    room: v.object({
      name: v.string(),
    }),
  },
  handler: async (ctx, args) => {
    const { room } = args;

    try {
      // Find the room in our database by LiveKit room name (which is actually the room ID)
      const dbRoom = await ctx.db.get(room.name as Id<"rooms">);

      if (dbRoom) {
        // Default to temporary if isTemporary is undefined (for existing rooms)
        const isTemporary = dbRoom.isTemporary ?? true;

        if (isTemporary) {
          // Remove this room from creator's registeredRooms
          try {
            const creator = await ctx.db.get(dbRoom.creatorId);
            if (creator) {
              const currentRegistered = Array.isArray(creator.registeredRooms)
                ? creator.registeredRooms
                : [];
              const updatedRegistered = currentRegistered.filter(
                (id: Id<"rooms">) => id !== dbRoom._id
              );
              await ctx.db.patch(dbRoom.creatorId, {
                registeredRooms: updatedRegistered,
                updatedAt: Date.now(),
              });
            }
          } catch (e) {
            console.error(
              "Failed to adjust creator registeredRooms during temp room deletion:",
              e
            );
          }
          // Delete entire room and all data
          await deleteRoomAndAllData(ctx, dbRoom._id);
          console.log(
            `Deleted temporary room ${room.name} (${dbRoom._id}) and all data`
          );
        } else {
          // Permanent room: only delete participants, keep room
          await cleanupPermanentRoom(ctx, dbRoom._id);
          console.log(`Cleaned up permanent room ${room.name} (${dbRoom._id})`);
        }
        // Schedule immediate purge of session rows for this room
        try {
          await ctx.scheduler.runAfter(0, api.webhooks.purgeRoomSessions, {
            roomId: dbRoom._id,
          });
        } catch {}
      } else {
        console.log(`Room ${room.name} not found in database`);
      }
    } catch (error) {
      console.error("Error handling room deleted:", error);
    }
  },
});

// Helper function to delete room and all data
async function deleteRoomAndAllData(ctx: any, roomId: Id<"rooms">) {
  // Delete all participants
  const participants = await ctx.db
    .query("participants")
    .withIndex("by_room", (q: any) => q.eq("roomId", roomId))
    .collect();

  for (const participant of participants) {
    await ctx.db.delete(participant._id);
  }

  // Delete all reactions
  const reactions = await ctx.db
    .query("reactions")
    .withIndex("by_room", (q: any) => q.eq("roomId", roomId))
    .collect();

  for (const reaction of reactions) {
    await ctx.db.delete(reaction._id);
  }

  // Delete all events
  const events = await ctx.db
    .query("loungeEvents")
    .withIndex("by_room", (q: any) => q.eq("roomId", roomId))
    .collect();

  for (const event of events) {
    await ctx.db.delete(event._id);
  }

  // Delete the room itself
  await ctx.db.delete(roomId);
}

// Helper function to cleanup permanent room
async function cleanupPermanentRoom(ctx: any, roomId: Id<"rooms">) {
  // Delete all participants
  const participants = await ctx.db
    .query("participants")
    .withIndex("by_room", (q: any) => q.eq("roomId", roomId))
    .collect();

  for (const participant of participants) {
    await ctx.db.delete(participant._id);
  }

  // Set room as inactive
  await ctx.db.patch(roomId, {
    isActive: false,
    participantCount: 0,
  });
}

// Purge session rows for a room (idempotent)
export const purgeRoomSessions = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, args) => {
    // currently we store minutes on participants; if livekitUsageSessions is added later, purge here
    // No-op placeholder for future session table; kept to satisfy scheduled calls
    return { success: true };
  },
});
