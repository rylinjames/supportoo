"use client";

import { Skeleton } from "@/components/ui/skeleton";

const LoungeLoading = () => {
  return (
    <div className="min-h-screen bg-foreground text-white flex">
      <div className="flex-1 relative justify-between flex flex-col border-r border-neutral-800">
        <div className="h-full">
          <div className="flex p-6 items-start justify-between border-b border-neutral-800">
            <div className="flex flex-col gap-2">
              <Skeleton className="w-64 h-6" />
              <Skeleton className="w-32 h-6" />
            </div>
            <div className="flex items-center gap-3">
              <Skeleton className="size-6" />
              <Skeleton className="size-6" />
              <Skeleton className="size-6" />
            </div>
          </div>
        </div>
        <div className="flex-1 p-6 border-t border-neutral-800 w-full">
          <div className="flex gap-4 justify-center items-center">
            <Skeleton className="rounded-full size-14" />
            <Skeleton className="rounded-full size-14" />
          </div>
        </div>
      </div>
      <div className="min-h-screen w-80 bg-background flex flex-col gap-4">
        <div className="p-6 flex flex-col gap-4 border-b border-neutral-800">
          <Skeleton className="w-40 h-6" />
          <div className="flex flex-col gap-3">
            <Skeleton className="w-full h-8" />
            <Skeleton className="w-full h-8" />
            <Skeleton className="w-full h-8" />
            <Skeleton className="w-full h-8" />
          </div>
        </div>
        <div className="p-6 flex flex-col gap-2">
          <Skeleton className="w-20 h-4" />
          <Skeleton className="w-50 h-4 mt-1" />
          <Skeleton className="w-30 h-4" />
          <Skeleton className="w-40 h-4" />
        </div>
      </div>
    </div>
  );
};

export default LoungeLoading;
