import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { Id } from "./_generated/dataModel";
import { ROOM_CATEGORIES } from "./categories";
import { api } from "./_generated/api";

// Types for enriched room data
export interface EnrichedRoom {
  // Base room data (matching LoungeCardProps)
  _id: Id<"rooms">;
  isActive: boolean;
  name: string;
  whopExperienceId: string;
  whopCompanyLogo: string;
  whopCompanyImageUrl: string;
  whopCompanyName: string;
  whopCompanyId: string;
  category?: string;
  isPublic: boolean;
  participantCount: number;
  creatorName: string;
  creatorWhopUsername: string;
  creatorAvatarUrl: string;
  isUserParticipant?: boolean;
  isCreator: boolean;

  // Additional fields for internal use
  description?: string;
  roomImage?: string;
  createdAt: number;
  creatorId: Id<"users">;
  relationship?: "creator" | "member"; // For my rooms
  discoverListed?: boolean; // Whether the lounge is discoverable in explore page
  isTemporary?: boolean; // Whether this is a temporary room

  // Viewer metadata
  viewerIsCompanyOwner?: boolean; // whether current viewer owns the company
  canDelete?: boolean; // legacy; do not use in UI
  viewerCanDelete?: boolean; // creator or whop admin within same company
  companyPlanTier?: string; // company's current plan tier
}

// Helper function to get participant count for a room
const getParticipantCount = async (
  ctx: any,
  roomId: Id<"rooms">
): Promise<number> => {
  // Count current participants (those who haven't left)
  const participants = await ctx.db
    .query("participants")
    .withIndex("by_room", (q: any) => q.eq("roomId", roomId))
    .filter((q: any) => q.eq(q.field("leftAt"), undefined)) // Still in room
    .collect();

  return participants.length;
};

// Helper function to cleanup empty temporary rooms
const cleanupEmptyTemporaryRooms = async (
  ctx: any,
  rooms: any[]
): Promise<any[]> => {
  const roomsToKeep: any[] = [];

  for (const room of rooms) {
    // Check if this is a temporary room with no participants
    if (room.isTemporary === true) {
      const participantCount = await getParticipantCount(ctx, room._id);

      if (participantCount === 0) {
        // This temporary room is empty - delete it
        try {
          await ctx.runMutation(api.rooms.internalDeleteRoom, {
            roomId: room._id,
          });
          console.log(
            `🧹 Cleaned up empty temporary room: ${room.name} (${room._id})`
          );
          // Don't add to roomsToKeep since it's deleted
          continue;
        } catch (error) {
          console.error(
            `❌ Failed to cleanup temporary room ${room._id}:`,
            error
          );
          // If cleanup fails, keep the room for now
        }
      }
    }

    // Keep this room (either not temporary, or temporary but has participants)
    roomsToKeep.push(room);
  }

  return roomsToKeep;
};

// Helper function to enrich room with all required data
const enrichRoomData = async (
  ctx: any,
  room: any,
  currentUserId?: Id<"users">
): Promise<EnrichedRoom> => {
  // Get participant count
  const participantCount = await getParticipantCount(ctx, room._id);

  // Get creator data
  const creator = await ctx.db.get(room.creatorId);

  // Get company/experience data
  const company = await ctx.db.get(room.companyId);

  // Viewer roles
  const viewerIsCompanyOwner = currentUserId
    ? company?.owner === currentUserId
    : false;
  const canDelete = currentUserId === room.creatorId || !!viewerIsCompanyOwner;
  const viewerCanDelete = canDelete; // default; can be overwritten by callers with Whop access

  // Check if current user is a participant
  let isUserParticipant = false;
  if (currentUserId) {
    const participation = await ctx.db
      .query("participants")
      .withIndex("by_room_and_user", (q: any) =>
        q.eq("roomId", room._id).eq("userId", currentUserId)
      )
      .filter((q: any) => q.eq(q.field("leftAt"), undefined))
      .first();
    isUserParticipant = !!participation;
  }

  return {
    // Core LoungeCard fields
    _id: room._id,
    isActive: room.isActive,
    name: room.name,
    whopExperienceId: company?.whopExperienceId || "",
    whopCompanyLogo: room.roomImage || company?.logo || "",
    whopCompanyImageUrl: room.roomImage || company?.logo || "",
    whopCompanyName: company?.name || "Unknown Company",
    whopCompanyId: company?.whopCompanyId || "",
    category: room.category,
    isPublic: room.isPublic ?? true,
    participantCount,
    creatorName: creator?.fullName || "Unknown",
    creatorWhopUsername: creator?.whopUsername || "unknown",
    creatorAvatarUrl: creator?.avatarUrl || "",
    isUserParticipant,
    isCreator: currentUserId === room.creatorId,

    // Additional internal fields
    description: room.description,
    roomImage: room.roomImage,
    createdAt: room.createdAt,
    creatorId: room.creatorId,
    discoverListed: room.discoverListed,
    isTemporary: room.isTemporary,
    viewerIsCompanyOwner,
    canDelete,
    viewerCanDelete,
    companyPlanTier: company?.planTier,
  };
};

// Query 1: Active Rooms (User Priority)
// Returns all active rooms user can access (public + private they belong to), prioritizing rooms where user is a participant
export const getActiveRooms = query({
  args: {
    userId: v.id("users"),
    limit: v.optional(v.number()), // Default 10
  },
  handler: async (ctx, args): Promise<EnrichedRoom[]> => {
    const limit = args.limit || 10;

    // Step 1: Get all active public rooms
    let activePublicRooms = await ctx.db
      .query("rooms")
      .withIndex("by_public_and_active", (q) =>
        q.eq("isPublic", true).eq("isActive", true)
      )
      .collect();

    // Clean up empty temporary rooms
    activePublicRooms = await cleanupEmptyTemporaryRooms(
      ctx,
      activePublicRooms
    );

    // Step 2: Get all active private rooms where user is allowed
    let activePrivateRooms = await ctx.db
      .query("rooms")
      .filter((q) =>
        q.and(q.eq(q.field("isPublic"), false), q.eq(q.field("isActive"), true))
      )
      .collect();

    // Clean up empty temporary rooms
    activePrivateRooms = await cleanupEmptyTemporaryRooms(
      ctx,
      activePrivateRooms
    );

    // Filter private rooms to only those where user is in allowedUsers (by username)
    const viewer = await ctx.db.get(args.userId);
    const viewerUsername = viewer?.whopUsername || "";
    const userPrivateRooms = activePrivateRooms.filter((room) =>
      (room.allowedUsers || []).includes(viewerUsername)
    );

    // Step 3: Combine public and accessible private rooms
    const activeRooms = [...activePublicRooms, ...userPrivateRooms];

    // Step 4: Check which rooms user is participant in
    const userParticipations = await ctx.db
      .query("participants")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .filter((q) => q.eq(q.field("leftAt"), undefined)) // Still in room
      .collect();

    const userRoomIds = new Set(userParticipations.map((p) => p.roomId));

    // Step 5: Sort by user participation (user's rooms first)
    const sortedRooms = activeRooms.sort((a, b) => {
      const aUserRoom = userRoomIds.has(a._id) ? 1 : 0;
      const bUserRoom = userRoomIds.has(b._id) ? 1 : 0;
      return bUserRoom - aUserRoom; // User rooms first
    });

    // Step 6: Enrich with all required data
    const enrichedRooms = await Promise.all(
      sortedRooms.slice(0, limit).map(async (room) => {
        const enrichedRoom = await enrichRoomData(ctx, room, args.userId);
        return {
          ...enrichedRoom,
          isUserParticipant: userRoomIds.has(room._id),
        };
      })
    );

    // Final safety filter: ensure no empty temporary rooms are returned
    const finalRooms = enrichedRooms.filter((room) => {
      if (room.isTemporary === true && room.participantCount === 0) {
        console.log(
          `🚫 Filtered out empty temporary room from final results: ${room.name} (${room._id})`
        );
        return false;
      }
      return true;
    });

    return finalRooms;
  },
});

// Query 2: My Rooms (Created + Joined)
// Returns all rooms user has joined or created (persistent collection)
export const getMyRooms = query({
  args: {
    userId: v.id("users"),
    limit: v.optional(v.number()), // Default 10
  },
  handler: async (ctx, args): Promise<EnrichedRoom[]> => {
    const limit = args.limit || 10;

    // Get user's registered rooms
    const user = await ctx.db.get(args.userId);
    if (!user || !user.registeredRooms?.length) {
      return [];
    }

    // Fetch all registered rooms
    const registeredRooms = await Promise.all(
      user.registeredRooms.map(async (roomId) => {
        const room = await ctx.db.get(roomId);
        return room;
      })
    );

    // Filter out null/deleted rooms and clean up empty temporary rooms
    let validRooms = registeredRooms
      .filter((room) => room !== null)
      .sort((a, b) => b.createdAt - a.createdAt);

    // Clean up empty temporary rooms before limiting
    validRooms = await cleanupEmptyTemporaryRooms(ctx, validRooms);
    validRooms = validRooms.slice(0, limit);

    // Enrich with all required data and determine relationship
    const enrichedRooms = await Promise.all(
      validRooms.map(async (room) => {
        const enrichedRoom = await enrichRoomData(ctx, room, args.userId);

        // Determine relationship
        let relationship: "creator" | "member" = "member";
        if (room.creatorId === args.userId) {
          relationship = "creator";
        }

        return {
          ...enrichedRoom,
          relationship,
        };
      })
    );

    // Final safety filter: ensure no empty temporary rooms are returned
    const finalRooms = enrichedRooms.filter((room) => {
      if (room.isTemporary === true && room.participantCount === 0) {
        console.log(
          `🚫 Filtered out empty temporary room from final results: ${room.name} (${room._id})`
        );
        return false;
      }
      return true;
    });

    return finalRooms;
  },
});

// Query 3: Lounges in your Whop (Company-based)
export const getWhopLounges = query({
  args: {
    companyId: v.id("companies"),
    userId: v.id("users"),
    viewerWhopAccessLevel: v.optional(
      v.union(v.literal("admin"), v.literal("customer"), v.literal("no_access"))
    ),
    limit: v.optional(v.number()), // Default 10
  },
  handler: async (
    ctx,
    args
  ): Promise<{
    publicLounges: EnrichedRoom[];
    privateLounges: EnrichedRoom[];
  }> => {
    const limit = args.limit || 1000; // effectively all for company section

    // Fetch all rooms in company
    let companyRooms = await ctx.db
      .query("rooms")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();

    // Clean up empty temporary rooms before processing
    companyRooms = await cleanupEmptyTemporaryRooms(ctx, companyRooms);

    // Helper function to get activity timestamp
    const getActivity = (r: any) => r.lastActivityAt ?? r.createdAt;

    // Public lounges: active first, then inactive
    // Within each group, admin-created lounges come first
    const publicRooms = companyRooms.filter((r) => r.isPublic === true);

    const activePublic = publicRooms
      .filter((r) => r.isActive === true)
      .sort((a, b) => {
        // First sort by admin-created (admin-created first)
        const aIsAdmin =
          a.creatorId === args.userId || args.viewerWhopAccessLevel === "admin";
        const bIsAdmin =
          b.creatorId === args.userId || args.viewerWhopAccessLevel === "admin";
        if (aIsAdmin !== bIsAdmin) {
          return aIsAdmin ? -1 : 1;
        }
        // Then by activity (most recent first)
        return getActivity(b) - getActivity(a);
      });

    const inactivePublic = publicRooms
      .filter((r) => r.isActive === false || r.isActive === undefined)
      .sort((a, b) => {
        // Same sorting logic as active
        const aIsAdmin =
          a.creatorId === args.userId || args.viewerWhopAccessLevel === "admin";
        const bIsAdmin =
          b.creatorId === args.userId || args.viewerWhopAccessLevel === "admin";
        if (aIsAdmin !== bIsAdmin) {
          return aIsAdmin ? -1 : 1;
        }
        return getActivity(b) - getActivity(a);
      });

    // Private lounges: active first, then inactive (no internal ordering)
    const privateRooms = companyRooms.filter((r) => r.isPublic === false);

    const activePrivate = privateRooms
      .filter((r) => r.isActive === true)
      .sort((a, b) => getActivity(b) - getActivity(a));

    const inactivePrivate = privateRooms
      .filter((r) => r.isActive === false || r.isActive === undefined)
      .sort((a, b) => getActivity(b) - getActivity(a));

    // Combine and limit
    const publicLounges = [...activePublic, ...inactivePublic].slice(0, limit);
    const privateLounges = [...activePrivate, ...inactivePrivate].slice(
      0,
      limit
    );

    // Enrich both sets
    const enrichPublicRooms = await Promise.all(
      publicLounges.map(async (room) => {
        const enriched = await enrichRoomData(ctx, room, args.userId);
        const isSameCompany = room.companyId === args.companyId;
        const isCreator = enriched.isCreator;
        const isWhopAdmin = args.viewerWhopAccessLevel === "admin";
        const viewerCanDelete = isCreator || (isWhopAdmin && isSameCompany);
        return { ...enriched, viewerCanDelete };
      })
    );

    const enrichPrivateRooms = await Promise.all(
      privateLounges.map(async (room) => {
        const enriched = await enrichRoomData(ctx, room, args.userId);
        const isSameCompany = room.companyId === args.companyId;
        const isCreator = enriched.isCreator;
        const isWhopAdmin = args.viewerWhopAccessLevel === "admin";
        const viewerCanDelete = isCreator || (isWhopAdmin && isSameCompany);
        return { ...enriched, viewerCanDelete };
      })
    );

    // Final safety filter: ensure no empty temporary rooms are returned
    const finalPublicLounges = enrichPublicRooms.filter((room) => {
      if (room.isTemporary === true && room.participantCount === 0) {
        console.log(
          `🚫 Filtered out empty temporary room from final results: ${room.name} (${room._id})`
        );
        return false;
      }
      return true;
    });

    const finalPrivateLounges = enrichPrivateRooms.filter((room) => {
      if (room.isTemporary === true && room.participantCount === 0) {
        console.log(
          `🚫 Filtered out empty temporary room from final results: ${room.name} (${room._id})`
        );
        return false;
      }
      return true;
    });

    return {
      publicLounges: finalPublicLounges,
      privateLounges: finalPrivateLounges,
    };
  },
});

// Query 4: Explore Rooms (Category-based Discovery)
// Returns random rooms for exploration, optionally filtered by category
export const getExploreRooms = query({
  args: {
    category: v.optional(v.string()), // null = random selection
    limit: v.optional(v.number()), // Default 10
    companyId: v.id("companies"), // Exclude current company
  },
  handler: async (ctx, args): Promise<EnrichedRoom[]> => {
    const limit = args.limit || 10;

    // Active, public, discover-listed rooms outside this company
    let activePublic = await ctx.db
      .query("rooms")
      .withIndex("by_public_and_active", (q) =>
        q.eq("isPublic", true).eq("isActive", true)
      )
      .collect();

    // Clean up empty temporary rooms before filtering
    activePublic = await cleanupEmptyTemporaryRooms(ctx, activePublic);

    activePublic = activePublic.filter(
      (r) => r.companyId !== args.companyId && r.discoverListed === true
    );
    if (args.category)
      activePublic = activePublic.filter((r) => r.category === args.category);

    const getActivity = (r: any) => r.lastActivityAt ?? r.createdAt;
    activePublic.sort((a, b) => getActivity(b) - getActivity(a));

    const ordered = activePublic.slice(0, limit);

    const enrichedRooms = await Promise.all(
      ordered.map(async (room) => enrichRoomData(ctx, room))
    );

    // Final safety filter: ensure no empty temporary rooms are returned
    const finalRooms = enrichedRooms.filter((room) => {
      if (room.isTemporary === true && room.participantCount === 0) {
        console.log(
          `🚫 Filtered out empty temporary room from final results: ${room.name} (${room._id})`
        );
        return false;
      }
      return true;
    });

    return finalRooms;
  },
});

// Query 5: Live Lounges (Global - All Companies)
// Returns all currently active lounges with participants across all companies
export const getLiveLounges = query({
  handler: async (ctx): Promise<EnrichedRoom[]> => {
    // Get all active, public rooms with participants
    let activeRooms = await ctx.db
      .query("rooms")
      .withIndex("by_public_and_active", (q) =>
        q.eq("isPublic", true).eq("isActive", true)
      )
      .collect();

    // Clean up empty temporary rooms
    activeRooms = await cleanupEmptyTemporaryRooms(ctx, activeRooms);

    // Filter to only rooms with current participants
    activeRooms = activeRooms.filter(
      (room) => (room.participantCount || 0) > 0
    );

    // Shuffle randomly for mixed display
    const shuffled = activeRooms.sort(() => Math.random() - 0.5);

    // Enrich with participant and company data
    const enrichedRooms = await Promise.all(
      shuffled.map(async (room) => enrichRoomData(ctx, room))
    );

    return enrichedRooms;
  },
});

// Query 6: Categorized Lounges (Paginated)
// Returns lounges by category with pagination support
export const getCategorizedLounges = query({
  args: {
    category: v.string(), // "popular", "recent", "gaming", "business", etc.
    offset: v.optional(v.number()), // For pagination, default 0
    limit: v.optional(v.number()), // Default 8
  },
  handler: async (ctx, args): Promise<EnrichedRoom[]> => {
    const offset = args.offset || 0;
    const limit = args.limit || 8;

    // Get all public, discover-listed rooms (active or inactive)
    let rooms = await ctx.db
      .query("rooms")
      .withIndex("by_public", (q) => q.eq("isPublic", true))
      .collect();

    // Clean up empty temporary rooms
    rooms = await cleanupEmptyTemporaryRooms(ctx, rooms);

    // Filter to discover-listed rooms only
    rooms = rooms.filter((room) => room.discoverListed === true);

    // Apply category filtering and sorting
    if (args.category === "popular") {
      // Sort by maxParticipantsEverReached, then by lastActivityAt
      rooms.sort((a, b) => {
        const aMax = a.maxParticipantsEverReached || 0;
        const bMax = b.maxParticipantsEverReached || 0;
        if (bMax !== aMax) return bMax - aMax;
        return (
          (b.lastActivityAt || b.createdAt) - (a.lastActivityAt || a.createdAt)
        );
      });
    } else if (args.category === "recent") {
      // Sort by createdAt (newest first)
      rooms.sort((a, b) => b.createdAt - a.createdAt);
    } else {
      // Filter by specific category, then sort by activity
      rooms = rooms.filter((room) => room.category === args.category);
      rooms.sort(
        (a, b) =>
          (b.lastActivityAt || b.createdAt) - (a.lastActivityAt || a.createdAt)
      );
    }

    // Apply pagination
    const paginatedRooms = rooms.slice(offset, offset + limit);

    // Enrich with participant and company data
    const enrichedRooms = await Promise.all(
      paginatedRooms.map(async (room) => enrichRoomData(ctx, room))
    );

    return enrichedRooms;
  },
});

// Query 7: Room Categories (Enhanced with Popular/Recent)
// Returns available categories for filter dropdown with special categories first
export const getRoomCategories = query({
  args: {},
  handler: async () => {
    // Add special categories at the beginning
    const specialCategories = [
      {
        id: "popular",
        name: "Popular",
        icon: "🔥",
        color: "#ef4444",
        description: "Most popular lounges",
      },
      {
        id: "recent",
        name: "Recent",
        icon: "🆕",
        color: "#10b981",
        description: "Recently created lounges",
      },
    ];

    const regularCategories = ROOM_CATEGORIES.map((cat) => ({
      id: cat.id,
      name: cat.name,
      icon: cat.icon,
      color: cat.color,
      description: cat.description,
    }));

    return [...specialCategories, ...regularCategories];
  },
});

// Mutation: Cleanup Empty Temporary Rooms
// Can be called independently to clean up stale temporary rooms
export const cleanupEmptyTemporaryRoomsMutation = mutation({
  args: {
    companyId: v.optional(v.id("companies")), // Optional: clean specific company, or all if not provided
  },
  handler: async (ctx, args) => {
    let roomsToCheck;

    if (args.companyId) {
      // Clean specific company
      roomsToCheck = await ctx.db
        .query("rooms")
        .withIndex("by_company", (q) =>
          q.eq("companyId", args.companyId as Id<"companies">)
        )
        .filter((q) => q.eq(q.field("isTemporary"), true))
        .collect();
    } else {
      // Clean all temporary rooms across all companies
      roomsToCheck = await ctx.db
        .query("rooms")
        .filter((q) => q.eq(q.field("isTemporary"), true))
        .collect();
    }

    let cleanedCount = 0;

    for (const room of roomsToCheck) {
      const participantCount = await getParticipantCount(ctx, room._id);

      if (participantCount === 0) {
        try {
          await ctx.runMutation(api.rooms.internalDeleteRoom, {
            roomId: room._id,
          });
          cleanedCount++;
          console.log(
            `🧹 Cleaned up empty temporary room: ${room.name} (${room._id})`
          );
        } catch (error) {
          console.error(
            `❌ Failed to cleanup temporary room ${room._id}:`,
            error
          );
        }
      }
    }

    return { cleanedCount, totalChecked: roomsToCheck.length };
  },
});
