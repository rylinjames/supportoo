import JoinLoungeClient from "./join-lounge-client";

interface JoinLoungePageProps {
  params: Promise<{
    experienceId: string;
    loungeId: string;
  }>;
}

const JoinLoungePage = async ({ params }: JoinLoungePageProps) => {
  const { experienceId, loungeId } = await params;

  return <JoinLoungeClient experienceId={experienceId} loungeId={loungeId} />;
};

export default JoinLoungePage;
