import { useMemo } from "react";
import { Crown, Mic, Users } from "lucide-react";
import { ParticipantPopover } from "./participant-popover";
import { Participant } from "./types";

interface ParticipantStripProps {
  participants: Participant[];
  className?: string;
  // Props needed for ParticipantPopover functionality
  currentUserRole?: string;
  currentUserId?: string;
  roomCreatorId?: string;
  roomId: string;
  onAddToSpeakers?: (participantId: string) => void;
  onRemoveFromSpeakers?: (participantId: string) => void;
  onKickFromLounge?: (participantId: string) => void;
  onPromoteToModerator?: (participantId: string) => void;
  onDemoteModeratorToSpeaker?: (participantId: string) => void;
  canManageModerators?: boolean;
  whopCompanyId?: string;
}

export function ParticipantStrip({
  participants,
  className = "",
  currentUserRole,
  currentUserId,
  roomCreatorId,
  roomId,
  onAddToSpeakers,
  onRemoveFromSpeakers,
  onKickFromLounge,
  onPromoteToModerator,
  onDemoteModeratorToSpeaker,
  canManageModerators,
  whopCompanyId,
}: ParticipantStripProps) {
  /**
   * Sort participants by role hierarchy and speaking state
   */
  const sortedParticipants = useMemo(() => {
    return [...participants].sort((a, b) => {
      // Role priority: moderator (0) > speaker (1) > listener (2)
      const roleOrder = { moderator: 0, speaker: 1, listener: 2 };
      const roleComparison = roleOrder[a.role] - roleOrder[b.role];

      if (roleComparison !== 0) {
        return roleComparison;
      }

      // Within same role, speaking participants first
      if (a.isSpeaking !== b.isSpeaking) {
        return a.isSpeaking ? -1 : 1;
      }

      // Finally, local user first (using whopUserId comparison)
      const aIsLocal = a.whopUserId === currentUserId;
      const bIsLocal = b.whopUserId === currentUserId;
      if (aIsLocal !== bIsLocal) {
        return aIsLocal ? -1 : 1;
      }

      // Alphabetical by name
      return a.name.localeCompare(b.name);
    });
  }, [participants, currentUserId]);

  if (participants.length === 0) {
    return (
      <div
        className={`h-16 bg-gray-800 border-t border-gray-700 flex items-center justify-center ${className}`}
      >
        <p className="text-gray-500 text-sm">No participants</p>
      </div>
    );
  }

  return (
    <div className={`h-16 bg-gray-800 border-t border-gray-700 ${className}`}>
      <div className="h-full flex items-center px-4">
        {/* Participant count */}
        <div className="flex-shrink-0 mr-4">
          <div className="text-xs text-gray-400 font-medium">
            {participants.length} participant
            {participants.length !== 1 ? "s" : ""}
          </div>
        </div>

        {/* Scrollable participant list */}
        <div className="flex-1 overflow-x-auto">
          <div className="flex space-x-2 pb-1">
            {/* pb-1 for scrollbar space */}
            {sortedParticipants.map((participant, index) => (
              <ParticipantPopover
                key={participant.id}
                participant={participant}
                index={index}
                size="small"
                currentUserRole={currentUserRole}
                currentUserId={currentUserId}
                isRoomCreator={participant.convexUserId === roomCreatorId}
                onAddToSpeakers={onAddToSpeakers}
                onRemoveFromSpeakers={onRemoveFromSpeakers}
                onKickFromLounge={onKickFromLounge}
                onPromoteToModerator={onPromoteToModerator}
                onDemoteModeratorToSpeaker={onDemoteModeratorToSpeaker}
                canManageModerators={canManageModerators}
                roomId={roomId}
                convexUserId={participant.convexUserId}
                whopCompanyId={whopCompanyId}
              />
            ))}
          </div>
        </div>

        {/* Scroll hint (only show if scrollable) */}
        {participants.length > 6 && (
          <div className="flex-shrink-0 ml-2">
            <div className="text-xs text-gray-500">← scroll →</div>
          </div>
        )}
      </div>
    </div>
  );
}
