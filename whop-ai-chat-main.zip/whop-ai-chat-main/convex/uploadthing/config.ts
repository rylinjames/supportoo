/**
 * UploadThing Configuration
 *
 * Setup and configuration for UploadThing file uploads.
 */

"use node";

import { UTApi } from "uploadthing/server";

/**
 * Get UploadThing configuration from environment
 */
export function getUploadThingConfig() {
  const token = process.env.UPLOADTHING_TOKEN;

  if (!token) {
    throw new Error("UPLOADTHING_SECRET environment variable is required");
  }

  return {
    token,
  };
}

/**
 * Get UploadThing API instance
 */
export function getUploadThingAPI() {
  const { token } = getUploadThingConfig();
  return new UTApi({ token });
}

/**
 * File upload limits by type
 */
export const FILE_LIMITS = {
  // Company context files
  pdf: {
    maxSize: 10 * 1024 * 1024, // 10MB
    allowedTypes: ["application/pdf"] as string[],
  },
  // Chat attachments (images only for pro plan)
  image: {
    maxSize: 2 * 1024 * 1024, // 2MB
    allowedTypes: [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
    ] as string[],
  },
};

/**
 * Validate file size and type
 */
export function validateFile(
  fileSize: number,
  fileType: string,
  category: "pdf" | "image"
): { valid: boolean; error?: string } {
  const limits = FILE_LIMITS[category];

  if (fileSize > limits.maxSize) {
    return {
      valid: false,
      error: `File too large. Max size: ${limits.maxSize / 1024 / 1024}MB`,
    };
  }

  if (!limits.allowedTypes.includes(fileType)) {
    return {
      valid: false,
      error: `Invalid file type. Allowed: ${limits.allowedTypes.join(", ")}`,
    };
  }

  return { valid: true };
}
