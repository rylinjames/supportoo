"use node";

import { action } from "./_generated/server";
import { v } from "convex/values";
import { WhopServerSdk } from "@whop/api";
import { Whop } from "@whop/sdk";
import { api } from "./_generated/api";

const whopApi = WhopServerSdk({
  appApiKey: process.env.WHOP_API_KEY!,
  appId: process.env.NEXT_PUBLIC_WHOP_APP_ID!,
  apiOrigin: "https://api.whop.com",
});

const whopInstance = new Whop({
  apiKey: process.env.WHOP_API_KEY!,
  appID: process.env.NEXT_PUBLIC_WHOP_APP_ID!,
});

// Send a DM to a Whop user by username when they are invited to a private lounge
export const sendInviteDm = action({
  args: {
    inviteeWhopUsername: v.string(),
    inviterWhopUsername: v.optional(v.string()),
    inviterWhopUserId: v.optional(v.string()),
    roomName: v.string(),
    experienceId: v.string(),
    roomId: v.id("rooms"),
    whopCompanyId: v.optional(v.string()),
    companyName: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const baseUrl = process.env.NEXT_PUBLIC_WHOP_APP_URL || "";
    const whopDeepLink = args.whopCompanyId
      ? `${baseUrl}/${args.whopCompanyId}/${args.experienceId}/app/`
      : null;
    const appPath = `/experiences/${args.experienceId}/join/${args.roomId}`;
    const link = whopDeepLink || (baseUrl ? `${baseUrl}${appPath}` : appPath);

    // No verbose logs in production; minimal debugging

    try {
      // Determine sender with fallback order: inviter first, then agent user
      const candidateUserIds = [
        args.inviterWhopUserId,
        process.env.NEXT_PUBLIC_WHOP_AGENT_USER_ID,
      ].filter(Boolean) as string[];

      let selectedUserId: string | undefined;
      for (const candidate of candidateUserIds) {
        try {
          await whopApi.withUser(candidate).users.getCurrentUser();
          selectedUserId = candidate;
          break;
        } catch (_) {}
      }

      if (!selectedUserId) {
        return {
          success: false,
          error: "sanity_failed: no valid sender context",
        };
      }

      // Construct professional message, clarifying agent-on-behalf scenario
      const isAgentSender = args.inviterWhopUserId
        ? selectedUserId !== args.inviterWhopUserId
        : true;
      const inviterHandle = args.inviterWhopUsername
        ? `@${args.inviterWhopUsername}`
        : "a member";
      const companyPrefix = args.companyName ? ` in ${args.companyName}` : "";
      const message = isAgentSender
        ? `${inviterHandle} has invited you to join their private lounge “${args.roomName}”${companyPrefix}. Tap to join: ${link}`
        : `Hey! Come hang in my private lounge “${args.roomName}”${companyPrefix}. Tap to join: ${link}`;

      const baseClient = whopApi.withUser(selectedUserId);
      const client = args.whopCompanyId
        ? baseClient.withCompany(args.whopCompanyId)
        : baseClient;
      await client.messages.sendDirectMessageToUser({
        toUserIdOrUsername: args.inviteeWhopUsername,
        message,
      });
      return { success: true };
    } catch (error) {
      return { success: false, error: "failed_to_send_dm" };
    }
  },
});

// Check if a Whop user is an admin of a given Whop company
export const checkUserIsCompanyAdmin = action({
  args: {
    whopUserId: v.string(),
    whopCompanyId: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const access = await whopApi.access.checkIfUserHasAccessToCompany({
        companyId: args.whopCompanyId,
        userId: args.whopUserId,
      });
      const accessLevel = access?.accessLevel || "no_access";
      return { isAdmin: accessLevel === "admin", accessLevel };
    } catch (error) {
      return {
        isAdmin: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  },
});

// Create a checkout session for plans/credit packs using the Whop Payments SDK
// Uses createCheckoutSession to ensure metadata is properly preserved in webhooks
export const createCharge = action({
  args: {
    userId: v.string(),
    experienceId: v.string(),
    planId: v.string(), // Whop plan/product ID
    amount: v.number(), // Amount in dollars (will be converted to cents)
    title: v.string(),
    metadata: v.optional(
      v.object({
        type: v.union(v.literal("plan"), v.literal("credits")),
        planTier: v.optional(v.string()),
        credits: v.optional(v.number()),
        traceId: v.optional(v.string()),
        companyId: v.optional(v.string()),
      })
    ),
  },
  handler: async (
    ctx,
    args
  ): Promise<{
    success: boolean;
    error?: string;
    traceId: string;
    status?: string;
    session?: {
      planId: string;
      sessionId?: string;
      status: string;
      amount: number;
      title: string;
    };
  }> => {
    const traceId =
      args.metadata?.traceId ||
      `tr_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;

    console.log(`[WHOP] Creating checkout session`, {
      traceId,
      userId: args.userId,
      planId: args.planId,
      amount: args.amount,
      type: args.metadata?.type,
      timestamp: new Date().toISOString(),
      companyId: args.metadata?.companyId,
    });

    try {
      // Validate user exists via mutation (actions can't access ctx.db directly)
      const validationResult: {
        success: boolean;
        error?: string;
        convexUserId?: string;
      } = await ctx.runMutation(
        api.whopPaymentsMutations.validateUserForCharge,
        {
          userId: args.userId,
          experienceId: args.experienceId,
        }
      );

      if (!validationResult.success) {
        console.error(`[WHOP] User validation failed`, {
          traceId,
          userId: args.userId,
          error: validationResult.error,
        });
        return {
          success: false,
          error: validationResult.error || "User validation failed",
          traceId,
        };
      }

      // Create checkout session using Whop Payments SDK
      // This creates a checkout configuration with metadata that will be preserved in webhooks
      const checkoutSession = await whopApi.payments.createCheckoutSession({
        planId: args.planId,
        metadata: {
          experienceId: args.experienceId,
          convexUserId: validationResult.convexUserId,
          planId: args.planId,
          traceId,
          ...(args.metadata || {}),
        },
      });

      if (!checkoutSession || !checkoutSession.id) {
        throw new Error("No checkout session created");
      }

      console.log(`[WHOP] Checkout session created successfully`, {
        traceId,
        sessionId: checkoutSession.id,
        planId: checkoutSession.planId,
        timestamp: new Date().toISOString(),
        companyId: args.metadata?.companyId,
      });

      return {
        success: true,
        status: "created",
        traceId,
        // Return session details for client inAppPurchase call
        session: {
          planId: args.planId,
          sessionId: checkoutSession.id,
          status: "created",
          amount: args.amount,
          title: args.title,
        },
      };
    } catch (error) {
      console.error(`[WHOP] Checkout session creation failed`, {
        traceId,
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
      });

      return {
        success: false,
        error:
          error instanceof Error ? error.message : "Failed to create charge",
        traceId,
      };
    }
  },
});

/**
 * Create checkout session for plan upgrade/downgrade
 *
 * Validates user permissions and returns plan details for checkout.
 * Used in two-step upgrade flow: cancel current membership, then create checkout.
 */
export const createCheckoutSession = action({
  args: {
    companyId: v.id("companies"),
    targetPlanTier: v.union(
      v.literal("free"),
      v.literal("starter"),
      v.literal("pro"),
      v.literal("creator")
    ),
    whopUserId: v.string(),
    allowDowngrade: v.optional(v.boolean()), // Allow downgrades after cancellation
  },
  handler: async (
    ctx,
    { companyId, targetPlanTier, whopUserId, allowDowngrade }
  ): Promise<{
    success: boolean;
    planId: string;
    targetPlanTier: string;
    planPrice: number;
    planTitle: string;
  }> => {
    // 1. Get company
    const company = await ctx.runQuery(api.companies.getCompanyById, {
      companyId,
    });

    if (!company) {
      throw new Error("Company not found");
    }

    // 2. Verify user is admin or plan owner
    const isPlanOwner = company.planOwner === whopUserId;
    let isAdmin = false;

    if (!isPlanOwner) {
      const adminCheck = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
        whopUserId,
        whopCompanyId: company.whopCompanyId,
      });
      isAdmin = adminCheck.isAdmin;
    }

    if (!isPlanOwner && !isAdmin) {
      throw new Error(
        "Only admins or plan owners can create checkout sessions"
      );
    }

    // 3. Get target plan
    const targetPlan = await ctx.runQuery(api.planManagement.getPlanByTier, {
      tier: targetPlanTier,
    });

    if (!targetPlan || !targetPlan.whopPlanId) {
      throw new Error(
        `Target plan ${targetPlanTier} not found or not available for purchase`
      );
    }

    // 4. Get current plan for hierarchy check
    const planSettings = await ctx.runQuery(api.plans.getCompanyPlanSettings, {
      companyId,
    });
    const currentTier = planSettings?.planTier || "free";

    // 5. Check plan hierarchy (unless explicitly allowed after cancellation)
    if (!allowDowngrade) {
      const planHierarchy: Record<string, number> = {
        free: 0,
        starter: 1,
        pro: 2,
        creator: 3,
      };

      if (planHierarchy[targetPlanTier] <= planHierarchy[currentTier]) {
        throw new Error(
          `Cannot upgrade to ${targetPlanTier} plan (already on ${currentTier} or higher). Use allowDowngrade flag if this is a downgrade after cancellation.`
        );
      }
    }

    console.log(
      `✅ Checkout session validated for ${company.name}: ${currentTier} → ${targetPlanTier}`
    );
    console.log(`  Plan ID: ${targetPlan.whopPlanId}`);

    return {
      success: true,
      planId: targetPlan.whopPlanId,
      targetPlanTier,
      planPrice: targetPlan.priceUsd,
      planTitle: `${targetPlan.name} Plan`,
    };
  },
});

// Cancel Whop membership for plan downgrade
// Only admins/plan owners can cancel memberships
// Cancellation takes effect at the end of the current billing period
export const cancelMembership = action({
  args: {
    companyId: v.id("companies"),
    whopUserId: v.string(),
  },
  handler: async (
    ctx,
    { companyId, whopUserId }
  ): Promise<{
    success: boolean;
    message: string;
  }> => {
    // 1. Get company
    const company = await ctx.runQuery(api.companies.getCompanyById, {
      companyId,
    });

    if (!company) {
      throw new Error("Company not found");
    }

    if (!company.whopMembershipId) {
      throw new Error("No active membership to cancel");
    }

    // 2. Verify user is admin or plan owner
    const isPlanOwner = company.planOwner === whopUserId;

    let isAdmin = false;
    if (!isPlanOwner) {
      const adminCheck = await ctx.runAction(api.whop.checkUserIsCompanyAdmin, {
        whopUserId,
        whopCompanyId: company.whopCompanyId,
      });
      isAdmin = adminCheck.isAdmin;
    }

    if (!isPlanOwner && !isAdmin) {
      throw new Error("Only admins or plan owners can cancel memberships");
    }

    // 3. Call Whop API to cancel membership
    try {
      // Cancel membership via Whop SDK
      // Returns membership object with cancel_at_period_end: true
      const cancelledMembership = await whopInstance.memberships.cancel(
        company.whopMembershipId,
        {
          cancellation_mode: "at_period_end",
        }
      );

      console.log(`✅ Cancelled Whop membership: ${company.whopMembershipId}`);
      console.log(
        `   Cancel at period end: ${cancelledMembership.cancel_at_period_end}`
      );

      // Get renewal_period_end from Whop response or use currentPeriodEnd or calculate
      const renewalPeriodEnd = cancelledMembership.renewal_period_end;
      const periodEnd =
        renewalPeriodEnd && typeof renewalPeriodEnd === "number"
          ? renewalPeriodEnd * 1000 // Convert to ms
          : company.currentPeriodEnd
            ? company.currentPeriodEnd
            : Date.now() + 30 * 24 * 60 * 60 * 1000; // Fallback: 30 days from now

      console.log(`   Period ends: ${new Date(periodEnd).toISOString()}`);

      // 4. Get free plan ID for scheduled downgrade
      const freePlan = await ctx.runQuery(api.planManagement.getPlanByTier, {
        tier: "free",
      });

      if (!freePlan) {
        throw new Error("Free plan not found in database");
      }

      // 5. Schedule the downgrade
      await ctx.runMutation(api.whopPaymentsMutations.schedulePlanDowngrade, {
        companyId,
        scheduledPlanId: freePlan._id,
        scheduledFor: periodEnd,
      });

      // 6. Record billing event for cancellation
      try {
        await ctx.runMutation(api.whopPaymentsMutations.recordBillingEvent, {
          companyId,
          eventType: "subscription_cancelled",
          whopMembershipId: company.whopMembershipId!,
          whopUserId,
          whopPlanId: "",
          newPlanId: freePlan._id,
        });
        console.log(`✅ Recorded billing event for cancellation`);
      } catch (error) {
        console.error(`⚠️ Failed to record billing event:`, error);
        // Don't fail the cancellation if event recording fails
      }

      return {
        success: true,
        message:
          "Membership cancelled. You'll be downgraded to Free at the end of your billing period.",
      };
    } catch (error) {
      console.error("❌ Failed to cancel Whop membership:", error);
      throw new Error(
        `Failed to cancel membership: ${error instanceof Error ? error.message : "Unknown error"}`
      );
    }
  },
});
