import ImageKit from "imagekit";

// Server-side ImageKit instance (for backend operations only)
export const imagekit = new ImageKit({
  publicKey: process.env.NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY!,
  privateKey: process.env.IMAGEKIT_PRIVATE_KEY!,
  urlEndpoint: process.env.NEXT_PUBLIC_IMAGEKIT_URL_ENDPOINT!,
});

// Helper function to delete images from ImageKit (server-side only)
export async function deleteImageFromImageKit(fileId: string) {
  try {
    await imagekit.deleteFile(fileId);
    return { success: true };
  } catch (error) {
    console.error("Failed to delete image from ImageKit:", error);
    return { success: false, error: String(error) };
  }
}

// Helper function to get image details (server-side only)
export async function getImageDetails(fileId: string) {
  try {
    const details = await imagekit.getFileDetails(fileId);
    return { success: true, data: details };
  } catch (error) {
    console.error("Failed to get image details from ImageKit:", error);
    return { success: false, error: String(error) };
  }
}
