"use client";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ArrowDown, Info } from "lucide-react";

interface MidTierDowngradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  targetPlan: {
    name: string;
    tier: string | undefined;
  } | null;
  onConfirm: () => void;
}

export default function MidTierDowngradeModal({
  open,
  onOpenChange,
  targetPlan,
  onConfirm,
}: MidTierDowngradeModalProps) {
  if (!targetPlan) return null;

  const handleConfirm = () => {
    onConfirm();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-background border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white max-w-md max-h-[85vh] overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-center gap-3 mb-2">
            <ArrowDown className="w-6 h-6 text-yellow-600 dark:text-yellow-500" />
            <DialogTitle className="text-xl font-semibold text-neutral-900 dark:text-white">
              Downgrade to {targetPlan.name}
            </DialogTitle>
          </div>
          <DialogDescription className="text-neutral-600 dark:text-neutral-400">
            Your current plan will be cancelled and replaced with{" "}
            {targetPlan.name}.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4 overflow-y-auto flex-1">
          <div className="p-4 rounded-lg border border-yellow-200 dark:border-yellow-700/50 bg-yellow-50 dark:bg-yellow-900/10">
            <div className="space-y-3">
              <p className="text-sm text-yellow-900 dark:text-yellow-200 font-medium">
                Two-step process:
              </p>
              <ol className="text-sm text-yellow-800 dark:text-yellow-100 space-y-2 list-decimal list-inside">
                <li>Your current plan will be cancelled (at period end)</li>
                <li>You'll be charged for {targetPlan.name} immediately</li>
                <li>New plan features will be available right away</li>
              </ol>
            </div>
          </div>

          <div className="p-4 rounded-lg border border-blue-200 dark:border-blue-700/50 bg-blue-50 dark:bg-blue-900/20">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <p className="text-sm text-blue-900 dark:text-blue-200 font-medium">
                  What happens:
                </p>
              </div>
              <ul className="text-sm text-blue-800 dark:text-blue-100 space-y-1 list-disc list-inside">
                <li>Current plan cancels at the end of billing period</li>
                <li>New plan starts immediately after payment</li>
                <li>You keep access until the current period ends</li>
                <li>You'll save money on the lower tier plan</li>
              </ul>
            </div>
          </div>
        </div>

        <DialogFooter className="flex flex-col gap-3 sm:flex-row">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="w-full sm:w-auto"
          >
            Cancel
          </Button>
          <Button onClick={handleConfirm} className="w-full sm:w-auto">
            Continue to Payment
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
