/**
 * Atomic Billing Operations
 *
 * Prevents race conditions and minute leakage in concurrent billing scenarios.
 * All minute charging operations should go through these atomic functions.
 */

import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { Id } from "./_generated/dataModel";
import { api } from "./_generated/api";

/**
 * Atomically increment company minutes with proper credit deduction
 * This prevents race conditions when multiple participants bill simultaneously
 */
export const atomicIncrementCompanyMinutes = mutation({
  args: {
    companyId: v.id("companies"),
    deltaMinutes: v.number(),
    participantId: v.optional(v.id("participants")), // For logging
  },
  handler: async (
    ctx,
    args
  ): Promise<{
    success: boolean;
    usedBefore: number;
    usedAfter: number;
    included: number;
    creditsDeducted: number;
    duration: number;
  }> => {
    if (args.deltaMinutes <= 0) {
      throw new Error("Delta minutes must be positive");
    }

    const startTime = Date.now();

    try {
      // Get current company state
      const company = await ctx.db.get(args.companyId);
      if (!company) {
        throw new Error("Company not found");
      }

      const usedBefore =
        typeof company.minutesUsedThisMonth === "number"
          ? company.minutesUsedThisMonth
          : 0;

      // Get plan settings to determine included minutes
      const settings: { effectiveIncludedMinutes: number; planTier: string } =
        await ctx.runQuery(api.plans.getCompanyPlanSettings, {
          companyId: args.companyId,
        });
      const included: number = settings.effectiveIncludedMinutes || 0;

      // Calculate new usage
      const usedAfter = usedBefore + args.deltaMinutes;

      // Calculate credit deduction (only for overage beyond included minutes)
      const overageBefore = Math.max(0, usedBefore - included);
      const overageAfter = Math.max(0, usedAfter - included);
      const creditsToDeduct = Math.max(0, overageAfter - overageBefore);

      // Atomically update company minutes first
      await ctx.db.patch(args.companyId, {
        minutesUsedThisMonth: usedAfter,
        updatedAt: Date.now(),
      });

      // Deduct credits if necessary (FIFO)
      let actualCreditsDeducted = 0;
      if (creditsToDeduct > 0) {
        actualCreditsDeducted = await atomicDeductCredits(
          ctx,
          args.companyId,
          creditsToDeduct
        );
      }

      // Update monthly aggregate
      await updateMonthlyAggregate(
        ctx,
        args.companyId,
        args.deltaMinutes,
        settings
      );

      const endTime = Date.now();
      const duration = endTime - startTime;

      console.log(
        `💰 [ATOMIC] Company ${args.companyId}: charged ${args.deltaMinutes} min` +
          (args.participantId ? ` (participant ${args.participantId})` : "") +
          ` | ${usedBefore}→${usedAfter}/${included} included | ${actualCreditsDeducted} credits deducted | ${duration}ms`
      );

      return {
        success: true,
        usedBefore,
        usedAfter,
        included,
        creditsDeducted: actualCreditsDeducted,
        duration,
      };
    } catch (error) {
      const endTime = Date.now();
      const duration = endTime - startTime;

      console.error(
        `❌ [ATOMIC] Billing failed for company ${args.companyId}:`,
        error,
        `| ${duration}ms`
      );

      throw error;
    }
  },
});

/**
 * Atomically deduct credits using FIFO (First In, First Out) logic
 * Returns the actual amount deducted
 */
async function atomicDeductCredits(
  ctx: any,
  companyId: Id<"companies">,
  debitMinutes: number
): Promise<number> {
  // Get all available credits sorted by creation date (FIFO)
  const credits = await ctx.db
    .query("companyMinuteCredits")
    .withIndex("by_company", (q: any) => q.eq("companyId", companyId))
    .filter((q: any) => q.gt(q.field("remainingMinutes"), 0))
    .collect();

  // Sort by creation date for FIFO
  credits.sort((a: any, b: any) => a.purchasedAt - b.purchasedAt);

  let remainingToDeduct = debitMinutes;
  let totalDeducted = 0;

  for (const credit of credits) {
    if (remainingToDeduct <= 0) break;

    const available = Math.max(0, credit.remainingMinutes || 0);
    if (available <= 0) continue;

    const toDeduct = Math.min(available, remainingToDeduct);
    const newRemaining = available - toDeduct;

    // Atomically update this credit record
    await ctx.db.patch(credit._id, {
      remainingMinutes: newRemaining,
    });

    totalDeducted += toDeduct;
    remainingToDeduct -= toDeduct;

    console.log(
      `🔹 Credit ${credit._id}: deducted ${toDeduct}, remaining ${newRemaining}`
    );
  }

  if (remainingToDeduct > 0) {
    console.warn(
      `⚠️ Could not deduct ${remainingToDeduct} minutes - insufficient credits`
    );
  }

  return totalDeducted;
}

/**
 * Update monthly usage aggregate atomically
 */
async function updateMonthlyAggregate(
  ctx: any,
  companyId: Id<"companies">,
  deltaMinutes: number,
  settings: any
): Promise<void> {
  const now = Date.now();
  const ym = yearMonthUtc(now);

  // Find or create monthly record
  let monthly = await ctx.db
    .query("companyUsageMonthly")
    .withIndex("by_company_and_month", (q: any) =>
      q.eq("companyId", companyId).eq("yearMonth", ym)
    )
    .first();

  if (!monthly) {
    // Create new monthly record
    await ctx.db.insert("companyUsageMonthly", {
      companyId,
      yearMonth: ym,
      totalMinutes: deltaMinutes,
      includedMinutesAtStart: settings.effectiveIncludedMinutes || 0,
      planTierAtStart: settings.planTier as any,
      createdAt: now,
      updatedAt: now,
    });
  } else {
    // Atomically increment existing record
    const currentTotal = monthly.totalMinutes || 0;
    await ctx.db.patch(monthly._id, {
      totalMinutes: currentTotal + deltaMinutes,
      updatedAt: now,
    });
  }
}

/**
 * Get company usage with proper read consistency
 */
export const getCompanyUsageAtomic = query({
  args: { companyId: v.id("companies") },
  handler: async (
    ctx,
    args
  ): Promise<{
    used: number;
    included: number;
    creditsRemainingTotal: number;
    available: number;
    renewalAt: number;
    planTier: string;
  }> => {
    const company = await ctx.db.get(args.companyId);
    if (!company) {
      throw new Error("Company not found");
    }

    // Get plan settings
    const settings: { effectiveIncludedMinutes: number; planTier: string } =
      await ctx.runQuery(api.plans.getCompanyPlanSettings, {
        companyId: args.companyId,
      });

    const included: number = settings.effectiveIncludedMinutes || 0;
    const used = Math.max(0, company.minutesUsedThisMonth || 0);

    // Get credits
    const credits = await ctx.db
      .query("companyMinuteCredits")
      .withIndex("by_company", (q: any) => q.eq("companyId", args.companyId))
      .collect();

    const creditsRemainingTotal = credits.reduce(
      (acc: number, c: any) => acc + Math.max(0, c.remainingMinutes || 0),
      0
    );

    const available = Math.max(0, included - used) + creditsRemainingTotal;
    const renewalAt = company.planRenewsAt || 0;

    return {
      used,
      included,
      creditsRemainingTotal,
      available,
      renewalAt,
      planTier: settings.planTier,
    };
  },
});

/**
 * Coordination lock for monthly rollover to prevent billing during reset
 */
export const monthlyRolloverWithLock = mutation({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const companies = await ctx.db.query("companies").collect();
    let rolled = 0;
    const errors: string[] = [];

    for (const company of companies) {
      const renewAt = company.planRenewsAt as number | undefined;
      if (!renewAt || renewAt > now) {
        continue; // Not due for renewal
      }

      try {
        // Set rollover lock
        await ctx.db.patch(company._id, {
          isRollingOver: true,
          updatedAt: now,
        });

        // Wait a brief moment for any ongoing billing to complete
        await new Promise((resolve) => setTimeout(resolve, 100));

        // Perform rollover operations
        const settings = await ctx.runQuery(api.plans.getCompanyPlanSettings, {
          companyId: company._id,
        });

        // Create new monthly record
        const ym = yearMonthUtc(now);
        const existing = await ctx.db
          .query("companyUsageMonthly")
          .withIndex("by_company_and_month", (q: any) =>
            q.eq("companyId", company._id).eq("yearMonth", ym)
          )
          .first();

        if (!existing) {
          await ctx.db.insert("companyUsageMonthly", {
            companyId: company._id,
            yearMonth: ym,
            totalMinutes: 0,
            includedMinutesAtStart: settings.effectiveIncludedMinutes || 0,
            planTierAtStart: settings.planTier,
            createdAt: now,
            updatedAt: now,
          });
        }

        // Reset counters and advance renewal
        const nextRenewal = getNextMonthStartUtc(now);
        await ctx.db.patch(company._id, {
          minutesUsedThisMonth: 0,
          planRenewsAt: nextRenewal,
          isRollingOver: false, // Release lock
          updatedAt: now,
        });

        rolled++;
        console.log(
          `🔄 Rolled over company ${company._id} to ${new Date(nextRenewal).toISOString()}`
        );
      } catch (error) {
        // Release lock on error
        await ctx.db.patch(company._id, {
          isRollingOver: false,
          updatedAt: now,
        });

        const errorMsg = `Failed to rollover company ${company._id}: ${error}`;
        errors.push(errorMsg);
        console.error(errorMsg);
      }
    }

    return { rolled, errors };
  },
});

// Helper functions
function yearMonthUtc(ms: number): string {
  const d = new Date(ms);
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth() + 1;
  return `${y}-${String(m).padStart(2, "0")}`;
}

function getNextMonthStartUtc(nowMs: number): number {
  const d = new Date(nowMs);
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth();
  return new Date(Date.UTC(y, m + 1, 1, 0, 0, 0, 0)).getTime();
}
