"use client";

import { z } from "zod";
import {
  UseFormRegister,
  UseFormHandleSubmit,
  FieldErrors,
} from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Switch } from "@/components/animate-ui/radix/switch";
import { ThemeToggler } from "../shared/theme-toggler";
import { AudioDevicesSection } from "./audio-devices-section";

// Listener settings schema (includes anonymous option)
export const listenerSettingsSchema = z.object({
  isAnonymous: z.boolean(),
});

export type ListenerSettingsFormData = z.infer<typeof listenerSettingsSchema>;

interface ListenerViewProps {
  register: UseFormRegister<ListenerSettingsFormData>;
  handleSubmit: UseFormHandleSubmit<ListenerSettingsFormData>;
  errors: FieldErrors<ListenerSettingsFormData>;
  isDirty: boolean;
  isSubmitting: boolean;
  reset: () => void;
  userId: string;
  currentIsAnonymous?: boolean;
  localParticipant?: any; // LiveKit local participant
}

export function ListenerView({
  register,
  handleSubmit,
  errors,
  isDirty,
  isSubmitting,
  reset,
  userId,
  currentIsAnonymous = false,
  localParticipant,
}: ListenerViewProps) {
  const updateUserSettingsMutation = useMutation(api.users.updateUserSettings);

  const onSubmit = async (data: ListenerSettingsFormData) => {
    try {
      await updateUserSettingsMutation({
        userId: userId as any, // Type assertion for Convex ID
        isAnonymous: data.isAnonymous,
      });
    } catch (error) {
      console.error("Failed to update listener settings:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Appearance Settings */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-neutral-800 dark:text-white">
          User Settings
        </h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-neutral-800 dark:text-neutral-400">
              Change theme
            </span>
            <ThemeToggler />
          </div>
        </div>
      </div>

      <Separator className="bg-neutral-200 dark:bg-neutral-700" />

      {/* Privacy Settings */}
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-neutral-800 dark:text-neutral-400">
          Privacy
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-sm font-medium text-neutral-800 dark:text-neutral-400">
                Anonymous Mode
              </Label>
              <p className="text-xs text-neutral-600 dark:text-neutral-400">
                When enabled, you'll appear as "Anonymous" with a placeholder
                avatar.
              </p>
            </div>
            <Switch {...register("isAnonymous")} checked={currentIsAnonymous} />
          </div>

          {/* Anonymous Mode Preview */}
          {currentIsAnonymous && (
            <div className="mt-3 p-3 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700">
              <p className="text-xs text-neutral-600 dark:text-neutral-400 mb-2">
                Anonymous mode preview:
              </p>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-neutral-300 dark:bg-neutral-600 rounded-full flex items-center justify-center">
                  <span className="text-xs text-neutral-600 dark:text-neutral-400">
                    👤
                  </span>
                </div>
                <span className="text-sm text-neutral-700 dark:text-neutral-300">
                  Anonymous
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Audio Devices Settings */}
      <AudioDevicesSection localParticipant={localParticipant} />

      {/* Form Actions */}
      <div className="flex justify-end space-x-2 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={reset}
          disabled={!isDirty || isSubmitting}
        >
          Reset
        </Button>
        <Button type="submit" disabled={!isDirty || isSubmitting}>
          {isSubmitting ? "Saving..." : "Save Changes"}
          <span className="ml-2 text-xs opacity-70">(Enter)</span>
        </Button>
      </div>
    </form>
  );
}
