"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import SettingsModalView from "./settings-modal-view";

interface SettingsModalProps {
  currentUserRole?: string;
  roomId: string;
  whopUserData: {
    _id: string;
    whopUserId: string;
    whopUsername: string;
    fullName: string;
  };
  roomDetails?: any; // Room details from Convex
  localParticipant?: any; // LiveKit local participant
}

const SettingsModal = ({
  currentUserRole,
  roomId,
  whopUserData,
  roomDetails,
  localParticipant,
}: SettingsModalProps) => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white">
          <Settings className="w-4 h-4 mr-2" />
          Settings
        </Button>
      </DialogTrigger>
      <DialogContent
        onOpenAutoFocus={(e) => e.preventDefault()}
        className="bg-background text-neutral-900 dark:text-white max-w-md max-h-[80vh] overflow-y-auto"
        onKeyDown={(e) => {
          // Escape key closes the modal (handled by Dialog)
          // Enter key submits the form (handled by form elements)
          if (e.key === "Enter") {
            // Ctrl+Enter as an alternative submit shortcut
            e.preventDefault();
            const submitButton = e.currentTarget.querySelector(
              'button[type="submit"]'
            ) as HTMLButtonElement;
            if (submitButton && !submitButton.disabled) {
              submitButton.click();
            }
          }
        }}
      >
        <DialogHeader>
          <DialogTitle className="text-2xl font-semibold text-neutral-800 dark:text-white">
            {currentUserRole === "moderator" ? "Room Settings" : "Settings"}
          </DialogTitle>
        </DialogHeader>

        <SettingsModalView
          currentUserRole={currentUserRole}
          roomId={roomId}
          whopUserData={whopUserData}
          roomDetails={roomDetails}
          localParticipant={localParticipant}
        />
      </DialogContent>
    </Dialog>
  );
};

export default SettingsModal;
