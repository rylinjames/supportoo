"use client";

import { useRouter } from "next/navigation";

interface LoungeErrorStatesProps {
  companySlug: string;
  errorType: "company-not-found" | "lounge-not-found" | "lounge-closed";
}

export function LoungeErrorStates({
  companySlug,
  errorType,
}: LoungeErrorStatesProps) {
  const router = useRouter();

  const getErrorContent = () => {
    switch (errorType) {
      case "company-not-found":
        return {
          title: "Company Not Found",
          message: `The company "${companySlug}" does not exist.`,
          buttonText: "Go Home",
          buttonAction: () => router.push("/"),
        };
      case "lounge-not-found":
        return {
          title: "Lounge Not Found",
          message:
            "The lounge you're looking for doesn't exist or has been closed.",
          buttonText: "Create New Lounge",
          buttonAction: () => router.push(`/lounge-setup/${companySlug}`),
        };
      case "lounge-closed":
        return {
          title: "Lounge Closed",
          message: "This lounge has been closed by the moderator.",
          buttonText: "Create New Lounge",
          buttonAction: () => router.push(`/lounge-setup/${companySlug}`),
        };
    }
  };

  const content = getErrorContent();

  return (
    <div className="flex items-center justify-center h-full">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-neutral-900 dark:text-neutral-100 mb-4">
          {content.title}
        </h1>
        <p className="text-neutral-600 dark:text-neutral-300 mb-6">
          {content.message}
        </p>
        <button
          onClick={content.buttonAction}
          className="px-4 py-2 bg-neutral-200 dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100 rounded-lg hover:bg-neutral-300 dark:hover:bg-neutral-700"
        >
          {content.buttonText}
        </button>
      </div>
    </div>
  );
}
