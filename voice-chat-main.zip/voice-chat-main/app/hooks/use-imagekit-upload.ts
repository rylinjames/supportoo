"use client";

import { useState, useCallback } from "react";
import { validateImageFile, type ImageKitUploadResponse } from "@/lib/imagekit";

interface UseImageKitUploadOptions {
  folder?: string;
  fileName?: string;
  useUniqueFileName?: boolean;
}

interface UploadState {
  isUploading: boolean;
  progress: number;
  error: string | null;
  result: ImageKitUploadResponse | null;
}

export function useImageKitUpload(options: UseImageKitUploadOptions = {}) {
  const [uploadState, setUploadState] = useState<UploadState>({
    isUploading: false,
    progress: 0,
    error: null,
    result: null,
  });

  const upload = useCallback(
    async (file: File): Promise<ImageKitUploadResponse | null> => {
      // Reset state
      setUploadState({
        isUploading: true,
        progress: 0,
        error: null,
        result: null,
      });

      try {
        // Validate file first
        const validation = validateImageFile(file);
        if (!validation.valid) {
          throw new Error(validation.error);
        }

        // Get authentication parameters from our API
        setUploadState((prev) => ({ ...prev, progress: 10 }));

        const authResponse = await fetch("/api/imagekit/auth");
        if (!authResponse.ok) {
          throw new Error("Failed to get authentication parameters");
        }

        const authParams = await authResponse.json();
        setUploadState((prev) => ({ ...prev, progress: 20 }));

        // Check if ImageKit is properly configured
        const publicKey = process.env.NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY;
        if (!publicKey) {
          throw new Error(
            "ImageKit is not configured. Please add NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY to your environment variables."
          );
        }

        // Prepare form data for ImageKit upload
        const formData = new FormData();
        formData.append("file", file);
        formData.append("publicKey", publicKey);
        formData.append("signature", authParams.signature);
        formData.append("expire", authParams.expire.toString());
        formData.append("token", authParams.token);

        // Add optional parameters
        if (options.folder) {
          formData.append("folder", options.folder);
        }

        if (options.fileName) {
          formData.append("fileName", options.fileName);
        } else if (options.useUniqueFileName) {
          // Generate unique filename with timestamp
          const timestamp = Date.now();
          const extension = file.name.split(".").pop() || "jpg";
          formData.append("fileName", `upload_${timestamp}.${extension}`);
        }

        setUploadState((prev) => ({ ...prev, progress: 30 }));

        // Upload to ImageKit
        const uploadResponse = await fetch(
          "https://upload.imagekit.io/api/v1/files/upload",
          {
            method: "POST",
            body: formData,
          }
        );

        setUploadState((prev) => ({ ...prev, progress: 80 }));

        if (!uploadResponse.ok) {
          const errorData = await uploadResponse.json();
          throw new Error(errorData.message || "Upload failed");
        }

        const result: ImageKitUploadResponse = await uploadResponse.json();

        setUploadState({
          isUploading: false,
          progress: 100,
          error: null,
          result,
        });

        return result;
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : "Upload failed";

        setUploadState({
          isUploading: false,
          progress: 0,
          error: errorMessage,
          result: null,
        });

        return null;
      }
    },
    [options]
  );

  const reset = useCallback(() => {
    setUploadState({
      isUploading: false,
      progress: 0,
      error: null,
      result: null,
    });
  }, []);

  return {
    upload,
    reset,
    ...uploadState,
  };
}
