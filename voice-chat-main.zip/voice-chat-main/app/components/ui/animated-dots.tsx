"use client";

import { motion } from "motion/react";

interface AnimatedDotsProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function AnimatedDots({
  className = "",
  size = "md",
}: AnimatedDotsProps) {
  const dotSizes = {
    sm: "w-1 h-1",
    md: "w-2 h-2",
    lg: "w-3 h-3",
  };

  const containerSizes = {
    sm: "gap-1",
    md: "gap-1.5",
    lg: "gap-2",
  };

  return (
    <div className={`flex items-center ${containerSizes[size]} ${className}`}>
      {[0, 1, 2].map((index) => (
        <motion.div
          key={index}
          className={`${dotSizes[size]} bg-current rounded-full`}
          animate={{
            y: [0, -8, 0],
          }}
          transition={{
            duration: 1,
            repeat: Infinity,
            delay: index * 0.2,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}
