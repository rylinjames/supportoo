import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { Id } from "./_generated/dataModel";
import { createLoungeEvent, EVENT_TYPES, getFirstName } from "./events";

// Add a reaction for a user in a room
export const addReaction = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
    emoji: v.string(),
  },
  handler: async (ctx, { roomId, userId, emoji }) => {
    const now = Date.now();
    const timeout = emoji === "✋" ? 30000 : 7000; // 30s for hand, 7s for others
    const expiresAt = now + timeout;

    // Rate limiting: Check reaction history in past 30 seconds
    const thirtySecondsAgo = now - 30000;

    const recentReactionHistory = await ctx.db
      .query("reactionHistory")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) =>
        q.and(
          q.eq(q.field("roomId"), roomId),
          q.gt(q.field("createdAt"), thirtySecondsAgo)
        )
      )
      .collect();

    if (recentReactionHistory.length >= 5) {
      throw new Error(
        "Anti-spam protection: Please wait before adding more reactions"
      );
    }

    // Clean up expired reaction history (for rate limiting)
    const expiredHistory = await ctx.db
      .query("reactionHistory")
      .withIndex("by_expires", (q) => q.lt("expiresAt", now))
      .collect();

    for (const historyItem of expiredHistory) {
      await ctx.db.delete(historyItem._id);
    }

    // Clean up expired reactions (for display)
    const expiredReactions = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", roomId))
      .filter((q) => q.lt(q.field("expiresAt"), now))
      .collect();

    for (const reaction of expiredReactions) {
      await ctx.db.delete(reaction._id);
    }

    // Remove any existing reaction for this user in this room (replace logic)
    const existingReaction = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", roomId))
      .filter((q) => q.eq(q.field("userId"), userId))
      .first();

    if (existingReaction) {
      await ctx.db.delete(existingReaction._id);
    }

    // Add the new reaction (for display)
    const reactionId = await ctx.db.insert("reactions", {
      roomId,
      userId,
      emoji,
      createdAt: now,
      expiresAt,
    });

    // Add to reaction history (for rate limiting)
    await ctx.db.insert("reactionHistory", {
      roomId,
      userId,
      emoji,
      createdAt: now,
      expiresAt: now + 30000, // 30 seconds for rate limiting
    });

    // Create speak_request event for live feed when emoji is "✋"
    if (emoji === "✋") {
      // Get user details for the event
      const user = await ctx.db.get(userId);
      if (user && !user.isAnonymous) {
        await createLoungeEvent(ctx, {
          roomId,
          eventType: EVENT_TYPES.SPEAK_REQUEST,
          userId,
          eventData: {
            userName: getFirstName(user.fullName),
          },
        });
      }
    }

    return reactionId;
  },
});

// Get all active reactions for a room
export const getRoomReactions = query({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, { roomId }) => {
    const now = Date.now();

    // Get active reactions (expired ones are filtered out)
    const reactions = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", roomId))
      .filter((q) => q.gt(q.field("expiresAt"), now))
      .collect();

    return reactions;
  },
});

// Clear expired reactions (can be called periodically)
export const clearExpiredReactions = mutation({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();

    const expiredReactions = await ctx.db
      .query("reactions")
      .withIndex("by_expires", (q) => q.lt("expiresAt", now))
      .collect();

    // Delete expired reactions
    for (const reaction of expiredReactions) {
      await ctx.db.delete(reaction._id);
    }

    return expiredReactions.length;
  },
});

// Clear a specific user's reaction in a room
export const clearUserReaction = mutation({
  args: {
    roomId: v.id("rooms"),
    userId: v.id("users"),
  },
  handler: async (ctx, { roomId, userId }) => {
    const reaction = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", roomId))
      .filter((q) => q.eq(q.field("userId"), userId))
      .first();

    if (reaction) {
      await ctx.db.delete(reaction._id);
      return true;
    }

    return false;
  },
});

// Clear all reactions for a room (useful when room ends)
export const clearRoomReactions = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, { roomId }) => {
    const roomReactions = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", roomId))
      .collect();

    // Delete all reactions for this room
    for (const reaction of roomReactions) {
      await ctx.db.delete(reaction._id);
    }

    return roomReactions.length;
  },
});

// Clean up expired reactions for a specific room
export const cleanupExpiredReactionsForRoom = mutation({
  args: { roomId: v.id("rooms") },
  handler: async (ctx, { roomId }) => {
    const now = Date.now();

    // Find expired reactions for this room
    const expiredReactions = await ctx.db
      .query("reactions")
      .withIndex("by_room", (q) => q.eq("roomId", roomId))
      .filter((q) => q.lt(q.field("expiresAt"), now))
      .collect();

    // Delete expired reactions
    for (const reaction of expiredReactions) {
      await ctx.db.delete(reaction._id);
    }

    return expiredReactions.length;
  },
});
