import { Toaster } from "@/components/ui/sonner";

const ExperienceLayout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="h-screen">
      {children}
      <Toaster />
    </div>
  );
};

export default ExperienceLayout;
