"use client";
import { useEffect, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { useSessionStore } from "@/stores/session-store";

export type SyncState = "idle" | "syncing" | "success" | "error";

export type UseWhopSyncParams = {
  whopUserId: string;
  whopUsername: string;
  fullName: string;
  avatarUrl?: string;
  whopCompanyId: string;
  whopExperienceId: string;
  whopAccessLevel: "admin" | "customer" | "no_access" | null;
  companyName: string;
};

export function useWhopSync(params: UseWhopSyncParams) {
  const [syncState, setSyncState] = useState<SyncState>("idle");
  const [error, setError] = useState<string | null>(null);
  const [convexUserId, setConvexUserId] = useState<Id<"users"> | null>(null);

  const setSession = useSessionStore((s) => s.setSession);

  const syncUser = useMutation(api.whopSync.syncWhopUser);
  const syncCompany = useMutation(api.whopSync.syncWhopCompany);

  const convexCompany = useQuery(api.whopSync.getCompanyByExperienceId, {
    whopExperienceId: params.whopExperienceId,
  });

  useEffect(() => {
    const run = async () => {
      try {
        setSyncState("syncing");
        const uid = await syncUser({
          whopUserId: params.whopUserId,
          whopUsername: params.whopUsername,
          fullName: params.fullName,
          avatarUrl: params.avatarUrl,
        });
        await syncCompany({
          whopCompanyId: params.whopCompanyId,
          whopExperienceId: params.whopExperienceId,
          name: params.companyName,
          ownerUserId: uid,
        });

        setConvexUserId(uid as Id<"users">);
      } catch (e: any) {
        setError(e?.message ?? "Failed to sync. Please try again.");
        setSyncState("error");
      }
    };
    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (convexUserId && convexCompany?._id) {
      setSession({
        convexUserId,
        convexCompanyId: convexCompany._id,
        whopUserId: params.whopUserId,
        whopExperienceId: params.whopExperienceId,
        whopCompanyId: params.whopCompanyId,
        whopAccessLevel: params.whopAccessLevel || "customer",
        experienceImage: "/images/whop-logo.png",
        syncedAt: Date.now(),
      });
      setSyncState("success");
    }
  }, [convexUserId, convexCompany?._id, params, setSession]);

  return { syncState, error, convexUserId, convexCompany };
}
