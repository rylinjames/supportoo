"use client";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import Link from "next/link";
import AdminSettingsDialog from "./admin-settings-dialog";
import AnalyticsDialog from "./analytics-dialog";
import { useSessionStore } from "@/stores/session-store";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { CircleDollarSign } from "lucide-react";

const AdminSheet = ({ whopExperienceId }: { whopExperienceId: string }) => {
  const { session } = useSessionStore();

  // Get plan owner details
  const planOwnerDetails = useQuery(
    api.plans.getPlanOwnerDetails,
    session?.convexCompanyId
      ? { companyId: session.convexCompanyId as any }
      : "skip"
  );

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          className="hidden xl:inline-block text-neutral-800 hover:bg-transparent! dark:text-white hover:text-neutral-600 dark:hover:text-neutral-300"
        >
          Admin Panel
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-72 px-4 md:px-8">
        <SheetHeader>
          <SheetTitle className="hidden">Admin</SheetTitle>
        </SheetHeader>

        {/* Admin Section */}
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-3">
              Admin
            </h3>
            <div className="space-y-2 flex flex-col">
              <SheetClose asChild>
                <Link
                  href={`/experiences/${whopExperienceId}/plans`}
                  className="px-3 py-2 gap-2 flex items-center rounded-md text-sm text-neutral-800 dark:text-white hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
                >
                  <CircleDollarSign className="w-4 h-4 mr-2" />
                  View Pricing Plans
                </Link>
              </SheetClose>

              {/* Analytics Dialog */}
              {session?.convexCompanyId && (
                <div className="block">
                  <AnalyticsDialog companyId={session.convexCompanyId} />
                </div>
              )}

              {/* Admin Settings Dialog */}
              {session?.convexCompanyId && (
                <div className="block">
                  <AdminSettingsDialog
                    whopExperienceId={whopExperienceId}
                    companyId={session.convexCompanyId}
                    currentUserId={session.whopUserId}
                    planOwnerDetails={planOwnerDetails || undefined}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default AdminSheet;
