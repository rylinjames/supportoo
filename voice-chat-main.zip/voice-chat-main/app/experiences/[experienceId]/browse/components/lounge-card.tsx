"use client";

import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/animate-ui/radix/popover";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/avatar";
import { Button } from "@/components/ui/button";
import { EnrichedRoom } from "@/convex/browse";
import { MoreHorizontalIcon, Trash2, UsersIcon } from "lucide-react";
import Link from "next/link";
import { useAction, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { useSessionStore } from "@/stores/session-store";
import { OptimizedImage } from "@/app/components/shared/optimized-image";

interface LoungeCardProps extends EnrichedRoom {}

const LoungeCard = ({ lounge }: { lounge: LoungeCardProps }) => {
  const firstName = lounge.creatorName.split(" ")[0];
  const lastName = lounge.creatorName.split(" ")[1] || "";
  const initials = `${firstName[0]}${lastName[0]}`;

  return (
    <div className="flex flex-col rounded-md min-w-[260px] w-[260px] md:min-w-[300px] md:w-[300px] overflow-hidden hover:translate-y-[-4px] transition-transform duration-300">
      <div className="relative w-full h-40 overflow-hidden">
        <OptimizedImage
          src={lounge.roomImage || "/images/whop-logo.png"}
          alt={
            `${lounge.whopCompanyName.split(" ").join("_")}_logo` ||
            "cover_logo"
          }
          width={300}
          height={160}
          className="w-full h-full object-cover object-center"
          fallback="/images/whop-logo.png"
        />
        <div className="absolute top-2 right-2 z-10">
          <MoreInfo lounge={lounge} />
        </div>
      </div>
      <div className="p-4 flex rounded-b-md flex-col gap-1 bg-foreground dark:bg-[#1e1e1e] w-full border border-neutral-200 dark:border-none hover:shadow dark:shadow-none">
        <div className="flex w-full">
          <div className="flex items-start gap-1">
            <Avatar className="size-10">
              <AvatarImage src={lounge.creatorAvatarUrl} />
              <AvatarFallback>{initials}</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <p className="text-sm">
                Started by{" "}
                {lounge.isCreator ? "You" : `@${lounge.creatorWhopUsername}`}
              </p>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                {lounge.whopCompanyName}
              </p>
            </div>
          </div>
        </div>
        <div className="flex flex-col mt-2">
          <h3 className="truncate">{lounge.name}</h3>
          {!lounge.isPublic ? (
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              Private
            </p>
          ) : (
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              Public
            </p>
          )}
        </div>
        <div className="mt-3 flex items-center justify-between w-full">
          <div className="flex items-center gap-1">
            <UsersIcon className="size-4 text-neutral-500 dark:text-neutral-400" />
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              {lounge.participantCount} participant
              {lounge.participantCount === 1 ? "" : "s"}
            </p>
            {lounge.isActive ? (
              <p className="text-xs p-1 bg-red-500 text-white rounded-full ml-1 animate-pulse">
                Active
              </p>
            ) : (
              <p className="text-xs p-1 bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-400 rounded-full ml-1">
                Inactive
              </p>
            )}
          </div>
          <Link
            href={`/experiences/${lounge.whopExperienceId}/join/${lounge._id}`}
          >
            <Button size="sm" className="text-white">
              Join
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LoungeCard;

const MoreInfo = ({ lounge }: { lounge: LoungeCardProps }) => {
  const authorizeAndDelete = useAction(api.rooms.authorizeAndDeleteRoom);
  const toggleDiscover = useMutation(api.rooms.toggleDiscoverStatus);
  const router = useRouter();
  const session = useSessionStore((s) => s.session);
  const onDelete = async () => {
    try {
      if (!session?.convexUserId) {
        toast.error("Session not ready. Please try again.");
        return;
      }
      const isWhopAdmin = session.whopAccessLevel === "admin";
      await authorizeAndDelete({
        roomId: lounge._id as Id<"rooms">,
        requesterId: session.convexUserId as Id<"users">,
        requesterCompanyId: session.convexCompanyId as Id<"companies">,
        isWhopAdmin,
      });
      toast.success("Lounge deleted");
      router.refresh();
    } catch (e: any) {
      toast.error(e?.message || "Failed to delete lounge");
    }
  };

  const onToggleDiscover = async () => {
    try {
      if (!session?.convexUserId) {
        toast.error("Session not ready. Please try again.");
        return;
      }

      const result = await toggleDiscover({
        roomId: lounge._id as Id<"rooms">,
        requesterId: session.convexUserId as Id<"users">,
      });

      toast.success(result.message);
      router.refresh();
    } catch (e: any) {
      toast.error(e?.message || "Failed to toggle discover status");
    }
  };
  return (
    <Popover>
      <PopoverTrigger>
        <div className="bg-white dark:bg-neutral-800 rounded-md cursor-pointer p-1 z-10">
          <MoreHorizontalIcon className="size-4 text-neutral-800 dark:text-white relative z-20" />
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-50 flex flex-col gap-1 p-2 text-sm">
        <Link
          href={`https://whop.com/@${lounge.creatorWhopUsername}`}
          className="py-1 px-2 hover:bg-neutral-200 rounded-md dark:hover:bg-neutral-700"
          target="_blank"
        >
          <p className="">View Creator</p>
        </Link>
        <Link
          href={`https://whop.com/${lounge.whopCompanyId}`}
          className="py-1 px-2 hover:bg-neutral-200 rounded-md dark:hover:bg-neutral-700"
          target="_blank"
        >
          <p className="">View Company Whop</p>
        </Link>

        {/* Discover Toggle - Only for company admins on Creator tier, public lounges */}
        {lounge.isPublic &&
          lounge.viewerIsCompanyOwner &&
          lounge.companyPlanTier === "creator" && (
            <button
              onClick={onToggleDiscover}
              className="py-1 px-2 hover:bg-neutral-200 cursor-pointer rounded-md dark:hover:bg-neutral-700 flex items-center gap-2 text-left"
            >
              <span className="text-sm">
                {lounge.discoverListed
                  ? "Hide from Explore Page"
                  : "Show in Explore Page"}
              </span>
            </button>
          )}
        {(lounge.isCreator || lounge.viewerCanDelete) && (
          <Dialog>
            <DialogTrigger asChild>
              <button className="py-1 px-2 cursor-pointer hover:bg-red-100 rounded-md text-left text-red-600 dark:text-red-500 dark:hover:bg-neutral-700 flex items-center gap-2">
                Delete Lounge
              </button>
            </DialogTrigger>
            <DialogContent className="max-w-sm">
              <DialogHeader>
                <DialogTitle>Delete this lounge?</DialogTitle>
              </DialogHeader>
              <p className="text-sm text-neutral-600 dark:text-neutral-300">
                This will permanently delete the lounge, its participants and
                history. This action cannot be undone.
              </p>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <DialogClose asChild>
                  <Button
                    onClick={onDelete}
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    Confirm Delete
                  </Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </PopoverContent>
    </Popover>
  );
};
