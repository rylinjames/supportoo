import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { TabContent, TabList, TabTrigger, Tabs } from "../tabs";
import { LiveFeed } from "../live-feed";
import { Chat } from "../chat";
import { Badge } from "@/components/ui/badge";

const MobileLiveFeedAndChatSection = ({ roomId }: { roomId: string }) => {
  const [screenSize, setScreenSize] = useState(0);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    setScreenSize(window.innerWidth);
  }, []);

  return (
    <>
      {screenSize && screenSize < 1025 && (
        <div className="absolute left-0 bg-foreground bottom-0 w-screen z-10 grid place-items-center text-neutral-800 dark:text-white">
          <Tabs defaultTab="live-feed" className="flex flex-col h-full">
            <TabList className="flex-shrink-0 px-6 pt-4">
              <TabTrigger value="live-feed">Live Feed</TabTrigger>
              <TabTrigger value="chat">Chat</TabTrigger>
            </TabList>

            <motion.div
              layout={false}
              initial={{ height: "80px" }}
              animate={{ height: isExpanded ? "400px" : "80px" }}
              transition={{ duration: 0.3, ease: [0.77, 0, 0.175, 1] }}
              className="flex flex-col max-h-[400px]"
            >
              <TabContent
                value="live-feed"
                className="flex-1 flex flex-col min-h-20 p-6 h-full"
              >
                <LiveFeed roomId={roomId} />
                <Badge
                  onClick={() => setIsExpanded((prev) => !prev)}
                  className="absolute bottom-2 right-1/2 translate-x-1/2 py-1.5 px-3 bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-800 dark:text-white dark:hover:text-white"
                >
                  {isExpanded ? "Collapse Live Feed" : "Expand Live Feed"}
                </Badge>
              </TabContent>

              <TabContent
                value="chat"
                className="flex-1 flex flex-col min-h-20 p-6 h-full"
              >
                <Chat />
                <Badge
                  onClick={() => setIsExpanded((prev) => !prev)}
                  className="absolute bottom-2 right-1/2 translate-x-1/2 py-1.5 px-3 bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-800 dark:text-white dark:hover:text-white"
                >
                  {isExpanded ? "Collapse Chat" : "Expand Chat"}
                </Badge>
              </TabContent>
            </motion.div>
          </Tabs>
        </div>
      )}
    </>
  );
};

export default MobileLiveFeedAndChatSection;
