"use client";
import LoadingScreen from "./components/shared/loading-screen";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html>
      <body className="h-screen w-screen">
        <LoadingScreen error={true} message={"Something went wrong"} />
      </body>
    </html>
  );
}
