"use client";

import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useSessionStore } from "@/stores/session-store";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/animate-ui/radix/switch";
import { Crown, AlertTriangle, Settings } from "lucide-react";
import { toast } from "sonner";
import { Id } from "@/convex/_generated/dataModel";

interface AdminSettingsDialogProps {
  whopExperienceId: string;
  companyId: string;
  currentUserId: string;
  planOwnerDetails?: {
    whopUserId: string;
    whopUsername: string;
    fullName: string;
  } | null;
}

export default function AdminSettingsDialog({
  whopExperienceId,
  companyId,
  currentUserId,
  planOwnerDetails,
}: AdminSettingsDialogProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isTransferring, setIsTransferring] = useState(false);
  const [isTogglingMemberCreate, setIsTogglingMemberCreate] = useState(false);

  // Get session for convex user ID
  const { session } = useSessionStore();

  // Convex queries
  const planSettings = useQuery(api.plans.getCompanyPlanSettings, {
    companyId: companyId as Id<"companies">,
  });

  // Convex mutations
  const transferPlanOwnership = useMutation(api.plans.transferPlanOwnership);
  const setAllowMembersToCreateLounges = useMutation(
    api.companies.setAllowMembersToCreateLounges
  );

  const handleTransferOwnership = async () => {
    if (!planOwnerDetails) return;

    setIsTransferring(true);
    try {
      await transferPlanOwnership({
        companyId: companyId as any,
        newOwnerWhopUserId: currentUserId,
      });

      toast.success("Plan ownership transferred successfully!");
      setIsOpen(false);
    } catch (error) {
      console.error("Failed to transfer plan ownership:", error);
      toast.error("Failed to transfer plan ownership. Please try again.");
    } finally {
      setIsTransferring(false);
    }
  };

  const handleToggleMemberCreate = async (enabled: boolean) => {
    if (!session?.convexUserId) {
      toast.error("User session not found. Please refresh the page.");
      return;
    }

    setIsTogglingMemberCreate(true);
    try {
      await setAllowMembersToCreateLounges({
        companyId: companyId as any,
        requesterId: session.convexUserId as any,
        allow: enabled,
      });

      toast.success(
        enabled
          ? "Members can now create lounges"
          : "Only admins can create lounges"
      );
    } catch (error) {
      console.error("Failed to update lounge creation setting:", error);
      toast.error("Failed to update setting. Please try again.");
    } finally {
      setIsTogglingMemberCreate(false);
    }
  };

  const isCurrentUserPlanOwner = planOwnerDetails?.whopUserId === currentUserId;

  // Check if user is on Starter+ tier
  const isStarterOrAbove =
    planSettings?.planTier &&
    ["starter", "pro", "creator"].includes(planSettings.planTier);

  const allowMembersToCreate =
    planSettings?.features.allowMembersToCreateLounges ?? false;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          className="text-neutral-800 max-w-max dark:text-white hover:bg-transparent! hover:text-neutral-600 dark:hover:text-neutral-300"
        >
          <Settings className="w-4 h-4 mr-2" />
          Settings
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-background border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white max-w-md max-h-[85vh] overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="text-xl font-semibold text-neutral-900 dark:text-white">
            Admin Settings
          </DialogTitle>
          <DialogDescription className="text-neutral-600 dark:text-neutral-400">
            Manage company settings and plan ownership
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 overflow-y-auto flex-1">
          {/* Plan Owner Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium text-neutral-900 dark:text-white">
                Plan Ownership
              </h3>
            </div>

            {planOwnerDetails ? (
              <div className="space-y-3">
                <div className="p-3 bg-neutral-100 dark:bg-neutral-800/50 rounded-lg border border-neutral-300 dark:border-neutral-700">
                  <p className="text-sm font-medium text-neutral-900 dark:text-white mb-1">
                    Current Plan Owner
                  </p>
                  <p className="text-sm text-neutral-700 dark:text-neutral-300">
                    {planOwnerDetails.fullName}
                  </p>
                  <p className="text-xs text-neutral-500 dark:text-neutral-500">
                    @{planOwnerDetails.whopUsername}
                  </p>
                </div>

                {!isCurrentUserPlanOwner && (
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-700/50">
                      <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-500 mt-0.5 flex-shrink-0" />
                      <div className="space-y-1">
                        <p className="text-sm font-medium text-yellow-900 dark:text-yellow-400">
                          Transfer Plan Ownership
                        </p>
                        <p className="text-xs text-yellow-800 dark:text-yellow-300">
                          This will make you the plan owner. The current owner
                          will lose the ability to make plan changes.
                        </p>
                      </div>
                    </div>

                    <Button
                      onClick={handleTransferOwnership}
                      disabled={isTransferring}
                      className="w-full bg-yellow-600 hover:bg-yellow-700 text-white"
                    >
                      {isTransferring ? "Transferring..." : "Become Plan Owner"}
                    </Button>
                  </div>
                )}

                {isCurrentUserPlanOwner && (
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-700/50">
                    <p className="text-sm text-green-900 dark:text-green-400">
                      ✓ You are the current plan owner
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-3 bg-neutral-100 dark:bg-neutral-800/50 rounded-lg border border-neutral-300 dark:border-neutral-700">
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  No plan owner assigned yet. Make a plan change to assign you
                  as the plan owner.
                </p>
              </div>
            )}
          </div>

          {/* Lounge Creation Section - Only show for Starter+ */}
          {isStarterOrAbove && (
            <>
              <Separator className="bg-neutral-300 dark:bg-neutral-700" />

              <div className="space-y-4">
                <h3 className="text-lg font-medium text-neutral-900 dark:text-white">
                  Lounge Creation
                </h3>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-neutral-100 dark:bg-neutral-800/50 rounded-lg border border-neutral-300 dark:border-neutral-700">
                    <div className="flex-1 space-y-1">
                      <p className="text-sm font-medium text-neutral-900 dark:text-white">
                        Allow Members to Create Lounges
                      </p>
                      <p className="text-xs text-neutral-600 dark:text-neutral-400">
                        When enabled, all members can create lounges. When
                        disabled, only admins can create lounges.
                      </p>
                    </div>
                    <Switch
                      checked={allowMembersToCreate}
                      onCheckedChange={handleToggleMemberCreate}
                      disabled={isTogglingMemberCreate}
                      className="ml-4"
                    />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
