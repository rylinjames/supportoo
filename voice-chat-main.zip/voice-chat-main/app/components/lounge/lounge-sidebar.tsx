"use client";

import { motion, AnimatePresence } from "motion/react";
import {
  Heart,
  MessageCircle,
  Users,
  MonitorSpeaker,
  Square,
  Zap,
  Loader2,
  TvMinimal,
  MonitorX,
  Mic,
  MicOff,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useMutation, useAction } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/animate-ui/radix/popover";
import { toast } from "sonner";
import SettingsModal from "./settings-modal";
import { ResetSpeakersModal } from "./reset-speakers-modal";
import LoungeSidebarActionTabs from "./lounge-sidebar-action-tabs";
import LoungeSidebarFooter from "./lounge-sidebar-footer";
import { InviteUsersButton } from "@/app/components/lounge/invite-users-button";
import { ParticipantsDialog } from "./ParticipantsDialog";
import { Participant } from "./types";

const REACTIONS = [
  { emoji: "❤️", label: "Love" },
  { emoji: "👍", label: "Like" },
  { emoji: "👏", label: "Clap" },
  { emoji: "🎉", label: "Celebrate" },
  { emoji: "🔥", label: "Fire" },
  { emoji: "😂", label: "Laugh" },
  { emoji: "🤣", label: "Laughing Out Loud" },
  { emoji: "😭", label: "Crying" },
  { emoji: "💰", label: "Money" },
  { emoji: "⚡", label: "Lightning" },
  { emoji: "😠", label: "Angry" },
  { emoji: "😢", label: "Sad" },
  { emoji: "🤔", label: "Think" },
  { emoji: "👀", label: "Eyes" },
  { emoji: "🤯", label: "Mind Blown" },
  { emoji: "💯", label: "100" },
  { emoji: "🙏", label: "Pray" },
  { emoji: "🎯", label: "Target" },
];

interface LoungeSidebarProps {
  sidebarOpen: boolean;
  whopUserData: {
    _id: string;
    whopUserId: string;
    whopUsername: string;
    fullName: string;
  };
  currentUserRole?: string;
  experienceId: string;
  roomId: string;
  roomDetails?: any; // Room details from Convex
  localParticipant?: any; // LiveKit local participant
  isPublic: boolean;
  // Screen share props
  canScreenShare?: boolean;
  isSharing?: boolean;
  screenShareLoading?: boolean;
  screenShareActive?: boolean;
  screenShareError?: string | null;
  participantCount?: number; // For "View Participants" button
  participants?: Participant[]; // For participants dialog
  // Participant management functions
  onAddToSpeakers?: (participantId: string) => void;
  onRemoveFromSpeakers?: (participantId: string) => void;
  onKickFromLounge?: (participantId: string) => void;
  onPromoteToModerator?: (participantId: string) => void;
  onDemoteModeratorToSpeaker?: (participantId: string) => void;
  onMuteAllSpeakers?: () => void;
  onUnmuteAllSpeakers?: () => void;
  canManageModerators?: boolean;
  onStartScreenShare?: () => void;
  onStopScreenShare?: () => void;
  onTakeoverScreenShare?: () => void;
}

export function LoungeSidebar({
  sidebarOpen,
  whopUserData,
  currentUserRole,
  experienceId,
  roomId,
  roomDetails,
  localParticipant,
  isPublic,
  // Screen share props
  canScreenShare,
  isSharing,
  screenShareLoading,
  screenShareActive,
  screenShareError,
  participantCount,
  participants,
  // Participant management functions
  onAddToSpeakers,
  onRemoveFromSpeakers,
  onKickFromLounge,
  onPromoteToModerator,
  onDemoteModeratorToSpeaker,
  onMuteAllSpeakers,
  onUnmuteAllSpeakers,
  canManageModerators,
  onStartScreenShare,
  onStopScreenShare,
  onTakeoverScreenShare,
}: LoungeSidebarProps) {
  const [isReactionOpen, setIsReactionOpen] = useState(false);
  const [showResetConfirmation, setShowResetConfirmation] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [showParticipantsDialog, setShowParticipantsDialog] = useState(false);
  const addReactionMutation = useMutation(api.reactions.addReaction);
  const resetAllSpeakersAction = useAction(api.rooms.authorizeAndResetSpeakers);

  const handleReaction = async (emoji: string) => {
    try {
      await addReactionMutation({
        roomId: roomId as Id<"rooms">,
        userId: whopUserData._id as Id<"users">,
        emoji,
      });
      setIsReactionOpen(false);
    } catch (error) {
      console.error("Failed to add reaction:", error);

      // Show user-friendly error message
      let errorMessage = "Failed to add reaction. Please try again.";

      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === "object" && error !== null) {
        // Handle Convex errors which might have a different structure
        const errorObj = error as any;
        errorMessage = errorObj.message || errorObj.error || "Unknown error";
      }

      if (errorMessage.includes("Anti-spam protection")) {
        toast.error("Please wait before adding more reactions");
      } else {
        toast.error("Failed to add reaction. Please try again.");
      }
    }
  };

  const handleRequestToSpeak = async () => {
    // Prevent moderators and speakers from requesting to speak
    if (currentUserRole === "moderator" || currentUserRole === "speaker") {
      return;
    }

    try {
      await handleReaction("✋");
    } catch (error) {
      // Error handling is already done in handleReaction
      // Just log for debugging
      console.error("Failed to request to speak:", error);
    }
  };

  const handleResetAllSpeakers = async () => {
    try {
      setIsResetting(true);
      const resetCount = await resetAllSpeakersAction({
        roomId: roomId as Id<"rooms">,
        requesterId: whopUserData._id as Id<"users">,
        requesterCompanyId: roomDetails?.companyId as Id<"companies">,
      });
      toast.success(`Reset ${resetCount} speakers to listeners`);
      setShowResetConfirmation(false);
    } catch (error) {
      console.error("Failed to reset speakers:", error);
      toast.error("Failed to reset speakers. Please try again.");
    } finally {
      setIsResetting(false);
    }
  };

  const openResetConfirmation = () => {
    setShowResetConfirmation(true);
  };

  // Check if user can request to speak (only listeners can)
  const canRequestToSpeak = currentUserRole === "listener";

  // Calculate speaker counts for mute all button
  const speakers = participants?.filter((p) => p.role === "speaker") || [];
  const mutedSpeakers = speakers.filter((p) => p.isMuted);
  const speakerCount = speakers.length;
  const mutedSpeakerCount = mutedSpeakers.length;
  const isModerator = currentUserRole === "moderator";

  return (
    <AnimatePresence>
      <motion.aside
        key="sidebar"
        className="fixed right-0 top-0 h-full max-h-screen w-80 bg-background border-l border-neutral-200 dark:border-neutral-800 z-50 flex flex-col"
        initial={{ x: 320 }}
        animate={{ x: sidebarOpen ? 0 : 320 }}
        exit={{ x: 320, opacity: 0 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        {/* Lounge Actions Section - Fixed height */}
        <div className="p-6 border-b border-neutral-200 dark:border-neutral-800 flex-shrink-0">
          <h2 className="text-lg font-semibold mb-4">Lounge Actions</h2>
          <div className="space-y-3">
            <div className="relative">
              <Popover>
                <PopoverTrigger className="w-full">
                  <Button
                    onClick={() => setIsReactionOpen(!isReactionOpen)}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    React to Lounge
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 max-w-[250px]">
                  <div className="flex gap-2 flex-wrap">
                    {REACTIONS.map((reaction) => (
                      <Button
                        key={reaction.emoji}
                        variant="ghost"
                        size="icon"
                        onClick={() => handleReaction(reaction.emoji)}
                        className="w-8 h-8 p-0 hover:bg-neutral-200 dark:hover:bg-neutral-700"
                        title={reaction.label}
                      >
                        <span className="text-lg">{reaction.emoji}</span>
                      </Button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
            </div>

            {canRequestToSpeak && (
              <Button
                onClick={handleRequestToSpeak}
                className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Request to Speak
              </Button>
            )}
            {!isPublic && (
              <InviteUsersButton
                roomId={roomId}
                whopUserId={whopUserData._id}
              />
            )}
            <SettingsModal
              currentUserRole={currentUserRole}
              roomId={roomId}
              whopUserData={whopUserData}
              roomDetails={roomDetails}
              localParticipant={localParticipant}
            />

            {/* Screen Share Controls - Moderator Only */}
            {canScreenShare && (
              <>
                {/* Start Screen Share Button */}
                {!screenShareActive && (
                  <Button
                    onClick={onStartScreenShare}
                    disabled={screenShareLoading}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    {screenShareLoading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <TvMinimal className="w-4 h-4 mr-2" />
                    )}
                    Share Screen
                  </Button>
                )}

                {/* Stop Sharing Button (only if current user is sharing) */}
                {isSharing && (
                  <Button
                    onClick={onStopScreenShare}
                    disabled={screenShareLoading}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    {screenShareLoading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <MonitorX className="w-4 h-4 mr-2" />
                    )}
                    Stop Sharing Screen
                  </Button>
                )}

                {/* Take Over Button (when someone else is sharing) */}
                {screenShareActive && !isSharing && (
                  <Button
                    onClick={onTakeoverScreenShare}
                    disabled={screenShareLoading}
                    className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
                  >
                    {screenShareLoading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <TvMinimal className="w-4 h-4 mr-2" />
                    )}
                    Take Over Screen
                  </Button>
                )}

                {/* Error Display */}
                {screenShareError && (
                  <div className="text-red-400 text-sm px-2 py-1 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded">
                    {screenShareError}
                  </div>
                )}

                {/* Status Indicator (when someone else is presenting) */}
                {screenShareActive && !isSharing && !screenShareError && (
                  <div className="text-gray-400 text-sm px-2 py-1 bg-gray-50 dark:bg-gray-900/20 border border-gray-200 dark:border-gray-800 rounded flex items-center">
                    <MonitorSpeaker className="w-4 h-4 mr-2" />
                    Someone else is presenting
                  </div>
                )}
              </>
            )}

            {/* Mute All Speakers - Moderator Only */}
            {isModerator && speakers.length > 0 && (
              <Button
                onClick={
                  mutedSpeakerCount === speakerCount
                    ? onUnmuteAllSpeakers
                    : onMuteAllSpeakers
                }
                className={`w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white`}
              >
                {mutedSpeakerCount === speakerCount ? (
                  <Mic className="w-4 h-4 mr-2" />
                ) : (
                  <MicOff className="w-4 h-4 mr-2" />
                )}
                {mutedSpeakerCount === speakerCount
                  ? `Unmute All Speakers (${speakerCount})`
                  : `Mute All Speakers (${speakerCount})`}
              </Button>
            )}

            {/* View Participants Button - Shows when screen sharing is active */}
            {screenShareActive && (
              <Button
                onClick={() => setShowParticipantsDialog(true)}
                className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
              >
                <Users className="w-4 h-4 mr-2" />
                View Participants ({participantCount || 0})
              </Button>
            )}

            {/* Moderator-only actions */}
            {currentUserRole === "moderator" && isPublic && (
              <Button
                onClick={openResetConfirmation}
                className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white"
              >
                <Users className="w-4 h-4 mr-2" />
                Reset All Speakers
              </Button>
            )}
          </div>
        </div>

        {/* Action Tabs */}
        <LoungeSidebarActionTabs roomId={roomId} />

        {/* Footer Section */}
        <LoungeSidebarFooter />
      </motion.aside>

      {/* Reset Confirmation Dialog */}
      <ResetSpeakersModal
        open={showResetConfirmation}
        onOpenChange={setShowResetConfirmation}
        onConfirm={handleResetAllSpeakers}
        isLoading={isResetting}
      />

      {/* Participants Dialog */}
      <ParticipantsDialog
        isOpen={showParticipantsDialog}
        onClose={() => setShowParticipantsDialog(false)}
        participants={participants || []}
        currentUserRole={currentUserRole}
        currentUserId={whopUserData.whopUserId}
        roomCreatorId={roomDetails?.creatorId}
        roomId={roomId}
        onAddToSpeakers={onAddToSpeakers}
        onRemoveFromSpeakers={onRemoveFromSpeakers}
        onKickFromLounge={onKickFromLounge}
        onPromoteToModerator={onPromoteToModerator}
        onDemoteModeratorToSpeaker={onDemoteModeratorToSpeaker}
        canManageModerators={canManageModerators}
        whopCompanyId={whopUserData._id}
      />
    </AnimatePresence>
  );
}
