"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/animate-ui/radix/switch";
import { ThemeToggler } from "../shared/theme-toggler";
import { AudioDevicesSection } from "./audio-devices-section";
import { useMutation, useAction } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { toast } from "sonner";
import { RefreshCw, Copy, Loader2 } from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  UseFormRegister,
  UseFormHandleSubmit,
  FieldErrors,
  UseFormReset,
  UseFormWatch,
  UseFormSetValue,
} from "react-hook-form";
import { z } from "zod";

// Zod schema for moderator settings validation
export const moderatorSettingsSchema = z.object({
  name: z
    .string()
    .min(1, "Room name is required")
    .max(50, "Room name must be 50 characters or less")
    .trim(),
  maxParticipants: z
    .number()
    .min(5, "Minimum 5 participants")
    .max(100, "Maximum 100 participants"),
  maxSpeakers: z
    .number()
    .min(1, "Minimum 1 speaker")
    .max(20, "Maximum 20 speakers"),
  autoSpeakersEnabled: z.boolean().optional(),
});

export type ModeratorSettingsFormData = z.infer<typeof moderatorSettingsSchema>;

interface ModeratorViewProps {
  register: UseFormRegister<ModeratorSettingsFormData>;
  handleSubmit: UseFormHandleSubmit<ModeratorSettingsFormData>;
  errors: FieldErrors<ModeratorSettingsFormData>;
  isDirty: boolean;
  isSubmitting: boolean;
  roomId: string;
  updateRoomSettingsMutation: ReturnType<
    typeof useMutation<typeof api.rooms.updateRoomSettings>
  >;
  reset: UseFormReset<ModeratorSettingsFormData>;
  watch: UseFormWatch<ModeratorSettingsFormData>;
  setValue: UseFormSetValue<ModeratorSettingsFormData>;
  onTestAnonymousMode?: () => void; // Add test function prop
  localParticipant?: any; // LiveKit local participant
  isPublic?: boolean; // Add isPublic prop to determine room type
}

export const ModeratorView = ({
  register,
  handleSubmit,
  errors,
  isDirty,
  isSubmitting,
  roomId,
  updateRoomSettingsMutation,
  reset,
  watch,
  setValue,
  localParticipant,
  isPublic = true,
}: ModeratorViewProps) => {
  const [newRoomCode, setNewRoomCode] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Actions
  const generateRoomCode = useAction(api.rooms.generateRoomCodeAction);
  const updateRoomCode = useMutation(api.rooms.updateRoomCode);

  const handleGenerateNewCode = async () => {
    setIsGenerating(true);
    try {
      const code = await generateRoomCode();
      setNewRoomCode(code);
    } catch (error) {
      console.error("Failed to generate room code:", error);
      toast.error("Failed to generate new code. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveNewCode = async () => {
    if (!newRoomCode) return;

    setIsSaving(true);
    try {
      await updateRoomCode({
        roomId: roomId as Id<"rooms">,
        newRoomCode: newRoomCode,
      });
      toast.success(
        "Room code updated successfully! Share the new code with your members."
      );
      setNewRoomCode("");
      // The dialog will close automatically via DialogClose
    } catch (error) {
      console.error("Failed to update room code:", error);
      toast.error("Failed to save new code. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(newRoomCode);
    toast.success("Code copied to clipboard!");
  };

  const handleModalClose = () => {
    setNewRoomCode("");
    setIsGenerating(false);
    setIsSaving(false);
  };

  const onSubmit = async (data: ModeratorSettingsFormData) => {
    try {
      await updateRoomSettingsMutation({
        roomId: roomId as Id<"rooms">,
        name: data.name,
        maxParticipants: data.maxParticipants,
        maxSpeakers: data.maxSpeakers,
        autoSpeakersEnabled: data.autoSpeakersEnabled,
      });
      toast.success("Settings saved successfully");
      reset(); // Reset the form after successful submission
    } catch (error) {
      console.error("Failed to save settings:", error);
      let errorMessage = "Failed to save settings. Please try again.";
      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === "object" && error !== null) {
        const errorObj = error as any;
        errorMessage = errorObj.message || errorObj.error || "Unknown error";
      }
      toast.error(errorMessage);
    }
  };

  const handleSaveSettings = () => {
    if (!isDirty) {
      toast.info("No changes to save");
      return;
    }
    handleSubmit(onSubmit)();
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Room Settings Section */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-neutral-800 dark:text-white">
          Admin Settings
        </h3>

        <div className="space-y-4">
          <div>
            <Label
              htmlFor="roomName"
              className="text-sm font-medium text-neutral-800 dark:text-neutral-400"
            >
              Room Name
            </Label>
            <Input
              id="roomName"
              {...register("name")}
              placeholder="Enter room name"
              className="border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white mt-1"
            />
            {errors.name && (
              <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>
            )}
          </div>

          {/* Public Room Settings */}
          {isPublic ? (
            <>
              <div>
                <Label
                  htmlFor="maxParticipants"
                  className="text-sm font-medium text-neutral-800 dark:text-neutral-400"
                >
                  Max Participants
                </Label>
                <Input
                  id="maxParticipants"
                  type="number"
                  {...register("maxParticipants", { valueAsNumber: true })}
                  min={5}
                  max={100}
                  className="border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white mt-1"
                />
                {errors.maxParticipants && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.maxParticipants.message}
                  </p>
                )}
              </div>

              <div>
                <Label
                  htmlFor="maxSpeakers"
                  className="text-sm font-medium text-neutral-800 dark:text-neutral-400"
                >
                  Max Speakers
                </Label>
                <Input
                  id="maxSpeakers"
                  type="number"
                  {...register("maxSpeakers", { valueAsNumber: true })}
                  min={1}
                  max={20}
                  className="border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white mt-1"
                />
                {errors.maxSpeakers && (
                  <p className="text-red-500 text-xs mt-1">
                    {errors.maxSpeakers.message}
                  </p>
                )}
              </div>

              {/* Auto Speakers Toggle */}
              <div className="flex items-center space-x-3 p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg">
                <Switch
                  id="autoSpeakers"
                  checked={watch("autoSpeakersEnabled") || false}
                  onCheckedChange={(checked) => {
                    setValue("autoSpeakersEnabled", checked, {
                      shouldDirty: true,
                    });
                  }}
                />
                <div className="flex-1">
                  <Label
                    htmlFor="autoSpeakers"
                    className="text-sm font-medium text-neutral-800 dark:text-white"
                  >
                    Enable Auto Speakers
                  </Label>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400">
                    New members join as speakers (muted) instead of listeners.
                    They can unmute themselves.
                  </p>
                </div>
              </div>
            </>
          ) : (
            /* Private Room Settings */
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg bg-neutral-50 dark:bg-neutral-800/50">
                <div>
                  <h4 className="font-medium text-neutral-800 dark:text-white">
                    Room Access Code
                  </h4>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    Manage your private room access code
                  </p>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button type="button" variant="outline" className="gap-2">
                      <RefreshCw className="w-4 h-4" />
                      Generate New Code
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="min-w-[500px] max-w-sm">
                    <DialogHeader>
                      <DialogTitle>Generate New Room Code</DialogTitle>
                      <DialogDescription>
                        This will generate a new 8-character code for your
                        private room. The old code will no longer work.
                      </DialogDescription>
                    </DialogHeader>

                    {newRoomCode && (
                      <div className="space-y-4 py-4 ">
                        <div className="space-y-3">
                          <Label className="text-sm font-medium text-neutral-800! dark:text-white!">
                            New Room Code:
                          </Label>
                          <div className="flex items-center gap-2">
                            <Input
                              value={newRoomCode}
                              readOnly
                              className="font-mono text-center text-lg tracking-wider"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              onClick={handleCopyCode}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="text-xs border text-neutral-800 dark:text-white border-primary rounded p-3">
                            ⚠️ Make sure to share this code with your members
                            before saving.
                          </div>
                        </div>
                      </div>
                    )}

                    <DialogFooter>
                      <DialogClose asChild>
                        <Button variant="outline" onClick={handleModalClose}>
                          Cancel
                        </Button>
                      </DialogClose>
                      {!newRoomCode ? (
                        <Button
                          onClick={handleGenerateNewCode}
                          disabled={isGenerating}
                          className="gap-2"
                        >
                          {isGenerating ? (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin" />
                              Generating...
                            </>
                          ) : (
                            <>
                              <RefreshCw className="w-4 h-4" />
                              Generate Code
                            </>
                          )}
                        </Button>
                      ) : (
                        <DialogClose asChild>
                          <Button
                            onClick={handleSaveNewCode}
                            disabled={isSaving}
                          >
                            {isSaving ? "Saving..." : "Save Code"}
                          </Button>
                        </DialogClose>
                      )}
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="text-xs border border-red-500 dark:border-red-600 text-neutral-800 dark:text-white rounded p-3">
                ⚠️ Generating a new code will invalidate the current one. All
                members will need the new code to rejoin.
              </div>
            </div>
          )}
        </div>
      </div>

      <Separator className="bg-neutral-200 dark:bg-neutral-700" />

      {/* Theme Section */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-neutral-800 dark:text-white">
          User Settings
        </h3>
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-neutral-800 dark:text-neutral-400">
            Change theme
          </span>
          <ThemeToggler />
        </div>
      </div>

      {/* Audio Devices Section */}
      <AudioDevicesSection localParticipant={localParticipant} />

      {/* Save Button */}
      <div className="flex gap-3 pt-4">
        <Button
          type="submit"
          disabled={!isDirty || isSubmitting}
          className="flex-1 bg-primary hover:bg-primary/90 text-white"
        >
          {isSubmitting ? "Saving..." : "Save Changes"}
        </Button>
        <DialogClose asChild>
          <Button
            variant="outline"
            className="border-neutral-200 text-neutral-800 dark:bg-neutral-800 dark:border-neutral-700 dark:text-white hover:bg-neutral-200 dark:hover:bg-neutral-700"
            type="button"
          >
            Cancel
          </Button>
        </DialogClose>
      </div>
    </form>
  );
};
