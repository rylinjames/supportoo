"use node";

import { action } from "./_generated/server";
import { v } from "convex/values";
import { AccessToken, RoomServiceClient } from "livekit-server-sdk";

// Generate LiveKit token for a user to join a room
export const generateLiveKitToken = action({
  args: {
    roomName: v.string(),
    participantName: v.string(),
    userId: v.string(),
    companyId: v.string(),
    roomId: v.string(),
    userRole: v.optional(
      v.union(
        v.literal("moderator"),
        v.literal("speaker"),
        v.literal("listener")
      )
    ), // Pass role from client
  },
  handler: async (ctx, args) => {
    const apiKey = process.env.LIVEKIT_API_KEY;
    const apiSecret = process.env.LIVEKIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      throw new Error("LiveKit API credentials not configured");
    }

    // Determine permissions based on role
    const canPublishAudio =
      args.userRole === "moderator" || args.userRole === "speaker";
    const canPublishVideo = args.userRole === "moderator"; // Only moderators can screen share

    // Create access token
    const at = new AccessToken(apiKey, apiSecret, {
      identity: args.userId,
      name: args.participantName,
      metadata: JSON.stringify({
        companyId: args.companyId,
        roomId: args.roomId,
        userId: args.userId,
        canScreenShare: canPublishVideo, // Flag for frontend to show/hide screen share controls
      }),
    });

    // Grant permissions based on role
    at.addGrant({
      room: args.roomName,
      roomJoin: true,
      canPublish: canPublishAudio, // Audio publishing (moderators + speakers)
      canSubscribe: true, // Everyone can subscribe (hear/see others)
      canPublishData: true, // Data channel for screen share coordination
    });

    // Generate token - await the Promise
    const token = await at.toJwt();

    return {
      token: token,
      roomName: args.roomName,
    };
  },
});

// Test LiveKit RoomService - list all rooms
export const testLiveKitRooms = action({
  args: {},
  handler: async (ctx) => {
    const apiKey = process.env.LIVEKIT_API_KEY;
    const apiSecret = process.env.LIVEKIT_API_SECRET;
    const livekitUrl = process.env.NEXT_PUBLIC_LIVEKIT_URL;

    if (!apiKey || !apiSecret || !livekitUrl) {
      throw new Error("LiveKit credentials not configured");
    }

    try {
      // Create RoomServiceClient
      const roomService = new RoomServiceClient(livekitUrl, apiKey, apiSecret);

      // List all LiveKit rooms
      const livekitRooms = await roomService.listRooms();

      return {
        success: true,
        roomCount: livekitRooms.length,
        rooms: livekitRooms.map((room) => ({
          name: room.name,
          numParticipants: room.numParticipants,
          creationTime: room.creationTime,
          metadata: room.metadata,
        })),
      };
    } catch (error) {
      console.error("LiveKit RoomService error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  },
});

// Remove participant from LiveKit room using server API
export const removeParticipantFromLiveKit = action({
  args: {
    roomName: v.string(),
    participantIdentity: v.string(),
  },
  handler: async (ctx, args) => {
    const apiKey = process.env.LIVEKIT_API_KEY;
    const apiSecret = process.env.LIVEKIT_API_SECRET;
    const livekitUrl = process.env.NEXT_PUBLIC_LIVEKIT_URL;

    if (!apiKey || !apiSecret || !livekitUrl) {
      throw new Error("LiveKit API credentials not configured");
    }

    try {
      const roomService = new RoomServiceClient(livekitUrl, apiKey, apiSecret);
      await roomService.removeParticipant(
        args.roomName,
        args.participantIdentity
      );
      return { success: true };
    } catch (error) {
      console.error("LiveKit removeParticipant error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  },
});

// Delete a LiveKit room by name
export const deleteLiveKitRoom = action({
  args: { roomName: v.string() },
  handler: async (ctx, args) => {
    const apiKey = process.env.LIVEKIT_API_KEY;
    const apiSecret = process.env.LIVEKIT_API_SECRET;
    const livekitUrl = process.env.NEXT_PUBLIC_LIVEKIT_URL;

    if (!apiKey || !apiSecret || !livekitUrl) {
      throw new Error("LiveKit credentials not configured");
    }

    const roomService = new RoomServiceClient(livekitUrl, apiKey, apiSecret);
    try {
      await roomService.deleteRoom(args.roomName);
      return { success: true };
    } catch (error) {
      // If the room doesn't exist anymore, consider it success
      console.error("LiveKit deleteRoom error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  },
});

// Update a participant's publish permission (grant/revoke canPublish) mid-call
export const setParticipantPublishPermission = action({
  args: {
    roomName: v.string(),
    participantIdentity: v.string(),
    canPublish: v.boolean(),
  },
  handler: async (ctx, args) => {
    const apiKey = process.env.LIVEKIT_API_KEY;
    const apiSecret = process.env.LIVEKIT_API_SECRET;
    const livekitUrl = process.env.NEXT_PUBLIC_LIVEKIT_URL;

    if (!apiKey || !apiSecret || !livekitUrl) {
      throw new Error("LiveKit credentials not configured");
    }

    try {
      const roomService = new RoomServiceClient(livekitUrl, apiKey, apiSecret);
      // The SDK supports updating participant permissions; use any to avoid type friction across versions
      await (roomService as any).updateParticipant(
        args.roomName,
        args.participantIdentity,
        {
          permission: {
            canPublish: args.canPublish,
            canSubscribe: true,
            canPublishData: true,
          },
        }
      );
      return { success: true };
    } catch (error) {
      console.error("LiveKit setParticipantPublishPermission error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  },
});
