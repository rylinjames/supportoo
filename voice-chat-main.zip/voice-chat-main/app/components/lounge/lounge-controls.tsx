"use client";

import { motion } from "motion/react";
import { Mic, MicOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { SignOutIcon } from "@phosphor-icons/react";

interface LoungeControlsProps {
  isMuted: boolean;
  onToggleMute: () => void;
  onDisconnect: () => void;
  userRole?: string;
  isPublic: boolean;
  canPublishAudio?: boolean;
}

export function LoungeControls({
  isMuted,
  onToggleMute,
  onDisconnect,
  userRole,
  isPublic,
  canPublishAudio,
}: LoungeControlsProps) {
  // Only show mute button for moderators and speakers and when LiveKit allows publishing
  const roleAllowsMic = userRole === "moderator" || userRole === "speaker";
  const canUseMicrophone = roleAllowsMic && canPublishAudio === true;

  return (
    <motion.div
      className="border-t border-neutral-200 dark:border-neutral-800 p-6 max-md:p-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <div className="flex items-center justify-center gap-4">
        {canUseMicrophone && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="lg"
                onClick={onToggleMute}
                className={`w-14 h-14 rounded-full border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-700`}
              >
                {isMuted ? (
                  <MicOff className="w-6 h-6" />
                ) : (
                  <Mic className="w-6 h-6" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{isMuted ? "Unmute Microphone" : "Mute Microphone"}</p>
            </TooltipContent>
          </Tooltip>
        )}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="lg"
              onClick={onDisconnect}
              className="w-14 h-14 rounded-full relative bg-primary hover:bg-primary/80 text-white"
            >
              <SignOutIcon className="size-5 text-white" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Leave Lounge</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </motion.div>
  );
}
