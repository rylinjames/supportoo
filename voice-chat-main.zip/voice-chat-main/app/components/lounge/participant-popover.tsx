"use client";

import { motion } from "motion/react";
import { Mic, MicOff, Crown, Users, UserX } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/animate-ui/radix/popover";
import { Button } from "@/components/ui/button";
import { ParticipantTile } from "./participant-tile";
import { Participant } from "./types";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/avatar";
import { useAction } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useEffect, useState } from "react";

interface ParticipantPopoverProps {
  participant: Participant;
  index: number;
  size?: "small" | "large";
  currentUserRole?: string;
  currentUserId?: string;
  isRoomCreator?: boolean;
  roomId: string;
  convexUserId: string;
  onAddToSpeakers?: (participantId: string) => void;
  onRemoveFromSpeakers?: (participantId: string) => void;
  onKickFromLounge?: (participantId: string) => void;
  onPromoteToModerator?: (participantId: string) => void;
  onDemoteModeratorToSpeaker?: (participantId: string) => void;
  onMuteParticipant?: (participantId: string) => void;
  onUnmuteParticipant?: (participantId: string) => void;
  canManageModerators?: boolean;
  whopCompanyId?: string;
}

export function ParticipantPopover({
  participant,
  index,
  size = "large",
  currentUserRole,
  currentUserId,
  isRoomCreator = false,
  roomId,
  convexUserId,
  onAddToSpeakers,
  onRemoveFromSpeakers,
  onKickFromLounge,
  onPromoteToModerator,
  onDemoteModeratorToSpeaker,
  onMuteParticipant,
  onUnmuteParticipant,
  canManageModerators,
  whopCompanyId,
}: ParticipantPopoverProps) {
  const checkAdmin = useAction(api.whop.checkUserIsCompanyAdmin);
  const [isTargetCompanyAdmin, setIsTargetCompanyAdmin] =
    useState<boolean>(false);
  const [adminChecked, setAdminChecked] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    const run = async () => {
      setAdminChecked(false);
      setIsTargetCompanyAdmin(false);
      try {
        if (participant?.whopUserId && whopCompanyId) {
          const res = await checkAdmin({
            whopUserId: participant.whopUserId,
            whopCompanyId,
          });
          if (isMounted) {
            setIsTargetCompanyAdmin(Boolean(res?.isAdmin));
          }
        }
      } catch {}
      if (isMounted) setAdminChecked(true);
    };
    run();
    return () => {
      isMounted = false;
    };
  }, [participant?.whopUserId, whopCompanyId, checkAdmin]);

  // Determine if current user can open this participant's popover
  let canShowPopover = false;
  if (
    currentUserRole === "moderator" &&
    participant.whopUserId !== currentUserId
  ) {
    if (participant.role === "moderator") {
      // Only creator/company-admin can open other moderator tiles, never on the creator tile, and not for company admins
      canShowPopover = Boolean(
        canManageModerators && !isRoomCreator && !isTargetCompanyAdmin
      );
    } else {
      // Speakers/listeners: any moderator can open
      canShowPopover = true;
    }
  }

  // If not a moderator or clicking on another moderator or self, just show the regular card
  if (!canShowPopover) {
    return (
      <ParticipantTile
        participant={participant}
        index={index}
        size={size}
        isRoomCreator={isRoomCreator}
        roomId={roomId}
        convexUserId={convexUserId}
      />
    );
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <div className="cursor-pointer">
          <ParticipantTile
            participant={participant}
            index={index}
            size={size}
            isRoomCreator={isRoomCreator}
            roomId={roomId}
            convexUserId={convexUserId}
          />
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-60 p-0" align="center">
        <div className="p-4">
          {/* Participant Info */}
          <div className="flex items-center gap-3 mb-4">
            <Avatar className="w-12 h-12">
              <AvatarImage src={participant.avatar} alt={participant.name} />
              <AvatarFallback className="text-xs">
                {participant.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold">{participant.name}</h3>
              <p className="text-sm text-neutral-400 flex items-center gap-1">
                {participant.role === "speaker" ? (
                  <>
                    <Mic className="w-3 h-3" />
                    Speaker
                  </>
                ) : (
                  <>
                    <Users className="w-3 h-3" />
                    Listener
                  </>
                )}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2">
            {/* Role Management */}
            {participant.role === "listener" ? (
              <Button
                onClick={() => onAddToSpeakers?.(participant.id)}
                className="w-full justify-start bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Mic className="w-4 h-4 mr-2" />
                Add to Speakers
              </Button>
            ) : participant.role === "speaker" ? (
              <>
                <Button
                  onClick={() => onRemoveFromSpeakers?.(participant.id)}
                  className="w-full justify-start bg-yellow-600 hover:bg-yellow-700 text-white"
                >
                  <MicOff className="w-4 h-4 mr-2" />
                  Remove from Speakers
                </Button>
                {/* Mute/Unmute Speaker */}
                {currentUserRole === "moderator" && (
                  <Button
                    onClick={() =>
                      participant.isMuted
                        ? onUnmuteParticipant?.(participant.id)
                        : onMuteParticipant?.(participant.id)
                    }
                    className={`w-full justify-start ${
                      participant.isMuted
                        ? "bg-green-600 hover:bg-green-700"
                        : "bg-red-600 hover:bg-red-700"
                    } text-white`}
                  >
                    {participant.isMuted ? (
                      <Mic className="w-4 h-4 mr-2" />
                    ) : (
                      <MicOff className="w-4 h-4 mr-2" />
                    )}
                    {participant.isMuted ? "Unmute Speaker" : "Mute Speaker"}
                  </Button>
                )}
              </>
            ) : !isTargetCompanyAdmin ? (
              canManageModerators && (
                <Button
                  onClick={() => onDemoteModeratorToSpeaker?.(participant.id)}
                  className="w-full justify-start bg-yellow-600 hover:bg-yellow-700 text-white"
                >
                  <MicOff className="w-4 h-4 mr-2" />
                  Demote to Speaker
                </Button>
              )
            ) : (
              <div className="text-sm text-neutral-500">Company admin</div>
            )}

            {/* Promote to Moderator (creator/admin only; enforced server-side) */}
            {participant.role === "speaker" &&
              canManageModerators &&
              !isTargetCompanyAdmin && (
                <Button
                  onClick={() => onPromoteToModerator?.(participant.id)}
                  className="w-full justify-start bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Promote to Moderator
                </Button>
              )}

            {/* Kick from Lounge */}
            {(participant.role !== "moderator" ||
              (canManageModerators && !isTargetCompanyAdmin)) && (
              <Button
                onClick={() => onKickFromLounge?.(participant.id)}
                className="w-full justify-start bg-red-600 hover:bg-red-700 text-white"
              >
                <UserX className="w-4 h-4 mr-2" />
                Kick User
              </Button>
            )}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
