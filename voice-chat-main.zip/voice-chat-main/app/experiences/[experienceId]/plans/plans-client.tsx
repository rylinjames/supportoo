"use client";

import { useSessionStore } from "@/stores/session-store";
import { useQuery, useAction } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  CrownIcon,
  StarIcon,
  ZapIcon,
  UsersIcon,
  CircleCheckBigIcon,
  ArrowLeftIcon,
} from "lucide-react";
import LoadingScreen from "@/app/components/shared/loading-screen";
import { ThemeToggler } from "@/app/components/shared/theme-toggler";
import Link from "next/link";
import MinutesBoost from "./minutes-boost";
import CheckoutModal from "./checkout-modal";
import PlanOwnerModal from "./plan-owner-modal";
import DowngradeModal from "./downgrade-modal";
import UpgradeModal from "./upgrade-modal";
import MidTierDowngradeModal from "./mid-tier-downgrade-modal";
import { toast } from "sonner";
import { useWhopPayments } from "@/app/providers/whop-payments-provider";
import { Id } from "@/convex/_generated/dataModel";

interface PlansClientProps {
  whopUserId: string;
  whopUsername: string;
  fullName: string;
  avatarUrl: string;
  whopCompanyId: string;
  whopExperienceId: string;
  companyName: string;
  companyLogo: string;
  whopAccessLevel: string | null;
}

export default function PlansClient(props: PlansClientProps) {
  const { session } = useSessionStore();

  // Helper function to get plan tier index for comparison
  const getPlanTierIndex = (tier: string) => {
    const tierOrder = { free: 0, starter: 1, pro: 2, creator: 3 };
    return tierOrder[tier as keyof typeof tierOrder] || 0;
  };

  // Get company plan settings
  const planSettings = useQuery(api.plans.getCompanyPlanSettings, {
    companyId: session?.convexCompanyId as any,
  });

  // Get company usage data
  const companyUsage = useQuery(api.plans.getCompanyUsageSummary, {
    companyId: session?.convexCompanyId as any,
  });

  // Get plan catalog
  const planCatalog = useQuery(api.plans.getCatalog);
  const checkoutConfig = useQuery(api.billing.getCheckoutConfig, {});

  // Get plan owner details
  const planOwnerDetails = useQuery(api.plans.getPlanOwnerDetails, {
    companyId: session?.convexCompanyId as any,
  });

  // Checkout modal state
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [selectedPlanId, setSelectedPlanId] = useState<string | undefined>(
    undefined
  );
  const [selectedTitle, setSelectedTitle] = useState<string>("Secure Checkout");
  const [selectedAmount, setSelectedAmount] = useState<number | undefined>(
    undefined
  );
  const [selectedDescription, setSelectedDescription] = useState<
    string | undefined
  >(undefined);
  const [selectedMetadata, setSelectedMetadata] = useState<
    | {
        type: "plan" | "credits";
        planTier?: string;
        credits?: number;
      }
    | undefined
  >(undefined);
  const [fallbackUrl, setFallbackUrl] = useState<string | undefined>(undefined);

  // Plan owner modal state
  const [planOwnerModalOpen, setPlanOwnerModalOpen] = useState(false);

  // Downgrade modal state
  const [downgradeModalOpen, setDowngradeModalOpen] = useState(false);
  const [downgradeTarget, setDowngradeTarget] = useState<{
    name: string;
    tier: string;
  } | null>(null);

  // Upgrade modal state
  const [upgradeModalOpen, setUpgradeModalOpen] = useState(false);
  const [upgradeTarget, setUpgradeTarget] = useState<{
    name: string;
    tier: string | undefined;
  } | null>(null);

  // Mid-tier downgrade modal state
  const [midTierDowngradeModalOpen, setMidTierDowngradeModalOpen] =
    useState(false);
  const [midTierDowngradeTarget, setMidTierDowngradeTarget] = useState<{
    name: string;
    tier: string | undefined;
  } | null>(null);

  // Cancellation confirmation state
  const [cancelConfirmationOpen, setCancelConfirmationOpen] = useState(false);

  // Actions
  const cancelMembership = useAction(api.whop.cancelMembership);
  const createCheckoutSession = useAction(api.whop.createCheckoutSession);
  const createCharge = useAction(api.whop.createCharge);
  const { chargeUserWithModal, isLoaded } = useWhopPayments();

  const openCheckout = (
    planId: string,
    title: string,
    amount: number,
    metadata: {
      type: "plan" | "credits";
      planTier?: string;
      credits?: number;
    },
    description?: string,
    url?: string
  ) => {
    setSelectedPlanId(planId);
    setSelectedTitle(title);
    setSelectedAmount(amount);
    setSelectedMetadata(metadata);
    setSelectedDescription(description);
    setFallbackUrl(url);
    setCheckoutOpen(true);
  };

  const handlePlanChange = async (
    planId: string,
    title: string,
    url?: string,
    planTier?: string,
    planName?: string
  ) => {
    // Check if current user is the plan owner
    const currentUserWhopId = session?.whopUserId;
    const isPlanOwner = planOwnerDetails?.whopUserId === currentUserWhopId;

    if (!isPlanOwner && planOwnerDetails) {
      // Show plan owner modal
      setPlanOwnerModalOpen(true);
      return;
    }

    if (!planTier || !session?.convexCompanyId || !currentUserWhopId) {
      toast.error("Missing required information");
      return;
    }

    const currentTierIndex = getPlanTierIndex(currentPlan);
    const targetTierIndex = getPlanTierIndex(planTier);

    // Scenario 1: Downgrade to Free
    if (planTier === "free") {
      setDowngradeTarget({ name: planName || title, tier: planTier });
      setDowngradeModalOpen(true);
      return;
    }

    // Scenario 2: Mid-tier downgrade (creator → pro, pro → starter)
    if (targetTierIndex < currentTierIndex) {
      setMidTierDowngradeTarget({ name: planName || title, tier: planTier });
      setMidTierDowngradeModalOpen(true);
      return;
    }

    // Scenario 3: Upgrade (starter → pro, pro → creator)
    if (targetTierIndex > currentTierIndex && currentPlan !== "free") {
      // User has a paid plan - show upgrade confirmation modal
      setUpgradeTarget({ name: planName || title, tier: planTier });
      setUpgradeModalOpen(true);
      return;
    }

    // Scenario 4: New subscription (free → starter/pro/creator)
    if (currentPlan === "free") {
      // Get plan pricing info from catalog
      const planInfo = planCatalog?.[planTier];
      if (!planInfo) {
        toast.error("Plan information not found");
        return;
      }

      // Extract numeric price from string like "$15"
      const priceStr = planInfo.price.replace("$", "");
      const price = parseFloat(priceStr);

      openCheckout(
        planId,
        title,
        price,
        {
          type: "plan",
          planTier: planTier,
        },
        `Subscribe to ${planName || title}`,
        url
      );
    }
  };

  // Handle downgrade to free confirmation
  const handleDowngradeToFree = async () => {
    if (!session?.convexCompanyId || !session?.whopUserId) {
      toast.error("Missing required information");
      return;
    }

    try {
      toast.info("Cancelling subscription...");
      const result = await cancelMembership({
        companyId: session.convexCompanyId as Id<"companies">,
        whopUserId: session.whopUserId,
      });

      toast.success(result.message);
      setDowngradeModalOpen(false);
      setDowngradeTarget(null);
    } catch (error) {
      console.error("Failed to cancel membership:", error);
      toast.error(
        error instanceof Error ? error.message : "Failed to cancel subscription"
      );
    }
  };

  // Handle upgrade confirmation (two-step process)
  const handleUpgradeConfirm = async () => {
    if (
      !upgradeTarget ||
      !session?.convexCompanyId ||
      !session?.whopUserId ||
      !upgradeTarget.tier
    ) {
      toast.error("Missing required information");
      setUpgradeModalOpen(false);
      return;
    }

    try {
      // Step 1: Cancel current membership
      toast.info("Cancelling current membership...");
      await cancelMembership({
        companyId: session.convexCompanyId as Id<"companies">,
        whopUserId: session.whopUserId,
      });

      // Step 2: Create checkout session for new plan
      toast.info("Opening checkout for new plan...");
      const sessionData = await createCheckoutSession({
        companyId: session.convexCompanyId as Id<"companies">,
        targetPlanTier: upgradeTarget.tier as
          | "free"
          | "starter"
          | "pro"
          | "creator",
        whopUserId: session.whopUserId,
        allowDowngrade: false, // This is an upgrade
      });

      if (!isLoaded) {
        toast.error("Payment system not ready. Please refresh and try again.");
        setUpgradeModalOpen(false);
        return;
      }

      // Step 3: Create charge and open payment modal
      const chargeResult = await createCharge({
        userId: session.whopUserId,
        experienceId: session.whopExperienceId,
        planId: sessionData.planId,
        amount: sessionData.planPrice,
        title: sessionData.planTitle,
        metadata: {
          type: "plan",
          planTier: upgradeTarget.tier,
          traceId: `upgrade_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`,
          companyId: session.whopCompanyId,
        },
      });

      if (!chargeResult.success || !chargeResult.session) {
        throw new Error(chargeResult.error || "Failed to create charge");
      }

      // Step 4: Open Whop payment modal
      const paymentResult = await chargeUserWithModal(chargeResult.session);

      if (paymentResult.success) {
        toast.success("Payment successful! Plan upgraded.");
        setUpgradeModalOpen(false);
        setUpgradeTarget(null);
      } else {
        toast.error(paymentResult.error || "Payment failed");
      }
    } catch (error) {
      console.error("Error upgrading plan:", error);
      toast.error(
        error instanceof Error ? error.message : "Failed to upgrade plan"
      );
      setUpgradeModalOpen(false);
    }
  };

  // Handle mid-tier downgrade confirmation (two-step process)
  const handleMidTierDowngradeConfirm = async () => {
    if (
      !midTierDowngradeTarget ||
      !session?.convexCompanyId ||
      !session?.whopUserId ||
      !midTierDowngradeTarget.tier
    ) {
      toast.error("Missing required information");
      setMidTierDowngradeModalOpen(false);
      return;
    }

    try {
      // Step 1: Cancel current membership
      toast.info("Cancelling current membership...");
      await cancelMembership({
        companyId: session.convexCompanyId as Id<"companies">,
        whopUserId: session.whopUserId,
      });

      // Step 2: Create checkout session for new plan
      toast.info("Opening checkout for new plan...");
      const sessionData = await createCheckoutSession({
        companyId: session.convexCompanyId as Id<"companies">,
        targetPlanTier: midTierDowngradeTarget.tier as
          | "free"
          | "starter"
          | "pro"
          | "creator",
        whopUserId: session.whopUserId,
        allowDowngrade: true, // Bypass hierarchy check for downgrades
      });

      if (!isLoaded) {
        toast.error("Payment system not ready. Please refresh and try again.");
        setMidTierDowngradeModalOpen(false);
        return;
      }

      // Step 3: Create charge and open payment modal
      const chargeResult = await createCharge({
        userId: session.whopUserId,
        experienceId: session.whopExperienceId,
        planId: sessionData.planId,
        amount: sessionData.planPrice,
        title: sessionData.planTitle,
        metadata: {
          type: "plan",
          planTier: midTierDowngradeTarget.tier,
          traceId: `downgrade_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`,
          companyId: session.whopCompanyId,
        },
      });

      if (!chargeResult.success || !chargeResult.session) {
        throw new Error(chargeResult.error || "Failed to create charge");
      }

      // Step 4: Open Whop payment modal
      const paymentResult = await chargeUserWithModal(chargeResult.session);

      if (paymentResult.success) {
        toast.success("Payment successful! Plan changed.");
        setMidTierDowngradeModalOpen(false);
        setMidTierDowngradeTarget(null);
      } else {
        toast.error(paymentResult.error || "Payment failed");
      }
    } catch (error) {
      console.error("Error downgrading plan:", error);
      toast.error(
        error instanceof Error ? error.message : "Failed to downgrade plan"
      );
      setMidTierDowngradeModalOpen(false);
    }
  };

  const handleCheckoutComplete = () => {
    toast.success("Payment completed. Refreshing usage…");
  };

  if (!session?.convexCompanyId) {
    return <LoadingScreen />;
  }

  if (
    !planSettings ||
    !companyUsage ||
    !planCatalog ||
    !checkoutConfig ||
    planOwnerDetails === undefined
  ) {
    return <LoadingScreen />;
  }

  const currentPlan = planSettings.planTier;
  const features = planSettings.features;

  // Build plans dynamically from database catalog in fixed order
  const tierOrder = ["free", "starter", "pro", "creator"] as const;
  const plans = tierOrder
    .map((tier) => {
      const planData = planCatalog[tier];
      const isCurrent = currentPlan === tier;

      // If no plan data exists for this tier, skip it
      if (!planData) {
        return null;
      }

      return {
        name: planData.name,
        tier: tier,
        price: planData.price,
        description: planData.description,
        features: planData.features,
        icon:
          tier === "free"
            ? UsersIcon
            : tier === "starter"
              ? ZapIcon
              : tier === "pro"
                ? StarIcon
                : CrownIcon,
        current: isCurrent,
        includedMinutes: planData.includedMinutes,
      };
    })
    .filter((plan): plan is NonNullable<typeof plan> => plan !== null); // Type-safe filter

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-background">
        <div className="container mx-auto px-4 py-3 flex w-full justify-between items-center">
          <div className="flex items-center gap-4">
            <Link
              href={`/experiences/${props.whopExperienceId}/browse`}
              className="text-sm "
            >
              <Button variant="ghost" size="sm">
                <ArrowLeftIcon className="w-4 h-4 text-neutral-800 dark:text-white" />
                Go to browse
              </Button>
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggler />
          </div>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-neutral-900 dark:text-white mb-2">
            Pricing Plans
          </h2>
          <p className="text-neutral-600 dark:text-neutral-400">
            Choose the perfect plan for your community
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan) => {
            return (
              <div
                key={plan.tier}
                className={`relative border min-h-[500px] flex flex-col h-full justify-between border-border rounded-lg bg-card p-6 ${
                  plan.current
                    ? "ring-2 ring-primary"
                    : "hover:shadow-lg transition-shadow"
                }`}
              >
                <div className="flex flex-col h-full">
                  {plan.current && (
                    <div className="absolute -top-4 right-1/2 translate-x-1/2">
                      <Badge
                        variant="secondary"
                        className="bg-primary text-white"
                      >
                        Current Plan
                      </Badge>
                    </div>
                  )}
                  <div className="text-left pb-4">
                    <h3 className="text-xs border uppercase py-0.5 px-2 max-w-max border-neutral-200 dark:border-neutral-600 rounded-md font-medium text-neutral-900 dark:text-white">
                      {plan.name}
                    </h3>
                    <div className="flex items-baseline justify-start gap-1 mt-4">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      {plan.price !== "$0" && (
                        <span className="text-neutral-600 dark:text-neutral-400">
                          /month
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-2">
                      {plan.description}
                    </p>
                  </div>

                  <div className="pt-0">
                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <CircleCheckBigIcon className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-neutral-700 dark:text-neutral-300">
                            {feature}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                {plan.current ? (
                  <Button
                    className="justify-self-end w-full"
                    variant="outline"
                    disabled
                  >
                    Current Plan
                  </Button>
                ) : (
                  <Button
                    className="justify-self-end w-full"
                    variant={
                      getPlanTierIndex(plan.tier) >
                      getPlanTierIndex(currentPlan)
                        ? "default"
                        : "outline"
                    }
                    disabled={
                      !checkoutConfig.plans[
                        plan.tier as "free" | "starter" | "pro" | "creator"
                      ]
                    }
                    onClick={() => {
                      const cfg =
                        checkoutConfig.plans[
                          plan.tier as "free" | "starter" | "pro" | "creator"
                        ];
                      if (!cfg) return;
                      const actionLabel =
                        getPlanTierIndex(plan.tier) >
                        getPlanTierIndex(currentPlan)
                          ? "Upgrade to "
                          : "Switch to ";
                      handlePlanChange(
                        cfg.planId,
                        actionLabel + plan.name,
                        cfg.url,
                        plan.tier,
                        plan.name
                      );
                    }}
                  >
                    {getPlanTierIndex(plan.tier) > getPlanTierIndex(currentPlan)
                      ? "Upgrade"
                      : "Downgrade"}
                  </Button>
                )}
              </div>
            );
          })}
        </div>

        {/* Minute Pack Boosts */}
        <div className="mt-12">
          <div className="text-center mb-8">
            <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mb-2">
              Or you can further boost your minutes with our booster packs
            </h3>
            <p className="text-neutral-600 dark:text-neutral-400">
              Need more minutes? Grab a boost pack to keep your lounges running
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {checkoutConfig.packs.map((p) => (
              <MinutesBoost
                key={p.planId}
                price={`$${p.price}`}
                minutes={`${p.minutes.toLocaleString()} minutes`}
                label="Booster"
                onGetPack={() =>
                  openCheckout(
                    p.planId,
                    `${p.minutes.toLocaleString()} Minutes Booster Pack`,
                    p.price,
                    {
                      type: "credits",
                      credits: p.minutes,
                    },
                    `Get ${p.minutes.toLocaleString()} extra minutes for your lounges`,
                    p.url
                  )
                }
              />
            ))}
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-12 text-center">
          <Separator className="my-8" />
          <h3 className="text-xl font-semibold text-neutral-900 dark:text-white mb-4">
            Need a custom plan?
          </h3>
          <p className="text-neutral-600 dark:text-neutral-400 mb-6 max-w-2xl mx-auto">
            For enterprise needs or custom requirements, contact our team to
            discuss a tailored solution that fits your specific use case.
          </p>
          <Button size="lg">Contact Sales</Button>
        </div>
      </div>
      <CheckoutModal
        open={checkoutOpen}
        onOpenChange={setCheckoutOpen}
        planId={selectedPlanId}
        amount={selectedAmount}
        title={selectedTitle}
        description={selectedDescription}
        metadata={selectedMetadata}
        onComplete={handleCheckoutComplete}
      />
      <PlanOwnerModal
        open={planOwnerModalOpen}
        onOpenChange={setPlanOwnerModalOpen}
        planOwnerName={planOwnerDetails?.fullName}
        planOwnerUsername={planOwnerDetails?.whopUsername}
      />
      <DowngradeModal
        open={downgradeModalOpen}
        onOpenChange={setDowngradeModalOpen}
        currentPlanName={planCatalog[currentPlan]?.name || "Current Plan"}
        targetPlanName={downgradeTarget?.name || "Target Plan"}
        onConfirm={handleDowngradeToFree}
      />
      <UpgradeModal
        open={upgradeModalOpen}
        onOpenChange={setUpgradeModalOpen}
        targetPlan={upgradeTarget}
        onConfirm={handleUpgradeConfirm}
      />
      <MidTierDowngradeModal
        open={midTierDowngradeModalOpen}
        onOpenChange={setMidTierDowngradeModalOpen}
        targetPlan={midTierDowngradeTarget}
        onConfirm={handleMidTierDowngradeConfirm}
      />
    </div>
  );
}
