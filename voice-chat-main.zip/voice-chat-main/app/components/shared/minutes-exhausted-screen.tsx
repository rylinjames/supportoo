"use client";

import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { RefreshCw, ArrowRight, Mic, Zap } from "lucide-react";
import Link from "next/link";

interface MinutesExhaustedScreenProps {
  isAdmin: boolean;
  experienceId: string;
  companyName?: string;
}

export function MinutesExhaustedScreen({
  isAdmin,
  experienceId,
  companyName,
}: MinutesExhaustedScreenProps) {
  const router = useRouter();

  return (
    <div className="flex items-center justify-center min-h-screen h-full p-8 relative">
      <div className="text-center max-w-md">
        <div className="flex flex-col gap-2 justify-center items-center">
          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-primary flex items-center justify-center animate-pulse">
            <Mic className="h-16 w-16 text-white" />
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 mt-2">
          <div className="flex flex-col items-center justify-center gap-2">
            <p className="text-sm text-red-600 dark:text-red-400 p-2 bg-red-600/10 dark:bg-red-400/10 rounded-md">
              Your Whop has run out of minutes for voice chat. The lounge has
              been temporarily shut down.
            </p>
            <div className="flex gap-3 justify-center">
              {/* Primary CTA: Upgrade Plan (always visible) */}
              <Button
                onClick={() =>
                  router.push(`/experiences/${experienceId}/plans`)
                }
                className="flex items-center gap-2 text-white bg-blue-600 hover:bg-blue-700"
              >
                <Zap className="h-4 w-4" />
                Upgrade Plan
              </Button>

              {/* Secondary actions */}
              <Button
                onClick={() => router.refresh()}
                variant="outline"
                className="flex items-center gap-2"
              >
                <RefreshCw className="h-4 w-4" />
                Try Again
              </Button>
              <Button
                onClick={() =>
                  router.push(`/experiences/${experienceId}/browse`)
                }
                variant="outline"
                className="flex items-center gap-2"
              >
                <ArrowRight className="h-4 w-4" />
                Go to Browse
              </Button>
            </div>
          </div>
        </div>
      </div>
      <p className="text-sm text-neutral-600 dark:text-neutral-400 absolute bottom-4 left-1/2 -translate-x-1/2">
        powered by{" "}
        <Link
          className="text-black dark:text-white hover:underline"
          href="https://whop.com/joined/bookoo-apps-developers/"
        >
          Bookoo Apps
        </Link>
      </p>
    </div>
  );
}
