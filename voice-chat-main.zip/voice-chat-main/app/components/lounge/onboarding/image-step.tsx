"use client";

import { Button } from "@/components/ui/button";
import { Image as ImageIcon, ArrowLeft, Crown, Upload, X } from "lucide-react";
import { ThemeToggler } from "../../shared/theme-toggler";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { useRef, useState } from "react";
import { useImageKitUpload } from "@/app/hooks/use-imagekit-upload";
import { validateImageFile } from "@/lib/imagekit";
import { OptimizedImage } from "../../shared/optimized-image";

interface ImageStepProps {
  roomImage?: string;
  usingDefault?: boolean;
  companyId: string;
  onContinue: (uploadedImageUrl?: string) => void;
  onBack: () => void;
  onSkip: () => void;
  onUpgradeToPro: () => void;
}

export function ImageStep({
  roomImage,
  usingDefault = false,
  companyId,
  onContinue,
  onBack,
  onSkip,
  onUpgradeToPro,
}: ImageStepProps) {
  // Check if company can upload custom images
  const uploadPermissions = useQuery(api.plans.canCompanyUploadImages, {
    companyId: companyId as Id<"companies">,
  });

  const isLoading = uploadPermissions === undefined;
  const canUpload = uploadPermissions?.canUpload ?? false;
  const currentTier = uploadPermissions?.currentTier ?? "free";

  // File picker state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);

  // ImageKit upload hook
  const {
    upload,
    isUploading,
    progress,
    error: uploadError,
    result,
    reset,
  } = useImageKitUpload({
    folder: "/room-images",
    useUniqueFileName: true,
  });

  // Use the centralized validation from lib
  const validateFile = (file: File): string | null => {
    const validation = validateImageFile(file);
    return validation.valid ? null : validation.error!;
  };

  // Handle file selection
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    setFileError(null);
    reset(); // Reset upload state

    if (!file) return;

    const error = validateFile(file);
    if (error) {
      setFileError(error);
      setSelectedFile(null);
      setPreviewUrl(null);
      return;
    }

    setSelectedFile(file);

    // Create preview URL
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  // Remove selected file
  const handleRemoveFile = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setFileError(null);
    reset(); // Reset upload state
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Handle continue with upload
  const handleContinue = async () => {
    if (selectedFile && canUpload) {
      if (!result) {
        // Upload the file first
        const uploadResult = await upload(selectedFile);
        if (uploadResult) {
          onContinue(uploadResult.url);
        }
        // If upload failed, don't continue (error will be shown)
        return;
      } else {
        // File already uploaded, use the result
        onContinue(result.url);
        return;
      }
    }

    // No file selected, continue without custom image
    onContinue(undefined);
  };

  // Get display image (custom upload > room image > default)
  const displayImage = previewUrl || roomImage;
  const isUsingCustom = !!previewUrl;
  const isUsingDefault =
    !previewUrl && (!roomImage || roomImage.includes("whop-logo.png"));

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-foreground flex items-center justify-center p-4 relative">
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-neutral-800 rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">
              Room Image
            </h1>
            <p className="text-neutral-600 dark:text-neutral-400">
              Choose how your lounge will look
            </p>
          </div>

          <div className="space-y-6">
            {/* Current Image Preview */}
            <div className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg">
              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-3 rounded-lg bg-neutral-100 dark:bg-neutral-700 flex items-center justify-center relative">
                  {displayImage ? (
                    <>
                      <OptimizedImage
                        src={displayImage}
                        alt="Lounge"
                        width={80}
                        height={80}
                        className="w-full h-full object-cover rounded-lg"
                      />
                      {isUsingCustom && (
                        <button
                          onClick={handleRemoveFile}
                          className="absolute -top-2 -right-2 size-4 bg-primary text-white rounded-full flex items-center justify-center cursor-pointer transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </>
                  ) : (
                    <ImageIcon className="w-8 h-8 text-neutral-400" />
                  )}
                </div>
                <p className="text-sm text-neutral-600 dark:text-neutral-400">
                  {isUsingCustom
                    ? "Custom uploaded image"
                    : isUsingDefault
                      ? "Using default image"
                      : "Using experience image"}
                </p>
              </div>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg">
                <div className="text-center">
                  <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    Checking upload permissions...
                  </p>
                </div>
              </div>
            )}

            {/* Upload Option - For Starter+ Tiers */}
            {!isLoading &&
              (canUpload || process.env.NODE_ENV === "development") && (
                <div className="p-4 border border-dashed border-primary rounded-lg">
                  <div className="text-center space-y-3">
                    <div>
                      <h3 className="font-medium text-neutral-900 dark:text-white">
                        Upload Custom Image
                      </h3>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">
                        Upload your own lounge image (max 500KB)
                      </p>
                    </div>

                    {/* Hidden file input */}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />

                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading}
                      className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/20"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      {isUploading ? "Uploading..." : "Choose Image"}
                    </Button>

                    {/* Upload progress */}
                    {isUploading && (
                      <div className="w-full">
                        <div className="flex justify-between text-xs text-neutral-600 dark:text-neutral-400 mb-1">
                          <span>Uploading...</span>
                          <span>{progress}%</span>
                        </div>
                        <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full transition-all duration-300"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {/* File error */}
                    {(fileError || uploadError) && (
                      <p className="text-xs text-red-500">
                        {fileError || uploadError}
                      </p>
                    )}

                    {/* Upload success */}
                    {result && (
                      <p className="text-xs text-green-600 dark:text-green-400">
                        ✓ Image uploaded successfully!
                      </p>
                    )}

                    {/* Selected file info */}
                    {selectedFile && !fileError && !result && !isUploading && (
                      <p className="text-xs text-green-600 dark:text-green-400">
                        ✓ {selectedFile.name} (
                        {Math.round(selectedFile.size / 1000)}KB) - Ready to
                        upload
                      </p>
                    )}
                  </div>
                </div>
              )}

            {/* Upgrade Prompt - For Free Tier */}
            {!isLoading &&
              !canUpload &&
              process.env.NODE_ENV !== "development" && (
                <div className="p-4 border border-dashed border-primary rounded-lg bg-primary/5 dark:bg-primary/10">
                  <div className="text-center space-y-3">
                    <div>
                      <h3 className="font-medium text-neutral-900 dark:text-white">
                        Upload Your Own Image
                      </h3>
                      <p className="text-sm text-neutral-600 dark:text-neutral-400">
                        Upgrade tier to upload custom lounge images
                      </p>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={onUpgradeToPro}
                      className="bg-primary/10 text-primary hover:text-white! dark:hover:text-white! border-primary/20 hover:bg-primary/20 dark:bg-primary/20 dark:text-primary dark:border-primary/30"
                    >
                      <Crown className="w-4 h-4 mr-2" />
                      Upgrade Tier
                    </Button>
                  </div>
                </div>
              )}

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onBack}
                className="flex-1"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onSkip}
                className="flex-1"
              >
                Skip
              </Button>
              <Button
                onClick={handleContinue}
                disabled={isUploading}
                className="flex-1 text-white"
              >
                {isUploading ? "Uploading..." : "Continue"}
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute top-4 right-4">
        <ThemeToggler />
      </div>
    </div>
  );
}
