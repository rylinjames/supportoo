/**
 * Whop Payments Integration Types
 *
 * Contract between client, server, and webhook handling
 */

// Server-side charge creation response
export interface CreateChargeResult {
  success: boolean;
  error?: string;
  traceId: string;
  status?: string;
  session?: {
    planId: string;
    sessionId?: string;
    status: string;
    amount: number;
    title: string;
  };
}

// Client-side payment modal response
export interface PaymentModalResult {
  success: boolean;
  error?: string;
  receiptId?: string;
}

// Combined charge + modal flow result
export interface CompletePaymentResult {
  success: boolean;
  error?: string;
  traceId?: string;
  sessionId?: string;
  receiptId?: string;
  requiresWebhook?: boolean; // If true, final confirmation comes via webhook
}

// Payment metadata for tracking
export interface PaymentMetadata {
  type: "plan" | "credits";
  experienceId: string;
  convexUserId?: string;
  traceId: string;
  // Plan-specific
  planTier?: string;
  // Credits-specific
  credits?: number;
  // Additional context
  source?: string; // e.g., "plans_page", "promo_dialog"
}

// Payment item configuration (matches current checkout config)
export interface PaymentItem {
  planId: string; // Whop plan/product ID
  price: number; // In dollars
  amount: number; // In cents (price * 100)
  title: string;
  description?: string;
  url?: string; // Fallback URL if needed
  metadata: PaymentMetadata;
}

// Plan subscription items
export interface PlanPaymentItem extends PaymentItem {
  tier: "starter" | "creator" | "enterprise";
  features: string[];
  popular?: boolean;
}

// Credit pack items
export interface CreditPackItem extends PaymentItem {
  minutes: number;
  label: string; // e.g., "Booster"
  value?: string; // e.g., "Best Value"
}

// Webhook payload structure (for validation)
export interface PaymentWebhookPayload {
  action: "payment.succeeded" | "payment.failed" | "payment.refunded";
  data: {
    id: string; // payment ID
    status: string;
    amount: number;
    chargeId?: string;
    userId: string;
    metadata?: Record<string, any>;
    createdAt: string;
    updatedAt: string;
  };
}

// Error types for better error handling
export type PaymentError =
  | "user_not_found"
  | "invalid_plan"
  | "insufficient_permissions"
  | "charge_creation_failed"
  | "modal_canceled"
  | "modal_failed"
  | "webhook_validation_failed"
  | "network_error"
  | "unknown_error";

export interface PaymentErrorDetails {
  code: PaymentError;
  message: string;
  traceId?: string;
  recoverable: boolean; // Can user retry?
}
