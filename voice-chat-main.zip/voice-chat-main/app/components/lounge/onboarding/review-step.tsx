"use client";

import { Button } from "@/components/ui/button";
import { Image as ImageIcon, ArrowLeft } from "lucide-react";
import { ROOM_CATEGORIES } from "@/convex/categories";
import { ThemeToggler } from "../../shared/theme-toggler";
import { OptimizedImage } from "../../shared/optimized-image";

interface ReviewStepProps {
  formData: {
    name: string;
    description?: string;
    category: string;
    roomImage?: string;
    isPublic: boolean;
    roomCode?: string;
    discoverListed?: boolean;
  };
  onBack: () => void;
  onSubmit: () => void;
  isCreating?: boolean;
}

export function ReviewStep({
  formData,
  onBack,
  onSubmit,
  isCreating = false,
}: ReviewStepProps) {
  const categoryName =
    ROOM_CATEGORIES.find((c) => c.id === formData.category)?.name || "Other";

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-foreground flex items-center justify-center p-4 relative">
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-neutral-800 rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">
              Review Your Lounge
            </h1>
            <p className="text-neutral-600 dark:text-neutral-400">
              Everything looks good!
            </p>
          </div>

          <div className="space-y-6">
            <div className="space-y-4 p-4 bg-neutral-50 dark:bg-neutral-700 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-lg bg-neutral-100 dark:bg-neutral-600 flex items-center justify-center overflow-hidden">
                  {formData.roomImage ? (
                    <OptimizedImage
                      src={formData.roomImage}
                      alt="Room"
                      width={48}
                      height={48}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  ) : (
                    <ImageIcon className="w-6 h-6 text-neutral-400" />
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-neutral-900 dark:text-white">
                    {formData.name}
                  </h3>
                  <p className="text-sm text-neutral-600 dark:text-neutral-400">
                    {categoryName}
                  </p>
                </div>
              </div>

              {formData.description && (
                <div className="text-sm text-neutral-600 dark:text-neutral-400">
                  {formData.description}
                </div>
              )}

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-600 dark:text-neutral-400">
                    Privacy:
                  </span>
                  <span className="text-neutral-900 dark:text-white">
                    {formData.isPublic ? "Public" : "Private"}
                  </span>
                </div>
                {!formData.isPublic && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">
                      Room Code:
                    </span>
                    <span className="font-mono text-neutral-900 dark:text-white">
                      {formData.roomCode}
                    </span>
                  </div>
                )}
                {formData.isPublic && formData.discoverListed && (
                  <div className="flex justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400">
                      Discoverable:
                    </span>
                    <span className="text-neutral-900 dark:text-white">
                      Yes
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onBack}
                disabled={isCreating}
                className="flex-1"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
              <Button
                onClick={onSubmit}
                disabled={isCreating}
                className="flex-1 text-white"
              >
                {isCreating ? "Creating..." : "Create Lounge"}
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute top-4 right-4">
        <ThemeToggler />
      </div>
    </div>
  );
}
