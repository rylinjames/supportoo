import { Skeleton } from "@/components/ui/skeleton";

const LoadingCard = () => {
  return (
    <div className="rounded-t-md min-w-[300px] w-[300px] overflow-hidden flex-1">
      <Skeleton className="w-full h-40 rounded-none" />
      <div className="p-4 flex rounded-b-md flex-col gap-1 bg-foreground dark:bg-[#1e1e1e] w-full border border-neutral-200 dark:border-none hover:shadow dark:shadow-none">
        <div className="flex w-full justify-between items-start">
          <div className="flex items-start gap-1">
            <Skeleton className="size-8 rounded-full" />
            <div className="flex flex-col gap-1">
              <Skeleton className="w-20 h-4" />
              <Skeleton className="w-15 h-4" />
            </div>
          </div>
          <Skeleton className="w-10 h-4" />
        </div>
        <div className="flex flex-col mt-2">
          <Skeleton className="w-40 h-4" />
        </div>
        <div className="mt-3 flex justify-between w-full">
          <div className="flex items-center gap-1">
            <Skeleton className="w-10 h-4" />
            <Skeleton className="w-10 h-4" />
          </div>
          <Skeleton className="w-15 h-4" />
        </div>
      </div>
    </div>
  );
};

export default LoadingCard;
