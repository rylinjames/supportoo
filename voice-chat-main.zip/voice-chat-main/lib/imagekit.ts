// ImageKit configuration for client-side
export const imagekitConfig = {
  publicKey: process.env.NEXT_PUBLIC_IMAGEKIT_PUBLIC_KEY || "",
  urlEndpoint: process.env.NEXT_PUBLIC_IMAGEKIT_URL_ENDPOINT || "",
  authenticationEndpoint: "/api/imagekit/auth",
};

// Helper function to generate optimized image URLs
export function getOptimizedImageUrl(
  src: string,
  options?: {
    width?: number;
    height?: number;
    quality?: number;
    format?: "jpg" | "png" | "webp" | "avif";
    crop?: "maintain_ratio" | "force" | "at_least" | "at_max";
  }
): string {
  // Return original URL if ImageKit is not configured or not an ImageKit URL
  if (
    !imagekitConfig.urlEndpoint ||
    !src.startsWith(imagekitConfig.urlEndpoint)
  ) {
    return src;
  }

  const params = new URLSearchParams();

  if (options?.width) params.append("w", options.width.toString());
  if (options?.height) params.append("h", options.height.toString());
  if (options?.quality) params.append("q", options.quality.toString());
  if (options?.format) params.append("f", options.format);
  if (options?.crop) params.append("c", options.crop);

  const transformations = params.toString();

  if (transformations) {
    const separator = src.includes("?") ? "&" : "?";
    return `${src}${separator}tr=${transformations}`;
  }

  return src;
}

// Helper function to validate image file
export function validateImageFile(file: File): {
  valid: boolean;
  error?: string;
} {
  // Check file type
  if (!file.type.startsWith("image/")) {
    return {
      valid: false,
      error: "Please select an image file (JPG, PNG, WebP)",
    };
  }

  // Check file size (500KB limit)
  const maxSize = 500 * 1024; // 500KB in bytes
  if (file.size > maxSize) {
    return { valid: false, error: "Image must be smaller than 500KB" };
  }

  // Check for supported formats
  const supportedTypes = [
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/webp",
    "image/gif",
  ];

  if (!supportedTypes.includes(file.type)) {
    return { valid: false, error: "Supported formats: JPG, PNG, WebP, GIF" };
  }

  return { valid: true };
}

// Types for ImageKit upload response
export interface ImageKitUploadResponse {
  fileId: string;
  name: string;
  size: number;
  filePath: string;
  url: string;
  fileType: string;
  height: number;
  width: number;
  thumbnailUrl: string;
  AITags?: Array<{ name: string; confidence: number }>;
}
