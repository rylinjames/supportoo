"use client";

import { ConvexProvider, ConvexReactClient } from "convex/react";
import { ThemeProvider } from "@/components/theme-provider";
import { WhopPaymentsProvider } from "./providers/whop-payments-provider";
import { WhopIframeSdkProvider } from "@whop/react";

const convex = new ConvexReactClient(process.env.NEXT_PUBLIC_CONVEX_URL!);

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ConvexProvider client={convex}>
      <ThemeProvider
        attribute="class"
        defaultTheme="system"
        enableSystem
        disableTransitionOnChange
      >
        <WhopIframeSdkProvider>
          <WhopPaymentsProvider>{children}</WhopPaymentsProvider>
        </WhopIframeSdkProvider>
      </ThemeProvider>
    </ConvexProvider>
  );
}
