import { headers } from "next/headers";
import LoadingScreen from "@/app/components/shared/loading-screen";
import {
  verifyUserToken,
  getUserInfo,
  getExperienceInfo,
  getUserCompanyAccess,
} from "@/whop/server/sdk";
import ExploreClient from "./explore-client";

export const dynamic = "force-dynamic";

export default async function ExplorePage({
  params,
}: {
  params: Promise<{ experienceId: string }>;
}) {
  const { experienceId } = await params;
  const headersList = await headers();
  const userToken = headersList.get("x-whop-user-token");

  if (!userToken) {
    return (
      <div className="min-h-screen w-full">
        <LoadingScreen
          message="Please open this app from your Whop experience so we can verify your account."
          error={true}
        />
      </div>
    );
  }

  const verification = await verifyUserToken();
  if (verification.error || (verification.success && !verification.userId)) {
    return (
      <div className="min-h-screen w-full grid place-items-center">
        <LoadingScreen
          message="Could not verify your account. Please open this app from your Whop experience again."
          error={true}
        />
      </div>
    );
  }

  const whopUserId = verification.userId!;
  const userInfo = await getUserInfo(whopUserId);
  if (!userInfo.success || !userInfo.user) {
    return (
      <div className="min-h-screen w-full">
        <LoadingScreen
          message="Could not fetch your user information. Please try again."
          error={true}
        />
      </div>
    );
  }

  const experienceInfo = await getExperienceInfo(experienceId);
  if (!experienceInfo.success || !experienceInfo.experience) {
    return (
      <div className="min-h-screen w-full">
        <LoadingScreen
          message="Could not fetch experience information. Please check configuration."
          error={true}
        />
      </div>
    );
  }

  const whopCompanyId = experienceInfo.experience.company.id;
  const companyName = experienceInfo.experience.company.title;
  const access = await getUserCompanyAccess(whopUserId, whopCompanyId);
  const whopAccessLevel =
    access.success && access.access?.accessLevel
      ? access.access.accessLevel
      : null;

  // Render client shell; it will query discoverable lounges
  return (
    <ExploreClient
      experienceId={experienceId}
      whopUserId={whopUserId}
      whopUsername={userInfo.user.username}
      fullName={userInfo.user.name || ""}
      avatarUrl={userInfo.user.profilePicture?.sourceUrl || ""}
      whopCompanyId={whopCompanyId}
      companyName={companyName}
      whopAccessLevel={whopAccessLevel}
    />
  );
}
