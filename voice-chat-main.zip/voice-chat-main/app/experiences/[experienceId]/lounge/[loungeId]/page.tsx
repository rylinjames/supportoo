"use client";

import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useQuery, useAction } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { LiveKitRoom, AudioConference } from "@livekit/components-react";
import { LoungeRoom } from "@/app/components/lounge";
import { useSessionStore } from "@/stores/session-store";
import { useOnboardingStore } from "@/stores/onboarding-store";
import LoadingScreen from "@/app/components/shared/loading-screen";
import { MinutesExhaustedScreen } from "@/app/components/shared/minutes-exhausted-screen";
import { MinuteWarningSystem } from "@/app/components/lounge/minute-warning-system";

export default function WhopLoungePage() {
  const params = useParams();
  const experienceId = params.experienceId as string;
  const loungeId = params.loungeId as string;

  const [token, setToken] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Session validation
  const { session, isSessionValid, _hasHydrated } = useSessionStore();

  // Onboarding store cleanup
  const { resetStore } = useOnboardingStore();

  // LiveKit token generation - MUST be called before any conditional returns
  const generateToken = useAction(api.livekit.generateLiveKitToken);

  // Single unified query for all lounge data - MUST be called before any conditional returns
  const loungeData = useQuery(
    api.lounge.getLoungeData,
    session &&
      isSessionValid() &&
      loungeId &&
      session.convexUserId &&
      session.convexCompanyId
      ? {
          roomId: loungeId as Id<"rooms">,
          userId: session.convexUserId,
          companyId: session.convexCompanyId,
        }
      : "skip"
  );

  useEffect(() => {
    const getToken = async () => {
      try {
        if (!loungeData?.user || !loungeData?.room) {
          return;
        }

        // Generate proper LiveKit token with user identity
        const tokenResult = await generateToken({
          roomName: loungeId,
          participantName: loungeData.user.fullName,
          userId: session?.whopUserId as string, // This will be the LiveKit participant identity
          userRole: loungeData.computed.userRole, // Pass user's role for permissions
          companyId: session?.convexCompanyId as Id<"companies">,
          roomId: loungeId,
        });

        setToken(tokenResult.token);
      } catch (err) {
        console.error("❌ Failed to generate LiveKit token:", err);
        setError("Failed to get room token");
      }
    };

    if (loungeId && loungeData?.user && loungeData?.room) {
      getToken();
    }
  }, [loungeId, loungeData, session?.whopUserId, generateToken]);

  // Clean up onboarding store once user successfully enters lounge
  useEffect(() => {
    if (loungeData?.room && loungeData?.user && token) {
      resetStore();
    }
  }, [loungeData?.room, loungeData?.user, token, resetStore]);

  // Handle hydrating state - show loading until localStorage is read
  if (!_hasHydrated) {
    return <LoadingScreen />;
  }

  // Early session validation
  if (!isSessionValid()) {
    return (
      <LoadingScreen
        message="Your session has expired. Please reload to sync your account again or go back to browse."
        error={true}
      />
    );
  }

  // Handle errors
  if (error) {
    return <LoadingScreen message={error} error={true} />;
  }

  // Handle room access validation
  if (loungeData && loungeData.room && !loungeData.computed.canJoin) {
    return (
      <LoadingScreen
        message="This lounge is not currently active. Please come back later."
        error={true}
      />
    );
  }

  // Handle room not found
  if (loungeData && !loungeData.room) {
    return <LoadingScreen message="Lounge not found." error={true} />;
  }

  // Handle room shutdown due to minute exhaustion
  if (loungeData?.room?.shutdownReason === "minutes_exhausted") {
    return (
      <MinutesExhaustedScreen
        isAdmin={session?.whopAccessLevel === "admin"}
        experienceId={experienceId}
        companyName={loungeData.company?.name}
      />
    );
  }

  // Loading state
  if (
    !token ||
    !loungeData?.room ||
    !loungeData?.user ||
    !loungeData?.company
  ) {
    return <LoadingScreen />;
  }

  return (
    <LiveKitRoom
      token={token}
      serverUrl={process.env.NEXT_PUBLIC_LIVEKIT_URL || ""}
      connect={true}
      video={false}
      audio={true}
    >
      <div className="h-screen">
        <LoungeRoom
          roomId={loungeId}
          companyName={loungeData.company.name}
          roomCreatorId={loungeData.room.creatorId}
          whopUserData={{ ...loungeData.user, _id: loungeData.user.id }}
          experienceId={experienceId}
          whopCompanyId={session?.whopCompanyId}
        />
        {/* Admin-only minute warning system */}
        <MinuteWarningSystem
          roomId={loungeId}
          isAdmin={session?.whopAccessLevel === "admin"}
          experienceId={experienceId}
        />
        {/* Hidden audio conference for LiveKit audio handling */}
        <div className="hidden">
          <AudioConference />
        </div>
      </div>
    </LiveKitRoom>
  );
}
