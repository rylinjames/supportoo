"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Info } from "lucide-react";

interface DowngradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentPlanName: string;
  targetPlanName: string;
  onConfirm: () => void;
}

export default function DowngradeModal({
  open,
  onOpenChange,
  currentPlanName,
  targetPlanName,
  onConfirm,
}: DowngradeModalProps) {
  const handleConfirm = () => {
    onConfirm();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-background border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white max-w-md max-h-[85vh] overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className="w-6 h-6 text-yellow-600 dark:text-yellow-500" />
            <DialogTitle className="text-xl font-semibold text-neutral-900 dark:text-white">
              Downgrade to {targetPlanName}
            </DialogTitle>
          </div>
          <DialogDescription className="text-neutral-600 dark:text-neutral-400">
            Cancel your subscription and downgrade to the free plan.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 overflow-y-auto flex-1">
          {/* Current Plan Info */}
          <div className="p-3 bg-neutral-100 dark:bg-neutral-800/50 rounded-lg border border-neutral-300 dark:border-neutral-700">
            <div className="flex items-center gap-2 mb-2">
              <Info className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <p className="text-sm font-medium text-neutral-900 dark:text-white">
                Current Plan
              </p>
            </div>
            <p className="text-sm text-neutral-700 dark:text-neutral-300">
              {currentPlanName}
            </p>
          </div>

          {/* Info Section */}
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-700/50">
            <div className="space-y-2">
              <p className="text-sm font-medium text-blue-900 dark:text-blue-200">
                What happens when you cancel:
              </p>
              <ul className="text-sm text-blue-800 dark:text-blue-100 space-y-1 list-disc list-inside">
                <li>
                  Your subscription will be cancelled at the end of your current
                  billing period
                </li>
                <li>
                  You'll keep access to {currentPlanName} features until then
                </li>
                <li>
                  You'll be automatically downgraded to {targetPlanName} when
                  the period ends
                </li>
                <li>You can resubscribe at any time</li>
              </ul>
            </div>
          </div>
        </div>

        <DialogFooter className="flex flex-col gap-3 sm:flex-row">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="w-full sm:w-auto"
          >
            Cancel
          </Button>
          <Button onClick={handleConfirm} className="w-full sm:w-auto">
            Confirm Cancellation
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
