import { NextRequest, NextResponse } from "next/server";
import { imagekit } from "@/lib/imagekit-server";

export async function GET(request: NextRequest) {
  try {
    // Generate authentication parameters for client-side upload
    const authenticationParameters = imagekit.getAuthenticationParameters();

    return NextResponse.json(authenticationParameters);
  } catch (error) {
    console.error("ImageKit auth error:", error);
    return NextResponse.json(
      { error: "Failed to generate authentication parameters" },
      { status: 500 }
    );
  }
}
