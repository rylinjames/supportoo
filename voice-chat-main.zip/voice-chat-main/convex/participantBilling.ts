import { v } from "convex/values";
import { mutation } from "./_generated/server";
import { Id } from "./_generated/dataModel";
import { api } from "./_generated/api";

/**
 * Participant-Level Real-Time Billing System
 *
 * This replaces the broken "on-leave" billing with real-time per-minute charging.
 * Each participant gets their own independent billing timer that charges every 60 seconds.
 *
 * Key Benefits:
 * - Scales to unlimited concurrent participants
 * - No more "infinite session" exploit
 * - Precise billing regardless of session length
 * - Automatic cleanup when participants leave
 */

// Charge a single participant one minute and schedule next billing cycle
export const chargeParticipantMinute = mutation({
  args: {
    participantId: v.id("participants"),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db.get(args.participantId);

    // Safety checks: participant might have left or been deleted
    if (!participant || participant.leftAt) {
      console.log(
        `⏹️ Billing stopped: participant ${args.participantId} has left`
      );
      return { success: false, reason: "participant_left" };
    }

    // Get room to find company
    const room = await ctx.db.get(participant.roomId);
    if (!room || !room.isActive) {
      console.log(`⏹️ Billing stopped: room ${participant.roomId} is inactive`);
      return { success: false, reason: "room_inactive" };
    }

    try {
      // Atomically charge 1 minute to the company (prevents race conditions)
      const billingResult = await ctx.runMutation(
        api.atomicBilling.atomicIncrementCompanyMinutes,
        {
          companyId: room.companyId,
          deltaMinutes: 1,
          participantId: args.participantId,
        }
      );

      // Get updated usage summary after atomic charge
      const summary = await ctx.runQuery(
        api.atomicBilling.getCompanyUsageAtomic,
        {
          companyId: room.companyId,
        }
      );
      const available: number = summary.available || 0;

      if (available <= 0) {
        console.log(
          `🚨 MINUTES EXHAUSTED: Room ${room._id} will be shutdown - company ${room.companyId} has 0 minutes remaining`
        );

        // Trigger room shutdown workflow
        await ctx.runMutation(api.rooms.shutdownRoomForMinutes, {
          roomId: room._id,
          reason: "minutes_exhausted",
        });

        return {
          success: false,
          reason: "minutes_exhausted",
          minutesCharged: 1,
        };
      }

      // Check for warning thresholds (10, 5, 1 minute)
      let warningLevel: "10_minutes" | "5_minutes" | "1_minute" | null = null;
      if (available <= 1) {
        warningLevel = "1_minute";
      } else if (available <= 5) {
        warningLevel = "5_minutes";
      } else if (available <= 10) {
        warningLevel = "10_minutes";
      }

      // Update participant's last billed timestamp
      await ctx.db.patch(args.participantId, {
        lastBilledAt: Date.now(),
      });

      console.log(
        `💰 Charged 1 minute: participant ${args.participantId}, company ${room.companyId}, ${available} minutes remaining`
      );

      // Log warning if threshold reached and emit warning event
      if (warningLevel) {
        console.log(
          `⚠️  WARNING: Company ${room.companyId} has reached ${warningLevel} threshold (${available} minutes remaining)`
        );

        // Emit warning event for real-time frontend detection
        const { createLoungeEvent, EVENT_TYPES } = await import("./events");
        await createLoungeEvent(ctx, {
          roomId: room._id,
          eventType: EVENT_TYPES.MINUTE_WARNING,
          eventData: {
            warningLevel,
            minutesRemaining: available,
          },
        });
      }

      // Schedule next billing cycle in 60 seconds
      await ctx.scheduler.runAfter(
        60000, // 60 seconds
        api.participantBilling.chargeParticipantMinute,
        { participantId: args.participantId }
      );

      return {
        success: true,
        minutesCharged: 1,
        warningLevel,
        minutesRemaining: available,
      };
    } catch (error) {
      console.error(
        `❌ Billing error for participant ${args.participantId}:`,
        error
      );
      return { success: false, reason: "billing_error", error: String(error) };
    }
  },
});

// Start billing for a new participant
export const startParticipantBilling = mutation({
  args: {
    participantId: v.id("participants"),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db.get(args.participantId);
    if (!participant) {
      throw new Error("Participant not found");
    }

    // Initialize billing timestamps
    await ctx.db.patch(args.participantId, {
      billingStartedAt: Date.now(),
      lastBilledAt: Date.now(),
    });

    // Schedule first billing cycle in 60 seconds
    await ctx.scheduler.runAfter(
      60000, // 60 seconds
      api.participantBilling.chargeParticipantMinute,
      { participantId: args.participantId }
    );

    console.log(
      `⏰ Started billing timer for participant ${args.participantId}`
    );
    return { success: true, billingStarted: true };
  },
});

// Stop billing for a participant and charge final partial minute
export const stopParticipantBilling = mutation({
  args: {
    participantId: v.id("participants"),
  },
  handler: async (ctx, args) => {
    const participant = await ctx.db.get(args.participantId);
    if (!participant) {
      console.log(
        `⚠️ Cannot stop billing: participant ${args.participantId} not found`
      );
      return { success: false, reason: "participant_not_found" };
    }

    const room = await ctx.db.get(participant.roomId);
    if (!room) {
      console.log(
        `⚠️ Cannot stop billing: room ${participant.roomId} not found`
      );
      return { success: false, reason: "room_not_found" };
    }

    try {
      // Calculate final partial minute charge
      const joinedAt = participant.joinedAt || Date.now();
      const leftAt = Date.now();
      const sessionDurationMs = leftAt - joinedAt;
      const sessionMinutes = Math.ceil(sessionDurationMs / 60000); // Always round up

      // Calculate how many minutes were already charged via timers
      const billingStartedAt = participant.billingStartedAt || joinedAt;
      const billingDurationMs = leftAt - billingStartedAt;
      const estimatedChargedMinutes = Math.floor(billingDurationMs / 60000);

      // Calculate final charge (ensure we charge at least 1 minute total)
      const finalChargeMinutes = Math.max(
        1,
        sessionMinutes - estimatedChargedMinutes
      );

      if (finalChargeMinutes > 0) {
        // Use atomic billing for final charge to prevent race conditions
        await ctx.runMutation(api.atomicBilling.atomicIncrementCompanyMinutes, {
          companyId: room.companyId,
          deltaMinutes: finalChargeMinutes,
          participantId: args.participantId,
        });
        console.log(
          `💰 Final charge: ${finalChargeMinutes} minutes for participant ${args.participantId}`
        );
      }

      // Mark billing as stopped
      await ctx.db.patch(args.participantId, {
        billingStoppedAt: leftAt,
        finalChargeMinutes: finalChargeMinutes,
      });

      console.log(`⏹️ Stopped billing for participant ${args.participantId}`);
      return {
        success: true,
        finalChargeMinutes,
        totalSessionMinutes: sessionMinutes,
      };
    } catch (error) {
      console.error(
        `❌ Error stopping billing for participant ${args.participantId}:`,
        error
      );
      return { success: false, reason: "billing_error", error: String(error) };
    }
  },
});

// Helper function to charge company minutes (reuses existing logic)
async function chargeCompanyMinute(
  ctx: { db: any; runQuery: any },
  companyId: Id<"companies">,
  minutes: number = 1
): Promise<void> {
  const company = await ctx.db.get(companyId);
  const usedBefore = company?.minutesUsedThisMonth || 0;

  // Get plan settings to determine included minutes
  const settings = await ctx.runQuery(api.plans.getCompanyPlanSettings, {
    companyId,
  });
  const included = settings.effectiveIncludedMinutes || 0;

  // Update company usage counter
  const newUsage = usedBefore + minutes;
  await ctx.db.patch(companyId, {
    minutesUsedThisMonth: newUsage,
    updatedAt: Date.now(),
  });

  // Charge credits only for overage (beyond included minutes)
  const overageBefore = Math.max(0, usedBefore - included);
  const overageAfter = Math.max(0, newUsage - included);
  const creditsToCharge = Math.max(0, overageAfter - overageBefore);

  if (creditsToCharge > 0) {
    await consumeCreditsFifo(ctx, companyId, creditsToCharge);
  }

  console.log(
    `📊 Company ${companyId}: used ${newUsage}/${included} included, charged ${creditsToCharge} credits`
  );
}

// FIFO credit consumption (copied from existing webhooks.ts logic)
async function consumeCreditsFifo(
  ctx: { db: any },
  companyId: Id<"companies">,
  debitMinutes: number
): Promise<number> {
  if (debitMinutes <= 0) return 0;

  const credits = await ctx.db
    .query("companyMinuteCredits")
    .withIndex("by_company", (q: any) => q.eq("companyId", companyId))
    .collect();

  // Sort: earliest expiresAt first (nulls last), then purchasedAt ascending
  credits.sort((a: any, b: any) => {
    const ea = a.expiresAt ?? Number.POSITIVE_INFINITY;
    const eb = b.expiresAt ?? Number.POSITIVE_INFINITY;
    if (ea !== eb) return ea - eb;
    return (a.purchasedAt || 0) - (b.purchasedAt || 0);
  });

  let remaining = debitMinutes;
  for (const credit of credits) {
    if (remaining <= 0) break;
    const available = Math.max(0, credit.remainingMinutes || 0);
    const take = Math.min(remaining, available);
    if (take > 0) {
      await ctx.db.patch(credit._id, {
        remainingMinutes: available - take,
      });
      remaining -= take;
    }
  }

  return debitMinutes - remaining; // Actually consumed
}
