"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useAction } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { ConvexParticipant } from "@/types/participants";
import {
  useLocalParticipant,
  useParticipants,
  useRoomContext,
} from "@livekit/components-react";
import {
  RoomEvent,
  Track,
  RemoteTrack,
  RemoteTrackPublication,
  RemoteParticipant,
} from "livekit-client";
import { motion } from "motion/react";
import { Crown, Mic, Users } from "lucide-react";
import { LoungeHeader } from "./lounge-header";
import { LoungeSidebar } from "./lounge-sidebar";
import { LoungeControls } from "./lounge-controls";
import MobileLoungeSidebar from "./mobile/mobile-lounge-sidebar";
import { ParticipantSection } from "./participant-section";
import { Participant } from "./types";
import MobileLiveFeedAndChatSection from "./mobile/mobile-live-feed-and-chat-section";
import { PrivateParticipantSection } from "./private-participant-section";
import { useSessionStore } from "@/stores/session-store";
import { useScreenShare } from "@/app/hooks/useScreenShare";
import { ScreenShareViewer } from "./ScreenShareViewer";
import { toast } from "sonner";

interface LoungeRoomProps {
  roomId: string;
  companyName: string;
  roomCreatorId?: string;
  experienceId: string;
  whopCompanyId?: string;
  whopUserData: {
    _id: string;
    whopUserId: string;
    whopUsername: string;
    fullName: string;
    isAnonymous?: boolean;
  };
}

export default function LoungeRoom({
  roomId,
  companyName,
  roomCreatorId,
  experienceId,
  whopCompanyId,
  whopUserData,
}: LoungeRoomProps) {
  const router = useRouter();
  const { localParticipant } = useLocalParticipant();
  const livekitParticipants = useParticipants();
  const room = useRoomContext();

  // Convex mutations
  const leaveRoomMutation = useMutation(api.participants.leaveRoom);
  const deleteRoomMutation = useMutation(api.rooms.deactivateRoom);
  const updateParticipantRole = useMutation(
    api.participants.updateParticipantRole
  );
  const authorizeAndSetRole = useAction(api.participants.authorizeAndSetRole);
  const authorizeKickAction = useAction(api.participants.authorizeAndKick);
  const banUserMutation = useMutation(api.rooms.banUserFromRoom);
  const cleanupReactionsMutation = useMutation(
    api.reactions.cleanupExpiredReactionsForRoom
  );
  const addReactionMutation = useMutation(api.reactions.addReaction);
  const removeFromLiveKit = useAction(api.livekit.removeParticipantFromLiveKit);

  // Mute actions
  const muteParticipantAction = useAction(api.participantMute.muteParticipant);
  const unmuteParticipantAction = useAction(
    api.participantMute.unmuteParticipant
  );
  const muteAllSpeakersAction = useAction(api.participantMute.muteAllSpeakers);

  // Apply output device preference to newly attached audio tracks
  useEffect(() => {
    if (!livekitParticipants.length) return;

    // Get the room from the first participant (they all share the same room)
    const firstParticipant = livekitParticipants[0];
    if (!firstParticipant || !("room" in firstParticipant)) return;

    const room = (firstParticipant as any).room;
    if (!room) return;

    const handleTrackSubscribed = (
      track: RemoteTrack,
      publication: RemoteTrackPublication,
      participant: RemoteParticipant
    ) => {
      if (track.kind === Track.Kind.Audio) {
        // Small delay to ensure the element is properly attached
        setTimeout(() => {
          const element = track.attach();
          // Apply current output device preference
          const savedOutputDevice = localStorage.getItem(
            "selectedOutputDevice"
          );
          if (savedOutputDevice && "setSinkId" in element) {
            (element as any)
              .setSinkId(savedOutputDevice)
              .catch((error: any) => {
                console.error(
                  "Failed to apply output device to new track:",
                  error
                );
              });
          }
        }, 100);
      }
    };

    // Listen for track subscriptions
    room.on(RoomEvent.TrackSubscribed, handleTrackSubscribed);

    return () => {
      room.off(RoomEvent.TrackSubscribed, handleTrackSubscribed);
    };
  }, [livekitParticipants]);

  // Convex queries
  const convexParticipants = useQuery(
    api.participants.getActiveRoomParticipants,
    { roomId: roomId as Id<"rooms"> }
  );

  // Get room details for settings
  const roomDetails = useQuery(api.rooms.getRoom, {
    roomId: roomId as Id<"rooms">,
  });

  // Get real-time reactions for this room
  const roomReactions = useQuery(api.reactions.getRoomReactions, {
    roomId: roomId as Id<"rooms">,
  });

  // State
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isConnected, setIsConnected] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(true);
  const [showAllListeners, setShowAllListeners] = useState(false);
  const INITIAL_LISTENERS_COUNT = 12;
  const [wasInRoom, setWasInRoom] = useState(false);
  const [isKicked, setIsKicked] = useState(false);
  const [screenSize, setScreenSize] = useState<number | undefined>(undefined);
  const [isReactionOpen, setIsReactionOpen] = useState(false);
  const [showResetConfirmation, setShowResetConfirmation] = useState(false);
  const { session } = useSessionStore();

  // Track screen size changes
  useEffect(() => {
    const handleResize = () => {
      setScreenSize(window.innerWidth);
    };

    // Set initial size
    handleResize();

    // Add event listener
    window.addEventListener("resize", handleResize);

    // Cleanup
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const currentUserRole =
    convexParticipants?.find(
      (p: ConvexParticipant) => p.user?.whopUserId === whopUserData.whopUserId
    )?.role || "listener";

  // Screen Share Integration
  const canScreenShare = currentUserRole === "moderator";
  const {
    isSharing,
    isLoading: screenShareLoading,
    error: screenShareError,
    screenShareState,
    startScreenShare,
    stopScreenShare,
    takeoverScreenShare,
  } = useScreenShare({
    room,
    roomId: roomId as Id<"rooms">,
    userId: whopUserData._id as Id<"users">,
    canScreenShare,
  });

  // Only creator or whop admin (session) can manage moderators; for now base on creator
  const canManageModerators =
    whopUserData._id === roomCreatorId ||
    (session?.whopAccessLevel === "admin" &&
      roomDetails?.companyId === session?.convexCompanyId);

  // Periodic cleanup of expired reactions (moderator is cleanup leader)
  useEffect(() => {
    const isCleanupLeader = currentUserRole === "moderator";

    if (!isCleanupLeader) return;
    const cleanupInterval = setInterval(() => {
      cleanupReactionsMutation({ roomId: roomId as Id<"rooms"> });
    }, 5000);

    return () => clearInterval(cleanupInterval);
  }, [
    roomId,
    cleanupReactionsMutation,
    currentUserRole,
    whopUserData.whopUserId,
  ]);

  // Check if user was kicked
  useEffect(() => {
    if (convexParticipants && wasInRoom) {
      const isStillInRoom = convexParticipants.some(
        (p: ConvexParticipant) => p.user?.whopUserId === whopUserData.whopUserId
      );
      if (!isStillInRoom && !isKicked) {
        setIsKicked(true);
        router.push(`/experiences/${experienceId}/browse`);
      }
    }
  }, [
    convexParticipants,
    wasInRoom,
    whopUserData.whopUserId,
    isKicked,
    router,
  ]);

  // Set wasInRoom when participants load
  useEffect(() => {
    if (convexParticipants && !wasInRoom) {
      const isInRoom = convexParticipants.some(
        (p: ConvexParticipant) => p.user?.whopUserId === whopUserData.whopUserId
      );
      if (isInRoom) {
        setWasInRoom(true);
      }
    }
  }, [convexParticipants, wasInRoom, whopUserData.whopUserId]);

  // Get current user's participant data to monitor role changes
  const currentUserParticipant = convexParticipants?.find(
    (p: ConvexParticipant) => p.user?.whopUserId === whopUserData.whopUserId
  );

  // Monitor role changes to ensure listeners are muted
  useEffect(() => {
    if (currentUserParticipant) {
      const currentRole = currentUserParticipant.role;

      // Ensure listeners are muted
      if (currentRole === "listener" && localParticipant && !isMuted) {
        localParticipant.setMicrophoneEnabled(false);
        setIsMuted(true);
      }
    }
  }, [currentUserParticipant?.role, localParticipant, isMuted]);

  // Map LiveKit participants to UI format
  const mapLiveKitParticipants = (): Participant[] => {
    if (!livekitParticipants || !convexParticipants) {
      return [];
    }

    return livekitParticipants
      .map((participant) => {
        // Find corresponding Convex participant data
        const convexParticipant = convexParticipants.find(
          (p: ConvexParticipant) => p.user?.whopUserId === participant.identity
        );

        if (!convexParticipant) {
          return {
            id: participant.identity,
            whopUserId: participant.identity,
            convexUserId: "", // No Convex user ID for disconnected users
            name: participant.identity,
            avatar: "/placeholder.svg?height=60&width=60",
            role: "listener" as const,
            isMuted: !participant.isMicrophoneEnabled,
            isSpeaking: participant.isSpeaking,
            isDisconnected: true,
          };
        }

        return {
          id: participant.identity,
          whopUserId:
            convexParticipant.user?.whopUserId || participant.identity,
          convexUserId: convexParticipant.user?._id || "", // Add Convex user ID
          name: convexParticipant?.user?.fullName || participant.identity,
          avatar:
            convexParticipant?.user?.avatarUrl ||
            "/placeholder.svg?height=60&width=60",
          role:
            (convexParticipant?.role as "moderator" | "speaker" | "listener") ||
            "listener",
          isMuted: !participant.isMicrophoneEnabled,
          isSpeaking: participant.isSpeaking,
          isDisconnected: false,
          isAnonymous: convexParticipant?.user?.isAnonymous || false,
        };
      })
      .filter((participant) => !participant.isDisconnected);
  };

  // Use real participant data when available, fallback to mock
  const participants = mapLiveKitParticipants();

  // Filter participants by role for separate sections
  const moderators = participants.filter((p) => p.role === "moderator");
  const speakers = participants.filter((p) => p.role === "speaker");
  const listeners = participants.filter((p) => p.role === "listener");

  // Determine actual publish permission from LiveKit local participant
  const canPublishAudio =
    (localParticipant as any)?.permissions?.canPublish ?? undefined;

  // Audio control functions
  const toggleMute = async () => {
    // Prevent listeners from unmuting
    if (currentUserRole === "listener" || !canPublishAudio) {
      return;
    }

    if (localParticipant) {
      try {
        if (isMuted) {
          // Request microphone permissions first
          await navigator.mediaDevices.getUserMedia({ audio: true });
          await localParticipant.setMicrophoneEnabled(true);
        } else {
          await localParticipant.setMicrophoneEnabled(false);
        }
        setIsMuted(!isMuted);
      } catch (error) {
        console.error("Error toggling mute:", error);
      }
    }
  };

  const toggleVolume = async () => {
    setVolume(!volume);
    // Toggle all audio elements
    const audioElements = document.querySelectorAll("audio");
    audioElements.forEach((audio) => {
      audio.volume = volume ? 0 : 1;
    });
  };

  // Participant management functions
  const addToSpeakers = async (participantId: string) => {
    try {
      // Find the participant in Convex data using whopUserId
      const convexParticipant = convexParticipants?.find(
        (p: ConvexParticipant) => p.user?.whopUserId === participantId
      );

      if (convexParticipant) {
        await authorizeAndSetRole({
          roomId: roomId as any,
          targetUserId: convexParticipant.userId,
          requestedRole: "speaker",
          requesterId: whopUserData._id as any,
          requesterCompanyId: (roomDetails?.companyId ||
            session?.convexCompanyId) as any,
          isWhopAdmin: session?.whopAccessLevel === "admin",
        });
      }
    } catch (error) {
      console.error("Error adding to speakers:", error);
    }
  };

  const removeFromSpeakers = async (participantId: string) => {
    try {
      // Find the participant in Convex data using whopUserId
      const convexParticipant = convexParticipants?.find(
        (p: ConvexParticipant) => p.user?.whopUserId === participantId
      );

      if (convexParticipant) {
        await authorizeAndSetRole({
          roomId: roomId as any,
          targetUserId: convexParticipant.userId,
          requestedRole: "listener",
          requesterId: whopUserData._id as any,
          requesterCompanyId: (roomDetails?.companyId ||
            session?.convexCompanyId) as any,
          isWhopAdmin: session?.whopAccessLevel === "admin",
        });
      }
    } catch (error) {
      console.error("Error removing from speakers:", error);
    }
  };

  const kickFromLounge = async (participantId: string) => {
    try {
      // Find the participant in Convex data using whopUserId
      const convexParticipant = convexParticipants?.find(
        (p: ConvexParticipant) => p.user?.whopUserId === participantId
      );

      if (convexParticipant) {
        await authorizeKickAction({
          roomId: roomId as any,
          targetUserId: convexParticipant.userId,
          requesterId: whopUserData._id as any,
          requesterCompanyId: (roomDetails?.companyId ||
            session?.convexCompanyId) as any,
        });

        // If it's the current user being kicked, redirect them
        if (participantId === whopUserData.whopUserId) {
          setIsKicked(true);
          router.push(`/experiences/${experienceId}/browse`);
        }
      }
    } catch (error) {
      console.error("Error kicking user:", error);
    }
  };

  const promoteToModerator = async (participantId: string) => {
    try {
      const convexParticipant = convexParticipants?.find(
        (p: ConvexParticipant) => p.user?.whopUserId === participantId
      );
      if (convexParticipant) {
        await authorizeAndSetRole({
          roomId: roomId as any,
          targetUserId: convexParticipant.userId,
          requestedRole: "moderator",
          requesterId: whopUserData._id as any,
          requesterCompanyId: (roomDetails?.companyId ||
            session?.convexCompanyId) as any,
          isWhopAdmin: session?.whopAccessLevel === "admin",
        });
      }
    } catch (error) {
      console.error("Error promoting to moderator:", error);
    }
  };

  const demoteModeratorToSpeaker = async (participantId: string) => {
    try {
      const convexParticipant = convexParticipants?.find(
        (p: ConvexParticipant) => p.user?.whopUserId === participantId
      );
      if (convexParticipant) {
        await authorizeAndSetRole({
          roomId: roomId as any,
          targetUserId: convexParticipant.userId,
          requestedRole: "speaker",
          requesterId: whopUserData._id as any,
          requesterCompanyId: (roomDetails?.companyId ||
            session?.convexCompanyId) as any,
          isWhopAdmin: session?.whopAccessLevel === "admin",
        });
      }
    } catch (error) {
      console.error("Error demoting moderator to speaker:", error);
    }
  };

  // Mute participant functions
  const muteParticipant = async (participantId: string) => {
    try {
      const convexParticipant = convexParticipants?.find(
        (p: ConvexParticipant) => p.user?.whopUserId === participantId
      );

      if (convexParticipant) {
        const result = await muteParticipantAction({
          roomId: roomId as any,
          targetUserId: convexParticipant.userId,
          requesterId: whopUserData._id as any,
          requesterCompanyId: (roomDetails?.companyId ||
            session?.convexCompanyId) as any,
          isWhopAdmin: session?.whopAccessLevel === "admin",
        });

        if (result.success) {
          toast.success(`Muted ${result.participantName}`);
        }
      }
    } catch (error) {
      console.error("Error muting participant:", error);
      toast.error("Failed to mute participant");
    }
  };

  const unmuteParticipant = async (participantId: string) => {
    try {
      const convexParticipant = convexParticipants?.find(
        (p: ConvexParticipant) => p.user?.whopUserId === participantId
      );

      if (convexParticipant) {
        const result = await unmuteParticipantAction({
          roomId: roomId as any,
          targetUserId: convexParticipant.userId,
          requesterId: whopUserData._id as any,
          requesterCompanyId: (roomDetails?.companyId ||
            session?.convexCompanyId) as any,
          isWhopAdmin: session?.whopAccessLevel === "admin",
        });

        if (result.success) {
          toast.success(`Unmuted ${result.participantName}`);
        }
      }
    } catch (error) {
      console.error("Error unmuting participant:", error);
      toast.error("Failed to unmute participant");
    }
  };

  const muteAllSpeakers = async () => {
    try {
      const result = await muteAllSpeakersAction({
        roomId: roomId as any,
        requesterId: whopUserData._id as any,
        requesterCompanyId: (roomDetails?.companyId ||
          session?.convexCompanyId) as any,
        isWhopAdmin: session?.whopAccessLevel === "admin",
      });

      if (result.success) {
        if (result.mutedCount === 0) {
          toast.info("No speakers to mute");
        } else {
          toast.success(`Muted ${result.mutedCount} speakers`);
        }
      }
    } catch (error) {
      console.error("Error muting all speakers:", error);
      toast.error("Failed to mute speakers");
    }
  };

  const unmuteAllSpeakers = async () => {
    try {
      // For unmute all, we need to call unmute for each speaker individually
      // since we don't have a bulk unmute action yet
      const speakers = participants.filter(
        (p) => p.role === "speaker" && p.isMuted
      );
      let unmutedCount = 0;

      for (const speaker of speakers) {
        try {
          await unmuteParticipant(speaker.id);
          unmutedCount++;
        } catch (error) {
          console.error(`Failed to unmute ${speaker.name}:`, error);
        }
      }

      if (unmutedCount > 0) {
        toast.success(`Unmuted ${unmutedCount} speakers`);
      } else {
        toast.info("No muted speakers to unmute");
      }
    } catch (error) {
      console.error("Error unmuting all speakers:", error);
      toast.error("Failed to unmute speakers");
    }
  };

  // Ban removed from UI for now; keep placeholder if needed in future

  const handleDisconnect = async () => {
    try {
      // Disconnect from LiveKit first to trigger webhooks reliably
      try {
        await room?.disconnect(true);
      } catch {}

      await leaveRoomMutation({
        roomId: roomId as any,
        userId: whopUserData._id as any,
      });
      setIsConnected(false);
    } catch (error) {
      console.error("Error leaving room:", error);
    }
  };

  // Redirect on LiveKit disconnect (do not wait for Convex)
  useEffect(() => {
    if (!room) return;
    const handleLKDisconnected = () => {
      setIsConnected(false);
      router.push(`/experiences/${experienceId}/browse`);
    };
    room.on(RoomEvent.Disconnected, handleLKDisconnected);
    return () => {
      room.off(RoomEvent.Disconnected, handleLKDisconnected);
    };
  }, [room, router, experienceId]);

  const endLounge = async () => {
    try {
      await deleteRoomMutation({ roomId: roomId as any });
      setIsConnected(false);
    } catch (error) {
      console.error("Error ending lounge:", error);
    }
  };

  // Reaction and request functions
  const handleReaction = async (emoji: string) => {
    try {
      await addReactionMutation({
        roomId: roomId as Id<"rooms">,
        userId: whopUserData._id as Id<"users">,
        emoji,
      });
      setIsReactionOpen(false);
    } catch (error) {
      console.error("Failed to add reaction:", error);
    }
  };

  const canRequestToSpeak = currentUserRole === "listener";

  const handleRequestToSpeak = async () => {
    try {
      await addReactionMutation({
        roomId: roomId as Id<"rooms">,
        userId: whopUserData._id as Id<"users">,
        emoji: "🤔",
      });
    } catch (error) {
      console.error("Failed to request to speak:", error);
    }
  };

  const openResetConfirmation = () => {
    setShowResetConfirmation(true);
  };

  // Handle kick redirect in useEffect to avoid setState during render
  useEffect(() => {
    if (isKicked || !isConnected) {
      router.push(`/experiences/${experienceId}/browse`);
    }
  }, [isKicked, router, experienceId]);

  // Handle maximize toggle for screen share
  // Determine if screen sharing layout should be active
  const isScreenShareLayoutActive = screenShareState?.isActive;

  return (
    <div className="min-h-screen bg-foreground flex">
      <motion.div
        className="xl:flex-1 max-xl:min-w-screen flex flex-col"
        animate={{
          marginRight: sidebarOpen ? 320 : 0,
        }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        {/* Header */}
        <LoungeHeader
          roomName={roomDetails?.name || `${companyName} Lounge`}
          participantCount={participants.length}
          onVolumeToggle={toggleVolume}
          volume={volume}
          onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
          sidebarOpen={sidebarOpen}
          experienceId={experienceId}
          roomId={roomId}
          whopUserData={whopUserData}
          currentUserRole={currentUserRole}
          roomDetails={{ ...roomDetails, whopCompanyId }}
          localParticipant={localParticipant}
          handleReaction={handleReaction}
          canRequestToSpeak={canRequestToSpeak}
          handleRequestToSpeak={handleRequestToSpeak}
          openResetConfirmation={openResetConfirmation}
          isReactionOpen={isReactionOpen}
          setIsReactionOpen={setIsReactionOpen}
          // @ts-ignore
          isPublic={roomDetails?.isPublic ?? true}
          // Screen share props for mobile sidebar in header
          canScreenShare={canScreenShare}
          isSharing={isSharing}
          screenShareLoading={screenShareLoading}
          screenShareActive={screenShareState?.isActive || false}
          screenShareError={screenShareError}
          participants={participants}
          onStartScreenShare={startScreenShare}
          onStopScreenShare={stopScreenShare}
          onTakeoverScreenShare={takeoverScreenShare}
          // Participant management functions
          onAddToSpeakers={addToSpeakers}
          onRemoveFromSpeakers={removeFromSpeakers}
          onKickFromLounge={kickFromLounge}
          onPromoteToModerator={promoteToModerator}
          onDemoteModeratorToSpeaker={demoteModeratorToSpeaker}
          canManageModerators={canManageModerators}
        />

        {/* Main Content - Conditional Layout */}
        {isScreenShareLayoutActive ? (
          /* Screen Share Layout - Full Height */
          <ScreenShareViewer className="flex-1" participants={participants} />
        ) : (
          /* Normal Layout */
          <div className="flex-1 max-md:p-4 max-xl:py-8 px-8 xl:p-6 overflow-y-auto relative">
            {/* Moderators */}
            {roomDetails?.isPublic ? (
              <>
                <ParticipantSection
                  title="Moderators"
                  icon={<Crown className="w-5 h-5 text-primary" />}
                  participants={moderators}
                  delay={0.1}
                  currentUserRole={currentUserRole}
                  currentUserId={whopUserData.whopUserId}
                  roomCreatorId={roomCreatorId}
                  roomId={roomId}
                  onAddToSpeakers={addToSpeakers}
                  onRemoveFromSpeakers={removeFromSpeakers}
                  onKickFromLounge={kickFromLounge}
                  onPromoteToModerator={promoteToModerator}
                  onDemoteModeratorToSpeaker={demoteModeratorToSpeaker}
                  canManageModerators={canManageModerators}
                  whopCompanyId={whopCompanyId}
                />

                {/* Speakers */}
                <ParticipantSection
                  title="Speakers"
                  icon={<Mic className="w-5 h-5 text-emerald-600" />}
                  participants={speakers}
                  delay={0.2}
                  currentUserRole={currentUserRole}
                  currentUserId={whopUserData.whopUserId}
                  roomCreatorId={roomCreatorId}
                  roomId={roomId}
                  onAddToSpeakers={addToSpeakers}
                  onRemoveFromSpeakers={removeFromSpeakers}
                  onKickFromLounge={kickFromLounge}
                  onPromoteToModerator={promoteToModerator}
                  onDemoteModeratorToSpeaker={demoteModeratorToSpeaker}
                  onMuteParticipant={muteParticipant}
                  onUnmuteParticipant={unmuteParticipant}
                  canManageModerators={canManageModerators}
                  whopCompanyId={whopCompanyId}
                />

                {/* Listeners */}
                <ParticipantSection
                  title="Listeners"
                  icon={<Users className="w-5 h-5 text-neutral-400" />}
                  participants={listeners}
                  showAllListeners={showAllListeners}
                  setShowAllListeners={setShowAllListeners}
                  initialCount={INITIAL_LISTENERS_COUNT}
                  delay={0.3}
                  currentUserRole={currentUserRole}
                  currentUserId={whopUserData.whopUserId}
                  roomCreatorId={roomCreatorId}
                  roomId={roomId}
                  onAddToSpeakers={addToSpeakers}
                  onRemoveFromSpeakers={removeFromSpeakers}
                  onKickFromLounge={kickFromLounge}
                  onPromoteToModerator={promoteToModerator}
                  onDemoteModeratorToSpeaker={demoteModeratorToSpeaker}
                  onMuteParticipant={muteParticipant}
                  onUnmuteParticipant={unmuteParticipant}
                  canManageModerators={canManageModerators}
                  whopCompanyId={whopCompanyId}
                />
              </>
            ) : (
              <PrivateParticipantSection
                participants={participants}
                roomId={roomId}
                roomCreatorId={roomCreatorId}
                currentUserRole={currentUserRole}
                currentUserId={whopUserData.whopUserId}
                onKickFromLounge={kickFromLounge}
              />
            )}
            <MobileLiveFeedAndChatSection roomId={roomId} />
          </div>
        )}

        {/* Controls */}

        <LoungeControls
          isMuted={isMuted}
          onToggleMute={toggleMute}
          onDisconnect={handleDisconnect}
          userRole={currentUserRole}
          isPublic={Boolean(roomDetails?.isPublic ?? true)}
          canPublishAudio={canPublishAudio}
        />
      </motion.div>
      {/* Sidebar - Works during screen share too */}
      {screenSize && screenSize > 1024 && (
        <LoungeSidebar
          sidebarOpen={sidebarOpen}
          whopUserData={whopUserData}
          currentUserRole={currentUserRole}
          experienceId={experienceId}
          roomId={roomId}
          roomDetails={roomDetails}
          localParticipant={localParticipant}
          isPublic={roomDetails?.isPublic ?? true}
          // Screen share props
          canScreenShare={canScreenShare}
          isSharing={isSharing}
          screenShareLoading={screenShareLoading}
          screenShareActive={screenShareState?.isActive || false}
          screenShareError={screenShareError}
          participantCount={participants.length}
          participants={participants}
          // Participant management functions
          onAddToSpeakers={addToSpeakers}
          onRemoveFromSpeakers={removeFromSpeakers}
          onKickFromLounge={kickFromLounge}
          onPromoteToModerator={promoteToModerator}
          onDemoteModeratorToSpeaker={demoteModeratorToSpeaker}
          onMuteAllSpeakers={muteAllSpeakers}
          onUnmuteAllSpeakers={unmuteAllSpeakers}
          canManageModerators={canManageModerators}
          onStartScreenShare={startScreenShare}
          onStopScreenShare={stopScreenShare}
          onTakeoverScreenShare={takeoverScreenShare}
        />
      )}
    </div>
  );
}
