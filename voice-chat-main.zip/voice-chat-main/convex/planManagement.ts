import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { Id } from "./_generated/dataModel";

// Get all active plans ordered by sort order
export const getActivePlans = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("plans")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .order("asc")
      .collect();
  },
});

// Get all active minute packs ordered by sort order
export const getActiveMinutePacks = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("minutePacks")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .order("asc")
      .collect();
  },
});

// Get plan by tier
export const getPlanByTier = query({
  args: {
    tier: v.union(
      v.literal("free"),
      v.literal("starter"),
      v.literal("pro"),
      v.literal("creator")
    ),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("plans")
      .withIndex("by_tier", (q) => q.eq("tier", args.tier))
      .filter((q) => q.eq(q.field("isActive"), true))
      .first();
  },
});

// Get minute pack by Whop plan ID
export const getMinutePackByWhopId = query({
  args: { whopPlanId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("minutePacks")
      .withIndex("by_whop_plan_id", (q) => q.eq("whopPlanId", args.whopPlanId))
      .filter((q) => q.eq(q.field("isActive"), true))
      .first();
  },
});

// Get plan by Whop plan ID
export const getPlanByWhopId = query({
  args: { whopPlanId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("plans")
      .withIndex("by_whop_plan_id", (q) => q.eq("whopPlanId", args.whopPlanId))
      .filter((q) => q.eq(q.field("isActive"), true))
      .first();
  },
});

// Admin: Create or update plan
export const upsertPlan = mutation({
  args: {
    tier: v.union(
      v.literal("free"),
      v.literal("starter"),
      v.literal("pro"),
      v.literal("creator")
    ),
    name: v.string(),
    description: v.string(),
    priceUsd: v.number(),
    includedMinutes: v.number(),
    maxSavedLounges: v.optional(v.number()),
    features: v.array(v.string()),
    whopPlanId: v.optional(v.string()),
    whopCheckoutUrl: v.optional(v.string()),
    sortOrder: v.number(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    // Check if plan already exists
    const existing = await ctx.db
      .query("plans")
      .withIndex("by_tier", (q) => q.eq("tier", args.tier))
      .first();

    if (existing) {
      // Update existing plan
      await ctx.db.patch(existing._id, {
        ...args,
        updatedAt: now,
      });
      return existing._id;
    } else {
      // Create new plan
      return await ctx.db.insert("plans", {
        ...args,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      });
    }
  },
});

// Admin: Create or update minute pack
export const upsertMinutePack = mutation({
  args: {
    name: v.string(),
    minutes: v.number(),
    priceUsd: v.number(),
    whopPlanId: v.string(),
    whopCheckoutUrl: v.string(),
    sortOrder: v.number(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    // Check if pack already exists
    const existing = await ctx.db
      .query("minutePacks")
      .withIndex("by_whop_plan_id", (q) => q.eq("whopPlanId", args.whopPlanId))
      .first();

    if (existing) {
      // Update existing pack
      await ctx.db.patch(existing._id, {
        ...args,
        updatedAt: now,
      });
      return existing._id;
    } else {
      // Create new pack
      return await ctx.db.insert("minutePacks", {
        ...args,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      });
    }
  },
});

// Admin: Toggle plan active status
export const togglePlanActive = mutation({
  args: { planId: v.id("plans") },
  handler: async (ctx, args) => {
    const plan = await ctx.db.get(args.planId);
    if (!plan) throw new Error("Plan not found");

    await ctx.db.patch(args.planId, {
      isActive: !plan.isActive,
      updatedAt: Date.now(),
    });

    return { isActive: !plan.isActive };
  },
});

// Admin: Toggle minute pack active status
export const toggleMinutePackActive = mutation({
  args: { packId: v.id("minutePacks") },
  handler: async (ctx, args) => {
    const pack = await ctx.db.get(args.packId);
    if (!pack) throw new Error("Minute pack not found");

    await ctx.db.patch(args.packId, {
      isActive: !pack.isActive,
      updatedAt: Date.now(),
    });

    return { isActive: !pack.isActive };
  },
});
