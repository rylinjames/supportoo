import { Doc, Id } from "@/convex/_generated/dataModel";

// Lounge event type from the database
export type LoungeEvent = Doc<"loungeEvents">;

// Event data interface (matches convex/events.ts)
export interface EventData {
  userName?: string;
  targetUserName?: string;
  actorUserName?: string;
  oldRole?: string;
  newRole?: string;
  oldRoomName?: string;
  newRoomName?: string;
  moderatorName?: string;
  participantId?: string;
  warningLevel?: string;
  minutesRemaining?: number;
}

// Event types enum
export const EVENT_TYPES = {
  USER_JOINED: "user_joined",
  USER_LEFT: "user_left",
  SPEAK_REQUEST: "speak_request",
  USER_KICKED: "user_kicked",
  USER_BANNED: "user_banned",
  ROLE_PROMOTED: "role_promoted",
  ROLE_DEMOTED: "role_demoted",
  ROOM_RENAMED: "room_renamed",
  LOUNGE_STARTED: "lounge_started",
  ROOM_CODE_UPDATED: "room_code_updated",
  MINUTE_WARNING: "minute_warning",
  SCREEN_SHARE_STARTED: "screen_share_started",
  SCREEN_SHARE_STOPPED: "screen_share_stopped",
  PARTICIPANT_MUTED: "participant_muted",
  PARTICIPANT_UNMUTED: "participant_unmuted",
  ALL_SPEAKERS_MUTED: "all_speakers_muted",
} as const;

export type EventType = (typeof EVENT_TYPES)[keyof typeof EVENT_TYPES];
