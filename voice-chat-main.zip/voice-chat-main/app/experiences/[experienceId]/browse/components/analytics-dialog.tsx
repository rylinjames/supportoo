"use client";

import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { BarChart3, Zap } from "lucide-react";

interface AnalyticsDialogProps {
  companyId: string;
}

export default function AnalyticsDialog({ companyId }: AnalyticsDialogProps) {
  // Get enhanced analytics data
  const analyticsData = useQuery(api.plans.getCompanyAnalytics, {
    companyId: companyId as any,
  });

  const planCatalog = useQuery(api.plans.getCatalog);

  if (!analyticsData || !planCatalog) {
    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button
            variant="ghost"
            className="text-neutral-800 max-w-max dark:text-white hover:bg-transparent! hover:text-neutral-600 dark:hover:text-neutral-300"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-background border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white max-w-md max-h-[85vh] overflow-hidden">
          <div className="flex items-center justify-center p-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-neutral-900 dark:border-white mx-auto mb-4"></div>
              <p className="text-neutral-600 dark:text-neutral-400">
                Loading analytics...
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const currentPlan = analyticsData.planTierName;
  const planData = planCatalog[currentPlan];
  const isFreeTier = currentPlan === "free";
  const { usageSummary, planUtilization, creditBreakdown } = analyticsData;

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          className="text-neutral-800 dark:text-white hover:bg-transparent! hover:text-neutral-600 dark:hover:text-neutral-300"
        >
          <BarChart3 className="w-4 h-4 mr-2" />
          Analytics
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-background border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white max-w-md max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="text-xl font-semibold text-neutral-900 dark:text-white">
            Plan Analytics
          </DialogTitle>
          <DialogDescription className="text-neutral-600 dark:text-neutral-400">
            Current plan status and usage overview
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 overflow-y-auto flex-1">
          {/* Current Plan Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium text-neutral-900 dark:text-white">
                Current Plan
              </h3>
            </div>

            <div className="p-3 bg-neutral-100 dark:bg-neutral-800/50 rounded-lg border border-neutral-300 dark:border-neutral-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-neutral-900 dark:text-white">
                  Plan Tier
                </span>
                <span className="text-sm text-neutral-700 dark:text-neutral-300 capitalize">
                  {currentPlan} Tier
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-neutral-900 dark:text-white">
                  Monthly Cap
                </span>
                <span className="text-sm text-neutral-700 dark:text-neutral-300">
                  {planData?.includedMinutes?.toLocaleString() || 0} minutes
                </span>
              </div>
            </div>
          </div>

          <Separator className="bg-neutral-300 dark:bg-neutral-700" />

          {/* Usage Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-medium text-neutral-900 dark:text-white">
                Usage This Month
              </h3>
            </div>

            <div className="p-3 bg-neutral-100 dark:bg-neutral-800/50 rounded-lg border border-neutral-300 dark:border-neutral-700">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-neutral-900 dark:text-white">
                  Minutes Used
                </span>
                <span className="text-sm text-neutral-700 dark:text-neutral-300">
                  {usageSummary.used.toLocaleString()} minutes
                </span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-neutral-900 dark:text-white">
                  Minutes Remaining
                </span>
                <span className="text-sm text-neutral-700 dark:text-neutral-300">
                  {usageSummary.available.toLocaleString()} minutes
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-neutral-900 dark:text-white">
                  Total Available
                </span>
                <span className="text-sm text-neutral-700 dark:text-neutral-300">
                  {usageSummary.included.toLocaleString()} minutes
                </span>
              </div>
            </div>

            {/* Usage Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-neutral-600 dark:text-neutral-400">
                  Usage Progress
                </span>
                <span className="text-neutral-700 dark:text-neutral-300">
                  {Math.round(planUtilization)}%
                </span>
              </div>
              <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all duration-300 ${
                    planUtilization > 90
                      ? "bg-red-500"
                      : planUtilization > 70
                        ? "bg-amber-500"
                        : "bg-blue-500"
                  }`}
                  style={{
                    width: `${Math.min(planUtilization, 100)}%`,
                  }}
                ></div>
              </div>
            </div>
          </div>

          {/* Renewal Section - Only show for paid plans */}
          {!isFreeTier && (
            <>
              <Separator className="bg-neutral-300 dark:bg-neutral-700" />

              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-medium text-neutral-900 dark:text-white">
                    Plan Renewal
                  </h3>
                </div>

                <div className="p-3 bg-neutral-100 dark:bg-neutral-800/50 rounded-lg border border-neutral-300 dark:border-neutral-700">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-neutral-900 dark:text-white">
                      Next Renewal
                    </span>
                    <span className="text-sm text-neutral-700 dark:text-neutral-300">
                      {new Date(usageSummary.renewalAt).toLocaleDateString(
                        "en-US",
                        {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        }
                      )}
                    </span>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Credit Breakdown */}
          {creditBreakdown.length > 0 && (
            <>
              <Separator className="bg-neutral-300 dark:bg-neutral-700" />

              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-medium text-neutral-900 dark:text-white">
                    Credit Packs
                  </h3>
                  <Zap className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                </div>

                <div className="space-y-2">
                  {creditBreakdown.slice(0, 3).map((credit: any) => (
                    <div
                      key={credit.id}
                      className="p-3 bg-neutral-100 dark:bg-neutral-800/50 rounded-lg border border-neutral-300 dark:border-neutral-700"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium text-neutral-900 dark:text-white capitalize">
                          {credit.source} Pack
                        </span>
                        <span className="text-xs text-neutral-500 dark:text-neutral-400">
                          {new Date(credit.purchasedAt).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-neutral-600 dark:text-neutral-400">
                          {credit.usedMinutes} / {credit.originalMinutes} used
                        </span>
                        <span className="text-xs text-neutral-700 dark:text-neutral-300">
                          {credit.remainingMinutes} remaining
                        </span>
                      </div>
                    </div>
                  ))}
                  {creditBreakdown.length > 3 && (
                    <p className="text-xs text-neutral-600 dark:text-neutral-400 text-center">
                      +{creditBreakdown.length - 3} more credit packs
                    </p>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
