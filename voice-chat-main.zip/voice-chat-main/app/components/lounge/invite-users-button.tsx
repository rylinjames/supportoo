"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { toast } from "sonner";
import { UserPlus } from "lucide-react";

export function InviteUsersButton({
  roomId,
  whopUserId,
}: {
  roomId: string;
  whopUserId: string;
}) {
  const [open, setOpen] = useState(false);
  const [username, setUsername] = useState("");
  const createInvite = useMutation(api.rooms.createInvite);

  const handleInvite = async () => {
    if (!username.trim()) {
      toast.error("Please enter a whop @username or whop personal id");
      return;
    }
    try {
      const res = await createInvite({
        roomId: roomId as Id<"rooms">,
        inviterId: whopUserId as Id<"users">,
        inviteeWhopUsername: username.trim().replace(/^@/, ""),
      });
      const uname = username.trim().replace(/^@/, "");
      if (res && typeof res === "object" && "ok" in res) {
        const r: any = res;
        if (r.ok === true) {
          toast.success(`Invitation sent to @${uname}`);
        } else {
          switch (r.reason) {
            case "room_not_found":
              toast.error("This lounge no longer exists.");
              break;
            case "not_private":
              toast.error("Invites only apply to private lounges.");
              break;
            case "not_creator":
              toast.error("Only the lounge creator can invite users.");
              break;
            case "already_allowed":
              toast.info(
                `@${uname} already has access to this private lounge.`
              );
              break;
            default:
              toast.error("Failed to send invitation. Please try again.");
          }
        }
      } else {
        toast.success(`Invitation sent to @${uname}`);
      }
      setOpen(false);
      setUsername("");
    } catch (e: any) {
      console.error("createInvite error:", e);
      toast.error("Failed to send invitation. Please try again.");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full justify-start flex-1 bg-white dark:bg-neutral-800 text-neutral-800 dark:text-white border border-neutral-200 dark:border-neutral-700 hover:border-primary hover:bg-primary dark:hover:bg-primary hover:text-white">
          <UserPlus className="w-4 h-4 mr-2" />
          Invite Users
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Invite a user to your private lounge</DialogTitle>
        </DialogHeader>
        <div className="space-y-2">
          <Input
            placeholder="Enter their whop @username or whop personal id"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleInvite} className="text-white">
            Send Invite
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
