"use client";

import { useState, useEffect } from "react";

interface UsePromoDisplayOptions {
  enabled: boolean; // Whether promo should be shown (e.g., user is on free tier)
  delayMs?: number; // Delay before showing promo
}

export function usePromoDisplay({
  enabled,
  delayMs = 1500,
}: UsePromoDisplayOptions) {
  const [shouldShow, setShouldShow] = useState(false);

  useEffect(() => {
    if (!enabled) {
      setShouldShow(false);
      return;
    }

    // Check if "Maybe Later" was clicked in last 24h
    const maybeLaterTime = localStorage.getItem("voiceLounge_maybeLater");
    const now = Date.now();

    if (maybeLaterTime) {
      const timeSinceClick = now - parseInt(maybeLaterTime);
      const twentyFourHours = 24 * 60 * 60 * 1000;

      if (timeSinceClick < twentyFourHours) {
        // Still in 24h cooldown
        console.log(
          "Promo in cooldown for",
          Math.round((twentyFourHours - timeSinceClick) / (60 * 60 * 1000)),
          "more hours"
        );
        return;
      }
    }

    // Show promo after delay for better UX
    const timer = setTimeout(() => {
      setShouldShow(true);
    }, delayMs);

    return () => clearTimeout(timer);
  }, [enabled, delayMs]);

  const handleMaybeLater = () => {
    // Set 24h cooldown
    localStorage.setItem("voiceLounge_maybeLater", Date.now().toString());
    setShouldShow(false);
    console.log("Promo dismissed for 24 hours");
  };

  const handleClose = () => {
    // No cooldown for X button or clicking outside
    setShouldShow(false);
    console.log("Promo closed (no cooldown)");
  };

  const handleClaim = () => {
    // User clicked claim - they'll be redirected to plans
    setShouldShow(false);
    console.log("Promo claimed - redirecting to plans");
  };

  return {
    shouldShow,
    handleMaybeLater,
    handleClose,
    handleClaim,
  };
}
