import { Doc, Id } from "@/convex/_generated/dataModel";

// Participant type from the database WITH populated user field
export type ConvexParticipant = Doc<"participants"> & {
  user: Doc<"users"> | null;
};

// Room reaction type from the database
export type RoomReaction = Doc<"reactions">;

// Room type from the database
export type Room = Doc<"rooms">;

// Lounge category interface
export interface LoungeCategory {
  id: string;
  name: string;
  icon: string;
}

// Plan feature type (for pricing plans)
export interface PlanFeature {
  name: string;
  description?: string;
}
