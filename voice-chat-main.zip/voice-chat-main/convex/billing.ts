import { action, mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { api } from "./_generated/api";

// Create a checkout session for a minute pack (Whop)
export const createMinutePackCheckout = action({
  args: {
    companyId: v.id("companies"),
    requesterId: v.id("users"),
    packId: v.string(), // pack_20k | pack_60k | pack_150k
  },
  handler: async (ctx, args) => {
    // Owner-only for now
    const company = await ctx.runQuery(api.companies.getCompanyById, {
      companyId: args.companyId,
    });
    if (!company) throw new Error("Company not found");
    if (company.owner !== args.requesterId) {
      throw new Error("Only the company owner can purchase minutes");
    }

    // Bridge to client: return the packId and companyId so client can call Whop iFrame SDK
    return {
      packId: args.packId,
      companyId: args.companyId,
      metadata: { companyId: String(args.companyId), packId: args.packId },
    };
  },
});

// Webhook receiver (to be wired to your API route) would call this mutation on success
export const creditMinutesForReceipt = mutation({
  args: {
    companyId: v.id("companies"),
    minutes: v.number(),
    receiptId: v.string(),
    source: v.union(v.literal("pack"), v.literal("promo")),
    expiresAt: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    // Insert credit if not already processed
    const existing = await ctx.db
      .query("billingReceipts")
      .withIndex("by_receipt", (q) => q.eq("receiptId", args.receiptId))
      .first();
    if (existing) return { ok: true };

    const creditId = await ctx.db.insert("companyMinuteCredits", {
      companyId: args.companyId,
      minutes: args.minutes,
      remainingMinutes: args.minutes,
      source: args.source,
      receiptRef: args.receiptId,
      purchasedAt: Date.now(),
      expiresAt: args.expiresAt,
    });

    await ctx.db.insert("billingReceipts", {
      companyId: args.companyId,
      provider: "whop",
      receiptId: args.receiptId,
      billingReason: "one_time",
      status: "succeeded",
      amountUsd: 0, // optional; can be filled from webhook
      currency: "usd",
      planId: undefined,
      packId: undefined,
      creditId,
      paidAt: Date.now(),
      rawPayload: undefined,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    return { ok: true };
  },
});

// Reverse minutes on refund/chargeback
export const reverseMinutesForReceipt = mutation({
  args: {
    companyId: v.id("companies"),
    receiptId: v.string(),
    minutes: v.number(), // minutes to reverse
    status: v.union(
      v.literal("refunded"),
      v.literal("partially_refunded"),
      v.literal("failed")
    ),
  },
  handler: async (ctx, args) => {
    const { companyId, receiptId, minutes } = args;
    let toReverse = Math.max(0, minutes);

    // Find credit(s) tied to this receipt (typically one)
    const credits = await ctx.db
      .query("companyMinuteCredits")
      .withIndex("by_company", (q) => q.eq("companyId", companyId))
      .collect();
    const byReceipt = credits.filter((c) => c.receiptRef === receiptId);

    for (const c of byReceipt) {
      if (toReverse <= 0) break;
      const reduce = Math.min(toReverse, Math.max(0, c.remainingMinutes || 0));
      if (reduce > 0) {
        await ctx.db.patch(c._id, {
          remainingMinutes: (c.remainingMinutes || 0) - reduce,
        });
        toReverse -= reduce;
      }
    }

    // If we still need to reverse minutes that were already consumed, add a negative adjustment
    if (toReverse > 0) {
      await ctx.db.insert("companyMinuteCredits", {
        companyId,
        minutes: -toReverse,
        remainingMinutes: 0,
        source: "plan_adjustment",
        receiptRef: receiptId,
        purchasedAt: Date.now(),
        expiresAt: undefined,
      });
    }

    // Mirror receipt status
    const existing = await ctx.db
      .query("billingReceipts")
      .withIndex("by_receipt", (q) => q.eq("receiptId", receiptId))
      .first();
    if (existing) {
      await ctx.db.patch(existing._id, {
        status: args.status,
        updatedAt: Date.now(),
      });
    }

    return { ok: true };
  },
});

// Read-only: return checkout config (plan and pack links)
export const getCheckoutConfig = query({
  args: {},
  handler: async (ctx) => {
    // Get plans from centralized database
    const plans = await ctx.db
      .query("plans")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .order("asc")
      .collect();

    // Get minute packs from centralized database
    const minutePacks = await ctx.db
      .query("minutePacks")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .order("asc")
      .collect();

    // Transform plans to expected format
    const plansConfig = plans.reduce(
      (acc, plan) => {
        if (plan.whopPlanId && plan.whopCheckoutUrl) {
          acc[plan.tier] = {
            planId: plan.whopPlanId,
            url: plan.whopCheckoutUrl,
          };
        }
        return acc;
      },
      {} as Record<string, { planId: string; url: string }>
    );

    // Transform minute packs to expected format
    const packsConfig = minutePacks.map((pack) => ({
      planId: pack.whopPlanId,
      label: pack.name,
      minutes: pack.minutes,
      price: pack.priceUsd,
      url: pack.whopCheckoutUrl,
    }));

    return { plans: plansConfig, packs: packsConfig };
  },
});
