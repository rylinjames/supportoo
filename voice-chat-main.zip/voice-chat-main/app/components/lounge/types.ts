export interface Participant {
  id: string;
  whopUserId: string;
  convexUserId: string; // Convex user ID for reaction matching
  name: string;
  avatar: string;
  role: "moderator" | "speaker" | "listener";
  isMuted: boolean;
  isSpeaking: boolean;
  isDisconnected: boolean;
  isRoomCreator?: boolean;
  isAnonymous?: boolean; // Anonymous mode for listeners
  isCompanyAdmin?: boolean;
  canBeManagedByViewer?: boolean;
}
