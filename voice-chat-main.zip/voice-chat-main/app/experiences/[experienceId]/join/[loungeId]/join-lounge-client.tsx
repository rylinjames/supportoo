"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useSessionStore } from "@/stores/session-store";
import LoadingScreen from "@/app/components/shared/loading-screen";
import { PrivateLoungeAuth } from "./components/private-lounge-auth";
import { Id } from "@/convex/_generated/dataModel";

interface JoinLoungeClientProps {
  experienceId: string;
  loungeId: string;
}

const JoinLoungeClient = ({
  experienceId,
  loungeId,
}: JoinLoungeClientProps) => {
  const [isJoining, setIsJoining] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { isSessionValid, session, _hasHydrated } = useSessionStore();

  // Fetch room data
  const roomData = useQuery(
    api.rooms.getRoomForJoin,
    session ? { roomId: loungeId as Id<"rooms"> } : "skip"
  );

  // Join mutation
  const joinPublicRoom = useMutation(api.participants.joinPublicRoom);

  // Join lounge when component loads (only if active or creator)
  useEffect(() => {
    const isCreatorNow = Boolean(
      roomData && session && roomData.creatorId === session.convexUserId
    );
    const canAttemptJoin =
      roomData &&
      session &&
      !isJoining &&
      !error &&
      roomData.isPublic &&
      (roomData.isActive || isCreatorNow);

    if (canAttemptJoin) {
      const joinLounge = async () => {
        setIsJoining(true);
        try {
          await joinPublicRoom({
            roomId: loungeId as Id<"rooms">,
            userId: session.convexUserId as Id<"users">,
            viewerIsCompanyAdmin: session.whopAccessLevel === "admin",
            requesterCompanyId: session.convexCompanyId,
          });

          // Navigate to lounge
          router.push(`/experiences/${experienceId}/lounge/${loungeId}`);
        } catch (error) {
          setIsJoining(false);
          console.error("Failed to join room:", error);
          const raw =
            (error instanceof Error && error.message) ||
            (error as any)?.message ||
            (error as any)?.error ||
            "";
          const lower = String(raw).toLowerCase();
          let friendly = "Failed to join lounge. Please try again.";
          if (lower.includes("insufficient minutes")) {
            friendly =
              "Your Whop has insufficient minutes to join this lounge. Please upgrade your plan to continue.";
          } else if (
            lower.includes("inactive") ||
            lower.includes("only the creator")
          ) {
            friendly =
              "This lounge is inactive. Only the creator can start it.";
          } else if (lower.includes("private")) {
            friendly = "This lounge is private. Use an invite or code to join.";
          } else if (lower.includes("room not found")) {
            friendly = "This lounge no longer exists.";
          } else if (lower.includes("user not found")) {
            friendly =
              "We couldn't find your account. Please reload and try again.";
          }
          setError(friendly);
        }
      };

      joinLounge();
    }
  }, [
    roomData,
    session,
    isJoining,
    error,
    joinPublicRoom,
    loungeId,
    router,
    experienceId,
  ]);

  // Session validation
  if (!_hasHydrated) {
    return <LoadingScreen />;
  }

  if (!isSessionValid() || !session) {
    return (
      <LoadingScreen
        message="Your session has expired. Please reload to sync your account again or go back to browse."
        error={true}
      />
    );
  }

  // Loading room data
  if (roomData === undefined) {
    return <LoadingScreen />;
  }

  // Room not found
  if (roomData === null) {
    return (
      <LoadingScreen
        message="Lounge doesn't exist. Browse some more lounges."
        error={true}
      />
    );
  }

  // Creator detection
  const isCreator = roomData.creatorId === session.convexUserId;

  // Non-creator trying to join inactive room
  if (!roomData.isActive && !isCreator) {
    return (
      <LoadingScreen
        message="Lounge isn't up at the moment. Kindly join later."
        info={true}
      />
    );
  }

  if (error) {
    return <LoadingScreen message={error} error={true} />;
  }

  // Branch based on room type
  if (roomData.isPublic) {
    // Default loading for public rooms
    return <LoadingScreen />;
  } else {
    // Private room: Show code input interface
    return (
      <PrivateLoungeAuth
        roomData={roomData}
        experienceId={experienceId}
        loungeId={loungeId}
      />
    );
  }
};

export default JoinLoungeClient;
