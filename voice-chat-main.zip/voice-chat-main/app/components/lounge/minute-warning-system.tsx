"use client";

import { useEffect, useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { toast } from "sonner";
import { LoungeEvent } from "@/types/lounge-events";
import { useRouter } from "next/navigation";

interface MinuteWarningSystemProps {
  roomId: string;
  isAdmin: boolean;
  experienceId: string;
}

export function MinuteWarningSystem({
  roomId,
  isAdmin,
  experienceId,
}: MinuteWarningSystemProps) {
  const [shownWarnings, setShownWarnings] = useState<Set<string>>(new Set());
  const router = useRouter();

  // Query for recent warning events (last 5 minutes)
  const recentEvents: LoungeEvent[] | undefined = useQuery(
    api.events.getRecentWarningEvents,
    isAdmin ? { roomId: roomId as Id<"rooms">, minutes: 5 } : "skip"
  );

  useEffect(() => {
    if (!isAdmin || !recentEvents) return;

    // Check for new warning events that haven't been shown yet
    recentEvents.forEach((event) => {
      const eventKey = `${event.eventData.warningLevel}_${event.createdAt}`;

      if (!shownWarnings.has(eventKey) && event.eventData.warningLevel) {
        // Show toast based on warning level
        const minutesRemaining = event.eventData.minutesRemaining || 0;

        switch (event.eventData.warningLevel) {
          case "10_minutes":
            toast.warning("⚠️ 10 minutes remaining", {
              description: `Your Whop has ${minutesRemaining} minutes left for voice chat.`,
              duration: 8000,
              action: {
                label: "Upgrade Plan",
                onClick: () =>
                  router.push(`/experiences/${experienceId}/plans`),
              },
            });
            break;
          case "5_minutes":
            toast.warning("⚠️ 5 minutes remaining", {
              description: `Your Whop has ${minutesRemaining} minutes left. Consider upgrading soon.`,
              duration: 10000,
              action: {
                label: "Upgrade Now",
                onClick: () =>
                  router.push(`/experiences/${experienceId}/plans`),
              },
            });
            break;
          case "1_minute":
            toast.error("🚨 1 minute remaining", {
              description: `Your Whop has ${minutesRemaining} minute left! The lounge will shut down when minutes are exhausted.`,
              duration: 15000,
              action: {
                label: "Upgrade Now",
                onClick: () =>
                  router.push(`/experiences/${experienceId}/plans`),
              },
            });
            break;
        }

        // Mark this warning as shown
        setShownWarnings((prev) => new Set(prev).add(eventKey));
      }
    });
  }, [recentEvents, isAdmin, shownWarnings]);

  // This component doesn't render anything visible
  return null;
}
