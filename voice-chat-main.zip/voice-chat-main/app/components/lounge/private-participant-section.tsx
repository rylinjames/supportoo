"use client";

import { motion, AnimatePresence } from "motion/react";
import { ParticipantPopover } from "./participant-popover";
import { Participant } from "./types";

interface ParticipantSectionProps {
  participants: Participant[];
  initialCount?: number;
  delay?: number;
  currentUserRole?: string;
  currentUserId?: string;
  roomCreatorId?: string;
  roomId: string;
  onKickFromLounge?: (participantId: string) => void;
}

export function PrivateParticipantSection({
  delay = 0.1,
  currentUserRole,
  currentUserId,
  roomCreatorId,
  roomId,
  onKickFromLounge,
  participants,
}: ParticipantSectionProps) {
  return (
    <motion.section
      className="mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <div className={`flex xl:flex-wrap gap-3 max-xl:overflow-x-auto`}>
        <AnimatePresence>
          {participants.map((participant, index) => (
            <ParticipantPopover
              key={participant.id}
              participant={participant}
              index={index}
              currentUserRole={currentUserRole}
              currentUserId={currentUserId}
              isRoomCreator={participant.convexUserId === roomCreatorId}
              onKickFromLounge={onKickFromLounge}
              roomId={roomId}
              convexUserId={participant.convexUserId}
            />
          ))}
        </AnimatePresence>
      </div>
    </motion.section>
  );
}
