const LoungeSidebarFooter = () => {
  return (
    <div className="h-[105px] grid mt-auto place-items-center border-t border-neutral-200 dark:border-neutral-800 flex-shrink-0">
      <div className="text-center">
        <p className="text-sm">Voice Lounge</p>
        <p className="text-xs mt-1 text-neutral-400">
          Powered by{" "}
          <span className="text-neutral-800 dark:text-white">Bookoo Apps</span>
        </p>
      </div>
    </div>
  );
};

export default LoungeSidebarFooter;
