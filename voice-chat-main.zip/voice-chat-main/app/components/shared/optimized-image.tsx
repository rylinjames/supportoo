"use client";

import { getOptimizedImageUrl } from "@/lib/imagekit";
import { useState } from "react";

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  quality?: number;
  format?: "jpg" | "png" | "webp" | "avif";
  crop?: "maintain_ratio" | "force" | "at_least" | "at_max";
  fallback?: string;
}

export function OptimizedImage({
  src,
  alt,
  width,
  height,
  quality = 80,
  format = "webp",
  crop = "at_max",
  fallback = "/images/whop-logo.png",
  className,
  ...props
}: OptimizedImageProps) {
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Get optimized URL if it's an ImageKit image
  const optimizedSrc = getOptimizedImageUrl(src, {
    width,
    height,
    quality,
    format,
    crop,
  });

  const handleError = () => {
    setHasError(true);
    setIsLoading(false);
  };

  const handleLoad = () => {
    setIsLoading(false);
  };

  return (
    <div className={`relative ${className || ""}`}>
      {isLoading && (
        <div className="absolute inset-0 bg-neutral-100 dark:bg-neutral-700 animate-pulse rounded-lg" />
      )}
      <img
        {...props}
        src={hasError ? fallback : optimizedSrc}
        alt={alt}
        onError={handleError}
        onLoad={handleLoad}
        className={`${className || ""} ${isLoading ? "opacity-0" : "opacity-100"} transition-opacity duration-300`}
      />
    </div>
  );
}
