import { mutation } from "./_generated/server";
import { api } from "./_generated/api";

function getNextMonthStartUtc(nowMs: number): number {
  const d = new Date(nowMs);
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth();
  return new Date(Date.UTC(y, m + 1, 1, 0, 0, 0, 0)).getTime();
}

export const monthlyRollover = mutation({
  args: {},
  handler: async (ctx): Promise<{ rolled: number; errors: string[] }> => {
    // Use atomic rollover with coordination locks to prevent minute leakage
    return await ctx.runMutation(api.atomicBilling.monthlyRolloverWithLock, {});
  },
});
