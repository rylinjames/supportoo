"use client";

import { motion, AnimatePresence } from "motion/react";
import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ParticipantPopover } from "./participant-popover";
import { Participant } from "./types";

interface ParticipantSectionProps {
  title: string;
  icon: React.ReactNode;
  participants: Participant[];
  showAllListeners?: boolean;
  setShowAllListeners?: (show: boolean) => void;
  initialCount?: number;
  delay?: number;
  currentUserRole?: string;
  currentUserId?: string;
  roomCreatorId?: string;
  roomId: string;
  onAddToSpeakers?: (participantId: string) => void;
  onRemoveFromSpeakers?: (participantId: string) => void;
  onKickFromLounge?: (participantId: string) => void;
  onPromoteToModerator?: (participantId: string) => void;
  onDemoteModeratorToSpeaker?: (participantId: string) => void;
  onMuteParticipant?: (participantId: string) => void;
  onUnmuteParticipant?: (participantId: string) => void;
  canManageModerators?: boolean;
  whopCompanyId?: string;
}

export function ParticipantSection({
  title,
  icon,
  participants,
  showAllListeners,
  setShowAllListeners,
  initialCount = 12,
  delay = 0.1,
  currentUserRole,
  currentUserId,
  roomCreatorId,
  roomId,
  onAddToSpeakers,
  onRemoveFromSpeakers,
  onKickFromLounge,
  onPromoteToModerator,
  onDemoteModeratorToSpeaker,
  onMuteParticipant,
  onUnmuteParticipant,
  canManageModerators,
  whopCompanyId,
}: ParticipantSectionProps) {
  const isListeners = title.toLowerCase().includes("listener");
  const displayParticipants =
    isListeners && !showAllListeners
      ? participants.slice(0, initialCount)
      : participants;

  return (
    <motion.section
      className="mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <h2 className="text-lg max-md:text-base font-semibold  mb-4 flex items-center gap-2 text-neutral-800! dark:text-white!">
        {icon}
        {title}
        {isListeners && ` (${participants.length})`}
      </h2>

      <div className={`flex xl:flex-wrap gap-3 max-xl:overflow-x-auto`}>
        <AnimatePresence>
          {displayParticipants.map((participant, index) => (
            <ParticipantPopover
              key={participant.id}
              participant={participant}
              index={index}
              size={isListeners ? "small" : "large"}
              currentUserRole={currentUserRole}
              currentUserId={currentUserId}
              isRoomCreator={participant.convexUserId === roomCreatorId}
              onAddToSpeakers={onAddToSpeakers}
              onRemoveFromSpeakers={onRemoveFromSpeakers}
              onKickFromLounge={onKickFromLounge}
              onPromoteToModerator={onPromoteToModerator}
              onDemoteModeratorToSpeaker={onDemoteModeratorToSpeaker}
              onMuteParticipant={onMuteParticipant}
              onUnmuteParticipant={onUnmuteParticipant}
              canManageModerators={canManageModerators}
              roomId={roomId}
              convexUserId={participant.convexUserId}
              whopCompanyId={whopCompanyId}
            />
          ))}
        </AnimatePresence>
      </div>

      {/* Show More/Less Button for Listeners */}
      {isListeners && participants.length > initialCount && (
        <motion.div
          className="flex justify-center mt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Button
            variant="ghost"
            onClick={() => setShowAllListeners?.(!showAllListeners)}
            className="bg-[#2a2a2a] hover:bg-[#333333] text-gray-300 hover:text-white px-6 py-2 rounded-full transition-all duration-300"
          >
            <motion.span
              key={showAllListeners ? "less" : "more"}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {showAllListeners
                ? `Show Less`
                : `Show ${participants.length - initialCount} More`}
            </motion.span>
            <motion.div
              animate={{ rotate: showAllListeners ? 180 : 0 }}
              transition={{ duration: 0.3 }}
              className="ml-2"
            >
              <ChevronRight className="w-4 h-4" />
            </motion.div>
          </Button>
        </motion.div>
      )}
    </motion.section>
  );
}
