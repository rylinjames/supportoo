"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface ResetSpeakersModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  isLoading?: boolean;
}

export function ResetSpeakersModal({
  open,
  onOpenChange,
  onConfirm,
  isLoading = false,
}: ResetSpeakersModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-background border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-neutral-900 dark:text-white">
            Reset All Speakers
          </DialogTitle>
          <DialogDescription className="text-neutral-600 dark:text-neutral-400">
            This will reset all current speakers back to listeners. This action
            cannot be undone.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="gap-3">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button
            onClick={onConfirm}
            disabled={isLoading}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            {isLoading ? "Resetting..." : "Reset All Speakers"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
