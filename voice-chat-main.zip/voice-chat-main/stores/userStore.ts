import { create } from "zustand";

interface UserState {
  reactions: Record<string, string>; // userId -> emoji
  addReaction: (userId: string, emoji: string) => void;
  clearReaction: (userId: string) => void;
  clearReactions: () => void;
}

export const useUserStore = create<UserState>((set, get) => ({
  reactions: {},

  addReaction: (userId: string, emoji: string) => {
    set((state) => ({
      reactions: {
        ...state.reactions,
        [userId]: emoji,
      },
    }));

    // Auto-clear based on reaction type
    const timeout = emoji === "✋" ? 30000 : 7000; // 30s for hand, 7s for others

    setTimeout(() => {
      get().clearReaction(userId);
    }, timeout);
  },

  clearReaction: (userId: string) => {
    set((state) => {
      const newReactions = { ...state.reactions };
      delete newReactions[userId];
      return { reactions: newReactions };
    });
  },

  clearReactions: () => {
    set({ reactions: {} });
  },
}));
