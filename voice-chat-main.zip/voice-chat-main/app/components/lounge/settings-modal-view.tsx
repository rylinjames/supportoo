"use client";

import { useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import {
  ModeratorView,
  moderatorSettingsSchema,
  ModeratorSettingsFormData,
} from "./moderator-view";
import {
  SpeakerView,
  speakerSettingsSchema,
  SpeakerSettingsFormData,
} from "./speaker-view";
import {
  ListenerView,
  listenerSettingsSchema,
  ListenerSettingsFormData,
} from "./listener-view";

interface SettingsModalViewProps {
  currentUserRole?: string;
  roomId: string;
  whopUserData: {
    _id: string;
    whopUserId: string;
    whopUsername: string;
    fullName: string;
    isAnonymous?: boolean;
  };
  roomDetails?: any; // Room details from Convex
  localParticipant?: any; // LiveKit local participant
}

const SettingsModalView = ({
  currentUserRole,
  roomId,
  whopUserData,
  roomDetails,
  localParticipant,
}: SettingsModalViewProps) => {
  // Convex mutations
  const updateRoomSettingsMutation = useMutation(api.rooms.updateRoomSettings);
  const updateUserSettingsMutation = useMutation(api.users.updateUserSettings);

  // Moderator form
  const moderatorForm = useForm<ModeratorSettingsFormData>({
    resolver: zodResolver(moderatorSettingsSchema),
    defaultValues: {
      name: "",
      maxParticipants: 50,
      maxSpeakers: 10,
    },
  });

  // Speaker form
  const speakerForm = useForm<SpeakerSettingsFormData>({
    resolver: zodResolver(speakerSettingsSchema),
    defaultValues: {},
  });

  // Listener form
  const listenerForm = useForm<ListenerSettingsFormData>({
    resolver: zodResolver(listenerSettingsSchema),
    defaultValues: {
      isAnonymous: whopUserData.isAnonymous || false,
    },
  });

  // Test function for moderators to test anonymous mode
  const testAnonymousMode = async () => {
    try {
      const newAnonymousState = !whopUserData.isAnonymous;
      await updateUserSettingsMutation({
        userId: whopUserData._id as any,
        isAnonymous: newAnonymousState,
      });
      toast.success(
        `Anonymous mode ${newAnonymousState ? "enabled" : "disabled"} for testing`
      );
    } catch (error) {
      console.error("Failed to test anonymous mode:", error);
      toast.error("Failed to test anonymous mode.");
    }
  };

  // Initialize forms based on role
  useEffect(() => {
    if (currentUserRole === "moderator" && roomDetails) {
      moderatorForm.reset({
        name: roomDetails.name || "",
        maxParticipants: roomDetails.maxParticipants ?? 50,
        maxSpeakers: roomDetails.maxSpeakers ?? 10,
        autoSpeakersEnabled: roomDetails.autoSpeakersEnabled ?? false,
      });
    }
  }, [roomDetails, currentUserRole, moderatorForm]);

  useEffect(() => {
    if (currentUserRole === "listener") {
      listenerForm.reset({
        isAnonymous: whopUserData.isAnonymous || false,
      });
    }
  }, [whopUserData.isAnonymous, currentUserRole, listenerForm]);

  // Render based on user role
  if (currentUserRole === "moderator") {
    return (
      <ModeratorView
        register={moderatorForm.register}
        handleSubmit={moderatorForm.handleSubmit}
        errors={moderatorForm.formState.errors}
        isDirty={moderatorForm.formState.isDirty}
        isSubmitting={moderatorForm.formState.isSubmitting}
        roomId={roomId}
        updateRoomSettingsMutation={updateRoomSettingsMutation}
        reset={moderatorForm.reset}
        watch={moderatorForm.watch}
        setValue={moderatorForm.setValue}
        onTestAnonymousMode={testAnonymousMode}
        localParticipant={localParticipant}
        isPublic={roomDetails?.isPublic ?? true}
      />
    );
  }

  if (currentUserRole === "speaker") {
    return (
      <SpeakerView
        register={speakerForm.register}
        handleSubmit={speakerForm.handleSubmit}
        errors={speakerForm.formState.errors}
        isDirty={speakerForm.formState.isDirty}
        isSubmitting={speakerForm.formState.isSubmitting}
        reset={speakerForm.reset}
        localParticipant={localParticipant}
      />
    );
  }

  if (currentUserRole === "listener") {
    return (
      <ListenerView
        register={listenerForm.register}
        handleSubmit={listenerForm.handleSubmit}
        errors={listenerForm.formState.errors}
        isDirty={listenerForm.formState.isDirty}
        isSubmitting={listenerForm.formState.isSubmitting}
        reset={listenerForm.reset}
        userId={whopUserData._id}
        currentIsAnonymous={whopUserData.isAnonymous}
        localParticipant={localParticipant}
      />
    );
  }

  // Default view for unknown roles
  return (
    <div className="space-y-4">
      <p className="text-neutral-400">
        Settings for {currentUserRole} role coming soon...
      </p>
    </div>
  );
};

export default SettingsModalView;
