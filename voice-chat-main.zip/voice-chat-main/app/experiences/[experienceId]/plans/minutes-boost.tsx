import { Button } from "@/components/ui/button";
import { ZapIcon } from "lucide-react";

interface MinutesBoostProps {
  price: string;
  minutes: string;
  label: string;
  onGetPack: () => void;
}

export default function MinutesBoost({
  price,
  minutes,
  label,
  onGetPack,
}: MinutesBoostProps) {
  return (
    <div className="p-6 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <ZapIcon className="w-6 h-6 text-neutral-500 dark:text-neutral-400" />
        <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">
          {label}
        </span>
      </div>
      <div className="mb-6">
        <p className="text-3xl font-bold text-neutral-900 dark:text-white mb-1">
          {price}
        </p>
        <p className="text-sm text-neutral-600 dark:text-neutral-400">
          {minutes}{" "}
          <span className="text-neutral-800 dark:text-white">extra</span>
        </p>
      </div>
      <Button className="w-full" onClick={onGetPack}>
        Get Pack
      </Button>
    </div>
  );
}
