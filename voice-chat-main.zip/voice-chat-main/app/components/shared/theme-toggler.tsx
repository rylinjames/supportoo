"use client";

import * as React from "react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";

import { Button } from "@/components/ui/button";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

export function ThemeToggler() {
  const { setTheme, theme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  const pathname = usePathname();
  const isBrowsePage = pathname.includes("/browse");
  const isExplorePage = pathname.includes("/explore");
  const isPlansPage = pathname.includes("/plans");

  React.useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <Button
        disabled
        variant="outline"
        size="icon"
        className={cn("border border-neutral-200 dark:border-neutral-800", {
          // Browse/explore/plans pages
          "text-neutral-800 dark:text-white bg-background! border-none":
            isBrowsePage || isExplorePage || isPlansPage,
          // Other pages
          "text-neutral-800 dark:text-white shadow border":
            !isBrowsePage && !isExplorePage && !isPlansPage,
        })}
      >
        <Sun className="size-5" />
        <span className="sr-only">Toggle theme</span>
      </Button>
    );
  }

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      className={cn("border border-neutral-200 dark:border-neutral-800", {
        // Browse/explore/plans pages
        "text-neutral-800 hover:text-neutral-800 dark:text-white dark:hover:text-white bg-background! border-none":
          isBrowsePage || isExplorePage || isPlansPage,
        // Other pages
        "text-neutral-800 hover:text-white dark:text-white dark:hover:text-white shadow border":
          !isBrowsePage && !isExplorePage && !isPlansPage,
      })}
    >
      {theme === "dark" ? (
        <Sun className="size-5" />
      ) : (
        <Moon className="size-5" />
      )}
      <span className="sr-only">Toggle theme</span>
    </Button>
  );
}
