"use client";

import React, { useRef, useState, useEffect } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { EventItem } from "./event-item";
import { LoungeEvent } from "@/types/lounge-events";

interface LiveFeedProps {
  roomId: string;
}

export function LiveFeed({ roomId }: LiveFeedProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const lastEventCountRef = useRef(0);

  const latestEvents: LoungeEvent[] | undefined = useQuery(api.events.getLatestEvents, {
    roomId: roomId as Id<"rooms">,
    limit: 50,
  });

  // Auto-scroll to top when new events arrive (unless hovering)
  useEffect(() => {
    if (!latestEvents || latestEvents.length === 0) return;

    const latestEventTimestamp = Math.max(
      ...latestEvents.map((e) => e.createdAt)
    );
    const hasNewEvents = latestEventTimestamp > lastEventCountRef.current;

    if (!isHovering && hasNewEvents) {
      containerRef.current?.scrollTo({
        top: 0,
        behavior: "smooth",
      });
      lastEventCountRef.current = latestEventTimestamp;
    } else {
      lastEventCountRef.current = latestEventTimestamp;
    }
  }, [latestEvents, isHovering]);

  if (!latestEvents) {
    return (
      <div className="max-h-full min-h-full h-full overflow-y-auto space-y-3 pr-2 relative">
        <div className="text-center h-full grid place-items-center text-neutral-400 py-8 text-sm">
          Loading events...
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="max-h-full min-h-full h-full overflow-y-auto space-y-3 pr-2 relative"
      onMouseEnter={() => {
        setIsHovering(true);
      }}
      onMouseLeave={() => {
        setIsHovering(false);
      }}
    >
      {latestEvents.length === 0 ? (
        <div className="text-center h-full grid place-items-center text-neutral-400 py-8 text-sm">
          No events yet. Activity will appear here.
        </div>
      ) : (
         latestEvents.map((event) => (
           <EventItem key={event._id} event={event} />
         ))
      )}
    </div>
  );
}
