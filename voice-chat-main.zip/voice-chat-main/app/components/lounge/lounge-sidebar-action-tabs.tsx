import { Chat } from "./chat";
import { LiveFeed } from "./live-feed";
import { TabList, TabTrigger, Tabs, TabContent } from "./tabs";

const LoungeSidebarActionTabs = ({ roomId }: { roomId: string }) => {
  return (
    <div className="xl:flex-1 flex flex-col xl:h-full xl:max-h-[calc(100vh-111px-273px)]">
      <Tabs defaultTab="live-feed" className="flex flex-col h-full">
        <TabList className="flex-shrink-0 px-6 pt-4">
          <TabTrigger value="live-feed">Live Feed</TabTrigger>
          <TabTrigger value="chat">Chat</TabTrigger>
        </TabList>

        <TabContent
          value="live-feed"
          className="flex-1 flex flex-col min-h-0 p-6 h-full"
        >
          <LiveFeed roomId={roomId} />
        </TabContent>

        <TabContent
          value="chat"
          className="flex-1 flex flex-col min-h-0 p-6 h-full"
        >
          <Chat />
        </TabContent>
      </Tabs>
    </div>
  );
};

export default LoungeSidebarActionTabs;
