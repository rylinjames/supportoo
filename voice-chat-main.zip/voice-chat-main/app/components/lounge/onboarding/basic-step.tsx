"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState, useEffect } from "react";
import { useAction, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/animate-ui/radix/switch";
import { Loader2, RefreshCw, ZapIcon } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { ThemeToggler } from "../../shared/theme-toggler";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

const basicSchema = z.object({
  name: z
    .string()
    .min(1, "Lounge name is required")
    .max(50, "Lounge name must be 50 characters or less")
    .trim(),
  isPublic: z.boolean(),
  roomCode: z.string().optional(),
  // Temporary vs permanent toggle (admins only can set false)
  isTemporary: z.boolean().optional(),
  // Discover toggle (creator tier admins only)
  discoverListed: z.boolean().optional(),
  // Auto speakers toggle
  autoSpeakersEnabled: z.boolean().optional(),
});

type BasicFormData = z.infer<typeof basicSchema>;

interface BasicStepProps {
  initialData: {
    name: string;
    isPublic: boolean;
    roomCode?: string;
    isTemporary?: boolean;
    discoverListed?: boolean;
  };
  canEditLifecycle?: boolean;
  onSubmit: (data: BasicFormData) => void;
  onDataChange: (data: Partial<BasicFormData>) => void;
  experienceId: string;
  companyName?: string;
  companyRoomCount?: number;
  isOwner?: boolean;
  planSettings?: any; // Company plan settings for discover toggle
  usageSummary?: {
    used: number;
    included: number;
    creditsRemainingTotal: number;
    available: number;
    renewalAt: number;
  };
}

export function BasicStep({
  initialData,
  onSubmit,
  onDataChange,
  experienceId,
  companyName,
  companyRoomCount,
  isOwner,
  canEditLifecycle = false,
  planSettings,
  usageSummary,
}: BasicStepProps) {
  const [isGeneratingCode, setIsGeneratingCode] = useState(false);
  const [codeGenerationError, setCodeGenerationError] = useState<string | null>(
    null
  );
  const router = useRouter();

  const form = useForm<BasicFormData>({
    resolver: zodResolver(basicSchema),
    defaultValues: initialData,
  });

  const { watch, setValue } = form;
  const isPublic = watch("isPublic");
  const isTemporary = watch("isTemporary");
  const lifecycleChecked = !(isTemporary ?? true); // OFF => Temporary (default), ON => Permanent

  // Server-side room code generation action
  const generateRoomCodeAction = useAction(api.rooms.generateRoomCodeAction);
  // Company cap UI hint (optional: if we had companyId here)

  // Auto-generate room code on mount if private but no code exists
  useEffect(() => {
    const currentIsPublic = watch("isPublic");
    const currentRoomCode = watch("roomCode");

    if (!currentIsPublic && !currentRoomCode && !isGeneratingCode) {
      generateRoomCode();
    }
  }, []);

  // Generate room code from server
  const generateRoomCode = async () => {
    setIsGeneratingCode(true);
    setCodeGenerationError(null);

    try {
      const code = await generateRoomCodeAction();
      setValue("roomCode", code);
      onDataChange({ roomCode: code });
      return code;
    } catch (error) {
      console.error("Failed to generate room code:", error);
      setCodeGenerationError("Failed to generate room code. Please try again.");
      return null;
    } finally {
      setIsGeneratingCode(false);
    }
  };

  // Handle privacy toggle
  const handlePrivacyChange = async (checked: boolean) => {
    setValue("isPublic", checked);

    if (!checked && !watch("roomCode")) {
      // Generate server-side room code for private rooms
      await generateRoomCode();
      onDataChange({ isPublic: checked });
    } else {
      onDataChange({ isPublic: checked });
    }
  };

  const copyRoomCode = async () => {
    const roomCode = watch("roomCode");
    if (roomCode) {
      try {
        await navigator.clipboard.writeText(roomCode);
        toast.success("Room code copied to clipboard");
      } catch (error) {
        console.error("Failed to copy room code:", error);
        toast.error("Failed to copy room code");
      }
    }
  };

  const handleGoBack = () => {
    router.push(`/experiences/${experienceId}/browse`);
  };

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-foreground flex items-center justify-center p-4 relative">
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-neutral-800 rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">
              Create Your Lounge
            </h1>
            <p className="text-neutral-600 dark:text-neutral-400">
              Set up your voice chat room in just a few steps
            </p>
            {/* Company cap message handled by Create page LoadingScreen */}
          </div>

          {/* Minute Usage Warning */}
          {usageSummary && usageSummary.available <= 10 && (
            <div className="mb-6 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <div className="flex items-start gap-3">
                <div className="text-amber-600 dark:text-amber-400 mt-0.5">
                  ⚠️
                </div>
                <div>
                  <h3 className="text-sm font-medium text-amber-800 dark:text-amber-200 mb-1">
                    Low Minutes Warning
                  </h3>
                  <p className="text-sm text-amber-700 dark:text-amber-300 mb-3">
                    Your Whop has only {usageSummary.available} minutes
                    remaining. Consider upgrading before creating a lounge to
                    avoid interruptions.
                  </p>
                  <Button
                    onClick={() =>
                      router.push(`/experiences/${experienceId}/plans`)
                    }
                    size="sm"
                    className="text-white bg-amber-600 hover:bg-amber-700"
                  >
                    <ZapIcon className="h-4 w-4 mr-1" />
                    Upgrade Plan
                  </Button>
                </div>
              </div>
            </div>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Name Field */}
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-neutral-900 dark:text-white">
                      Lounge Name *
                    </FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter a name for your lounge..."
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                          onDataChange({ name: e.target.value });
                        }}
                        className="w-full"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Privacy Section */}
              <div className="space-y-4">
                <Label className="text-sm font-medium text-neutral-900 dark:text-white">
                  Privacy
                </Label>

                <div className="flex items-center space-x-3 p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg">
                  <Switch
                    id="privacy"
                    checked={isPublic}
                    onCheckedChange={handlePrivacyChange}
                  />
                  <div className="flex-1">
                    <Label
                      htmlFor="privacy"
                      className="text-sm font-medium text-neutral-900 dark:text-white"
                    >
                      {isPublic ? "Public Lounge" : "Private Lounge"}
                    </Label>
                    <p className="text-xs text-neutral-600 dark:text-neutral-400">
                      {isPublic
                        ? "Anyone can discover and join your lounge"
                        : "Only people with the lounge code can join"}
                    </p>
                  </div>
                </div>

                {/* Discover Toggle - Only show when public + admin + creator tier */}
                {isPublic &&
                  isOwner &&
                  planSettings?.planTier === "creator" && (
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg">
                        <Switch
                          id="discover"
                          checked={watch("discoverListed") || false}
                          onCheckedChange={(checked) => {
                            setValue("discoverListed", checked);
                            onDataChange({ discoverListed: checked });
                          }}
                        />
                        <div className="flex-1">
                          <Label
                            htmlFor="discover"
                            className="text-sm font-medium text-neutral-900 dark:text-white"
                          >
                            Discoverable Lounge
                          </Label>
                          <p className="text-xs text-neutral-600 dark:text-neutral-400">
                            Let others find and join your amazing lounge in our
                            explore page
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                {/* Discover Toggle - Disabled when not creator tier */}
                {isPublic &&
                  isOwner &&
                  planSettings?.planTier !== "creator" && (
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg opacity-60">
                        <Switch id="discover" disabled={true} checked={false} />
                        <div className="flex-1">
                          <Label
                            htmlFor="discover"
                            className="text-sm font-medium text-neutral-900 dark:text-white"
                          >
                            Discoverable Lounge
                          </Label>
                          <p className="text-xs text-neutral-600 dark:text-neutral-400">
                            Upgrade to Creator tier to make your lounges
                            discoverable
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                {/* Auto Speakers Toggle - Only show when public */}
                {isPublic && (
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg">
                      <Switch
                        id="autoSpeakers"
                        checked={watch("autoSpeakersEnabled") || false}
                        onCheckedChange={(checked) => {
                          setValue("autoSpeakersEnabled", checked);
                          onDataChange({ autoSpeakersEnabled: checked });
                        }}
                      />
                      <div className="flex-1">
                        <Label
                          htmlFor="autoSpeakers"
                          className="text-sm font-medium text-neutral-900 dark:text-white"
                        >
                          Enable Auto Speakers
                        </Label>
                        <p className="text-xs text-neutral-600 dark:text-neutral-400">
                          New members join as speakers (muted) instead of listeners. They can unmute themselves.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Room Code Display for Private Rooms */}
                {!isPublic && (
                  <div className="space-y-3 p-4 bg-neutral-50 dark:bg-neutral-700 rounded-lg">
                    <Label className="text-sm font-medium text-neutral-900 dark:text-white">
                      Room Code
                    </Label>

                    {isGeneratingCode ? (
                      <div className="flex items-center justify-center py-4 text-neutral-600 dark:text-neutral-400">
                        <Loader2 className="h-5 w-5 animate-spin mr-2" />
                        <span className="text-sm ">Generating code...</span>
                      </div>
                    ) : watch("roomCode") ? (
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <code className="flex-1 px-3 py-2 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-600 rounded text-lg font-mono text-center">
                            {watch("roomCode")}
                          </code>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={copyRoomCode}
                            className="shrink-0"
                          >
                            Copy
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={generateRoomCode}
                            disabled={isGeneratingCode}
                            className="shrink-0"
                          >
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="text-xs text-neutral-600 dark:text-neutral-400">
                          Share this code with others to let them join your
                          private lounge
                        </p>
                      </div>
                    ) : codeGenerationError ? (
                      <div className="space-y-2">
                        <p className="text-sm text-red-600 dark:text-red-400">
                          {codeGenerationError}
                        </p>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={generateRoomCode}
                          disabled={isGeneratingCode}
                        >
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Regenerate Code
                        </Button>
                      </div>
                    ) : null}
                  </div>
                )}
              </div>

              {/* Room lifecycle */}
              <div className="space-y-4">
                <Label className="text-sm font-medium text-neutral-900 dark:text-white">
                  Room Period
                </Label>
                <div
                  className={`flex items-center space-x-3 p-4 border border-neutral-200 dark:border-neutral-700 rounded-lg ${canEditLifecycle ? "" : "opacity-60"}`}
                >
                  <Switch
                    id="lifecycle"
                    checked={lifecycleChecked}
                    onCheckedChange={(checked) => {
                      const newIsTemporary = !checked;
                      setValue("isTemporary", newIsTemporary);
                      onDataChange({ isTemporary: newIsTemporary });
                    }}
                    disabled={!canEditLifecycle}
                  />
                  <div className="flex-1">
                    <Label
                      htmlFor="lifecycle"
                      className="text-sm font-medium text-neutral-900 dark:text-white"
                    >
                      {(isTemporary ?? true)
                        ? "Temporary Room"
                        : "Permanent Room"}
                    </Label>
                    <p className="text-xs text-neutral-600 dark:text-neutral-400">
                      Temporary rooms are deleted when the last participant
                      leaves. Permanent rooms stay and are set inactive when
                      empty.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleGoBack}
                  className="flex-1"
                >
                  ← Back to Browse
                </Button>
                <Button
                  type="submit"
                  disabled={
                    !watch("name").trim() ||
                    isGeneratingCode ||
                    (!isPublic && !watch("roomCode"))
                  }
                  className="flex-1 text-white"
                >
                  Continue
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
      <div className="absolute top-4 right-4">
        <ThemeToggler />
      </div>
    </div>
  );
}
