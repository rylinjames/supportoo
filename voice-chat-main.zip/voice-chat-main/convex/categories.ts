// Room categories for discover page
export const ROOM_CATEGORIES = [
  {
    id: "gaming",
    name: "Gaming",
    icon: "🎮",
    color: "#FF6B6B",
    description: "Video games, esports, and gaming communities",
  },
  {
    id: "sports",
    name: "Sports",
    icon: "⚽",
    color: "#4ECDC4",
    description: "Sports discussions, fitness, and athletic communities",
  },
  {
    id: "technology",
    name: "Technology",
    icon: "💻",
    color: "#45B7D1",
    description: "Programming, tech discussions, and software development",
  },
  {
    id: "trading",
    name: "Trading",
    icon: "📈",
    color: "#96CEB4",
    description: "Trading, investing, and financial discussions",
  },
  {
    id: "education",
    name: "Education",
    icon: "📚",
    color: "#FFEAA7",
    description: "Learning, tutoring, study groups, and educational content",
  },
  {
    id: "music",
    name: "Music",
    icon: "🎵",
    color: "#DDA0DD",
    description:
      "Music production, creative discussions, and artistic collaboration",
  },
  {
    id: "fashion",
    name: "Fashion",
    icon: "👗",
    color: "#FFB6C1",
    description: "Fashion, style, and beauty discussions",
  },
  {
    id: "entertainment",
    name: "Entertainment",
    icon: "🎬",
    color: "#FFA500",
    description: "Movies, TV shows, and entertainment content",
  },
  {
    id: "other",
    name: "Other",
    icon: "🔮",
    color: "#9370DB",
    description: "Other topics and general discussions",
  },
] as const;

// Type for category IDs
export type RoomCategory = (typeof ROOM_CATEGORIES)[number]["id"];

// Popular tags for room categorization
export const ROOM_TAGS = [
  // Gaming tags
  "gaming",
  "esports",
  "streaming",
  "competitive",
  "casual",

  // Sports tags
  "sports",
  "fitness",
  "athletics",
  "training",
  "coaching",

  // Technology tags
  "technology",
  "coding",
  "programming",
  "software",
  "development",
  "ai",
  "startup",

  // Trading tags
  "trading",
  "investing",
  "crypto",
  "stocks",
  "finance",
  "forex",

  // Education tags
  "education",
  "learning",
  "tutoring",
  "study",
  "academic",
  "courses",

  // Music tags
  "music",
  "production",
  "creative",
  "artists",
  "instruments",
  "recording",

  // Fashion tags
  "fashion",
  "style",
  "beauty",
  "design",
  "trends",
  "modeling",

  // Entertainment tags
  "entertainment",
  "movies",
  "tv",
  "streaming",
  "podcasts",
  "comedy",

  // General tags
  "community",
  "networking",
  "professional",
  "social",
  "discussion",
  "other",
] as const;

export type RoomTag = (typeof ROOM_TAGS)[number];

// Helper function to get category by ID
export function getCategoryById(id: string) {
  return ROOM_CATEGORIES.find((category) => category.id === id);
}

// Helper function to validate category ID
export function isValidCategory(id: string): id is RoomCategory {
  return ROOM_CATEGORIES.some((category) => category.id === id);
}

// Helper function to validate tags
export function isValidTag(tag: string): tag is RoomTag {
  return ROOM_TAGS.includes(tag as RoomTag);
}
