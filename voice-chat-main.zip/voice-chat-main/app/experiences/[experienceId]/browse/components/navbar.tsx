"use client";
import { useState, useEffect } from "react";
import { ThemeToggler } from "@/app/components/shared/theme-toggler";
import { Button } from "@/components/ui/button";
import { usePathname, useRouter } from "next/navigation";
import { Bell } from "lucide-react";
import { useQuery, useMutation, useAction } from "convex/react";
import { api } from "@/convex/_generated/api";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/animate-ui/radix/popover";
import { Id } from "@/convex/_generated/dataModel";
import Link from "next/link";
import { cn } from "@/lib/utils";
import MobileSidebar from "./mobile-sidebar";
import AdminSheet from "./admin-sheet";

const Navbar = ({
  whopExperienceId,
  syncState,
  convexUserId,
  whopUsername,
  whopUserId,
  companyName,
  whopCompanyId,
}: {
  whopExperienceId: string;
  syncState: "idle" | "syncing" | "success" | "error";
  convexUserId?: string;
  whopUsername?: string;
  whopUserId?: string;
  companyName?: string;
  whopCompanyId?: string;
}) => {
  const router = useRouter();
  const username =
    whopUsername ??
    (whopUserId
      ? whopUserId.startsWith("@")
        ? whopUserId.slice(1)
        : whopUserId
      : undefined);
  const pendingCount = useQuery(
    api.rooms.getPendingInviteCount,
    username
      ? {
          inviteeWhopUsername: username,
        }
      : "skip"
  );
  const invites = useQuery(
    api.rooms.getInvitesForWhopUser,
    username
      ? {
          inviteeWhopUsername: username,
        }
      : "skip"
  );
  const acceptInvite = useMutation(api.rooms.acceptInvite);
  const declineInvite = useMutation(api.rooms.declineInvite);

  // Check if user is company admin
  const checkUserIsCompanyAdmin = useAction(api.whop.checkUserIsCompanyAdmin);
  const [isCompanyAdmin, setIsCompanyAdmin] = useState<boolean | null>(null);

  // Check admin status when component mounts
  useEffect(() => {
    if (whopUserId && whopCompanyId) {
      checkUserIsCompanyAdmin({
        whopUserId,
        whopCompanyId,
      })
        .then((result) => {
          setIsCompanyAdmin(result?.isAdmin === true);
        })
        .catch(() => {
          setIsCompanyAdmin(false);
        });
    } else {
      setIsCompanyAdmin(false);
    }
  }, [whopUserId, whopCompanyId, checkUserIsCompanyAdmin]);

  const handleAccept = async (inviteId: Id<"invitations">) => {
    if (!convexUserId) return;
    const res = await acceptInvite({
      inviteId,
      userId: convexUserId as Id<"users">,
    });
    router.push(`/experiences/${whopExperienceId}/join/${res.roomId}`);
  };

  const handleDecline = async (inviteId: Id<"invitations">) => {
    if (!convexUserId) return;
    await declineInvite({ inviteId, userId: convexUserId as Id<"users"> });
  };

  const pathname = usePathname();
  const isBrowse = pathname === `/experiences/${whopExperienceId}/browse`;
  const isExplore = pathname === `/experiences/${whopExperienceId}/explore`;
  const heading = isExplore
    ? "Explore Lounges"
    : companyName
      ? `${companyName} Lounges`
      : "Your Lounges";
  return (
    <div className="fixed top-0 left-0 right-0 z-50 border-b bg-background border-neutral-200 dark:border-neutral-800 w-full p-4 flex items-center justify-between">
      <h1 className="text-lg md:text-2xl font-bold">{heading}</h1>
      <div className="hidden xl:flex absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 gap-4">
        <Link
          href={`/experiences/${whopExperienceId}/browse`}
          className={cn(
            "relative text-sm text-neutral-400 hover:text-neutral-800 dark:hover:text-white",
            pathname === `/experiences/${whopExperienceId}/browse` &&
              "text-neutral-800 dark:text-white after:absolute after:-bottom-1.5 after:left-0 after:w-full after:h-[1px] after:bg-neutral-800 dark:after:bg-white"
          )}
        >
          Your Lounges
        </Link>
        <Link
          href={`/experiences/${whopExperienceId}/explore`}
          className={cn(
            "relative text-sm text-neutral-400 hover:text-neutral-800 dark:hover:text-white",
            pathname === `/experiences/${whopExperienceId}/explore` &&
              "text-neutral-800 dark:text-white after:absolute after:-bottom-1.5 after:left-0 after:w-full after:h-[1px] after:bg-neutral-800 dark:after:bg-white"
          )}
        >
          Explore Lounges
        </Link>
      </div>
      <div className="flex items-center gap-2 md:gap-4">
        {/* Only show Admin Panel for company admins*/}
        {isCompanyAdmin === true && (
          <AdminSheet whopExperienceId={whopExperienceId} />
        )}
        {syncState === "success" && (
          <Popover>
            <PopoverTrigger>
              <div className="relative cursor-pointer">
                <Bell className="w-5 h-5 text-neutral-800 dark:text-white" />
                {pendingCount && pendingCount.count > 0 && (
                  <div className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full size-4">
                    <span className="text-xs absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2">
                      {pendingCount.count}
                    </span>
                  </div>
                )}
              </div>
            </PopoverTrigger>
            <PopoverContent className="w-60 p-0">
              <div className="p-3 border-b text-sm font-medium">
                Invitations
              </div>
              <div className="max-h-80 overflow-y-auto">
                {invites && invites.length > 0 ? (
                  invites.map((inv: any) => (
                    <div
                      key={inv._id}
                      className="p-3 border-b text-sm flex flex-col items-start gap-2"
                    >
                      <div className="flex-1">
                        <p className="font-medium line-clamp-1">
                          {inv.room?.name || "Private Lounge"}
                        </p>
                        <p className="text-xs text-neutral-500">
                          from @{inv.inviter?.whopUsername}{" "}
                          {!inv.room?.isPublic && "(Private Lounge)"}
                        </p>
                      </div>
                      <div className="flex gap-4">
                        <Button
                          size="sm"
                          className="text-primary p-0 hover:bg-transparent! hover:text-primary/80! h-max w-max"
                          variant="ghost"
                          onClick={() => handleAccept(inv._id)}
                        >
                          Accept
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-neutral-600 p-0 dark:text-neutral-400 hover:bg-transparent! hover:text-white! h-max w-max"
                          onClick={() => handleDecline(inv._id)}
                        >
                          Decline
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-sm text-neutral-500">
                    No invitations
                  </div>
                )}
              </div>
            </PopoverContent>
          </Popover>
        )}
        <ThemeToggler />
        <MobileSidebar
          whopExperienceId={whopExperienceId}
          syncState={syncState}
        />
        <Button
          size="sm"
          disabled={syncState !== "success"}
          onClick={() => router.push(`/experiences/${whopExperienceId}/create`)}
          className="text-white hidden xl:block"
        >
          Create Lounge
        </Button>
      </div>
    </div>
  );
};

export default Navbar;
