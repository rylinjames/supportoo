"use client";

import { motion } from "motion/react";
import { Mic, MicOff, Crown } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/avatar";
import { Participant } from "./types";
import { ReactionBadge } from "./reaction-badge";

interface ParticipantTileProps {
  participant: Participant;
  index: number;
  size?: "small" | "large";
  isRoomCreator?: boolean;
  roomId: string;
  convexUserId: string;
}

export function ParticipantTile({
  participant,
  index,
  size = "large",
  isRoomCreator = false,
  roomId,
  convexUserId,
}: ParticipantTileProps) {
  const getRoleIcon = (role: string) => {
    switch (role) {
      case "moderator":
        return <Crown className="w-3 h-3 text-yellow-400" />;
      case "speaker":
        return <Mic className="w-3 h-3 text-green-400" />;
      default:
        return null;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "moderator":
        return "bg-foreground/60 text-gray-300 border-neutral-800/50";
      case "speaker":
        return "bg-foreground/60 text-gray-400 border-neutral-800/50";
      default:
        return "bg-foreground/60 text-gray-400 border-neutral-800/50";
    }
  };

  const isLarge = size === "large";
  const avatarSize = isLarge ? "w-16 h-16" : "w-12 h-12";
  const nameSize = isLarge ? "text-sm" : "text-xs";

  // Handle anonymous users
  const displayName = participant.isAnonymous
    ? "Anonymous"
    : participant.name.split(" ")[0];
  const displayAvatar = participant.isAnonymous
    ? "/placeholder.svg"
    : participant.avatar || "/placeholder.svg";
  const avatarFallback = participant.isAnonymous
    ? "👤"
    : participant.name
        .split(" ")
        .map((n) => n[0])
        .join("");

  return (
    <motion.div
      className="flex flex-col items-center max-w-max"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay: index * (isLarge ? 0.1 : 0.02) }}
      whileHover={{ scale: 1.05 }}
    >
      <div className="relative mb-3">
        <motion.div
          className={`p-1 rounded-full ${
            participant.isSpeaking
              ? "bg-gradient-to-r from-emerald-500 to-emerald-500 transition-colors duration-300"
              : "bg-transparent"
          }`}
          animate={
            participant.isSpeaking
              ? {
                  boxShadow: [
                    "0 0 0 0 rgba(16, 185, 129, 0.4)",
                    "0 0 0 10px rgba(16, 185, 129, 0)",
                    "0 0 0 0 rgba(16, 185, 129, 0)",
                  ],
                }
              : {}
          }
          transition={{
            repeat: Number.POSITIVE_INFINITY,
          }}
        >
          <Avatar className={avatarSize}>
            <AvatarImage src={displayAvatar} alt={displayName} />
            <AvatarFallback className=" text-xs">
              {avatarFallback}
            </AvatarFallback>
          </Avatar>
        </motion.div>
        <motion.div
          className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center ${
            participant.isMuted
              ? "bg-red-600 dark:bg-red-700"
              : "bg-emerald-600"
          }`}
          whileHover={{ scale: 1.2 }}
          whileTap={{ scale: 0.9 }}
        >
          {participant.isMuted ? (
            <MicOff className="w-3 h-3 text-white" />
          ) : (
            <Mic className="w-3 h-3 text-white" />
          )}
        </motion.div>
        <ReactionBadge
          userId={participant.whopUserId}
          roomId={roomId}
          convexUserId={convexUserId}
        />
      </div>
      <h3
        className={`${nameSize} font-medium text-center mb-1 text-neutral-800! dark:text-white!`}
      >
        {displayName}
      </h3>

      <span className="flex items-center gap-1 text-neutral-600 dark:text-neutral-400">
        {isRoomCreator && <p className="text-xs">Host</p>}
      </span>
    </motion.div>
  );
}
