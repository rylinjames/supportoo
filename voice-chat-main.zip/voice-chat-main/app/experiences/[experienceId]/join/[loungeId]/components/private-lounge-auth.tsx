"use client";

import { useEffect, useState } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useRouter } from "next/navigation";
import { useSessionStore } from "@/stores/session-store";
import { Id } from "@/convex/_generated/dataModel";
import { Button } from "@/components/ui/button";
import { PrivateRoomCodeInput } from "./private-room-code-input";
import { ThemeToggler } from "@/app/components/shared/theme-toggler";

interface PrivateLoungeAuthProps {
  roomData: {
    id: string;
    name: string;
    creatorName: string;
    creatorId: string;
    isActive: boolean;
  };
  experienceId: string;
  loungeId: string;
}

export function PrivateLoungeAuth({
  roomData,
  experienceId,
  loungeId,
}: PrivateLoungeAuthProps) {
  const [isJoining, setIsJoining] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [autoTried, setAutoTried] = useState(false);
  const [needsCode, setNeedsCode] = useState(false);
  const router = useRouter();
  const { session } = useSessionStore();

  // Join private room mutation
  const joinPrivateRoom = useMutation(api.participants.joinPrivateRoom);

  // Attempt seamless entry for creators/allowed users (no code required)
  useEffect(() => {
    const tryAutoJoin = async () => {
      if (!session || autoTried) return;
      setAutoTried(true);
      setIsJoining(true);
      try {
        await joinPrivateRoom({
          roomId: loungeId as Id<"rooms">,
          userId: session.convexUserId,
          roomCode: "", // empty code; server permits for creator/allowed
          viewerIsCompanyAdmin: session.whopAccessLevel === "admin",
          requesterCompanyId: session.convexCompanyId,
        });
        router.push(`/experiences/${experienceId}/lounge/${loungeId}`);
      } catch (_e) {
        // Not allowed yet; show code input
        setIsJoining(false);
        setNeedsCode(true);
      }
    };
    tryAutoJoin();
  }, [session, loungeId, experienceId, router, joinPrivateRoom, autoTried]);

  const handleJoinWithCode = async (roomCode: string) => {
    if (!session || !roomCode || roomCode.length !== 8) return;

    setIsJoining(true);
    setError(null);

    try {
      await joinPrivateRoom({
        roomId: loungeId as Id<"rooms">,
        userId: session.convexUserId,
        roomCode: roomCode,
        viewerIsCompanyAdmin: session.whopAccessLevel === "admin",
        requesterCompanyId: session.convexCompanyId,
      });

      // Navigate to lounge on success
      router.push(`/experiences/${experienceId}/lounge/${loungeId}`);
    } catch (error) {
      console.error("Failed to join private room:", error);
      const raw =
        (error instanceof Error && error.message) ||
        (error as any)?.message ||
        "";
      const lower = String(raw).toLowerCase();
      let friendly = "Invalid room code. Please check and try again.";
      if (lower.includes("insufficient minutes")) {
        friendly =
          "Your Whop has insufficient minutes to join this lounge. Please upgrade your plan to continue.";
      }
      setError(friendly);
      setIsJoining(false);
    }
  };

  const handleCodeSubmit = (code: string) => {
    // Clear error when attempting to join
    if (error) setError(null);
    handleJoinWithCode(code);
  };

  return (
    <>
      {needsCode && (
        <div className="min-h-screen relative bg-neutral-50 dark:bg-foreground flex items-center justify-center p-4">
          <div className="w-full max-w-md">
            <div className="bg-white dark:bg-neutral-800 rounded-2xl shadow-xl p-8">
              <div className="text-center mb-8">
                <h1 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">
                  Join {roomData.creatorName.split(" ")[0]}'s Private Lounge
                </h1>
                <h2 className="text-lg font-medium text-neutral-700 dark:text-neutral-300 mb-2">
                  "{roomData.name}"
                </h2>
                {needsCode ? (
                  <p className="text-neutral-600 dark:text-neutral-400">
                    Enter the 8-character room code to join
                  </p>
                ) : (
                  <p className="text-neutral-600 dark:text-neutral-400">
                    Checking your access...
                  </p>
                )}
              </div>

              <PrivateRoomCodeInput
                onSubmit={handleCodeSubmit}
                isLoading={isJoining}
                error={error}
                creatorName={roomData.creatorName}
              />

              {/* Back Button */}
              <div className="text-center mt-6">
                <Button
                  variant="ghost"
                  onClick={() =>
                    router.push(`/experiences/${experienceId}/browse`)
                  }
                  disabled={isJoining}
                  className="text-neutral-600 dark:text-neutral-400"
                >
                  ← Back to Browse
                </Button>
              </div>
            </div>
          </div>
          <div className="absolute top-4 right-4">
            <ThemeToggler />
          </div>
        </div>
      )}
    </>
  );
}
