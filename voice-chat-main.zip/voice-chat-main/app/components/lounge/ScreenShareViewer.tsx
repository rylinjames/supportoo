import { useEffect, useRef, useState } from "react";
import { RemoteVideoTrack, LocalVideoTrack, Track } from "livekit-client";
import {
  useRemoteParticipants,
  useLocalParticipant,
} from "@livekit/components-react";
import { Maximize2, Minimize2, User, Eye, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Participant } from "./types";

interface ScreenShareViewerProps {
  className?: string;
  participants?: Participant[];
}

/**
 * ScreenShareViewer - Display shared screen content
 *
 * Features:
 * - Automatic track attachment/detachment
 * - Presenter information display
 * - Maximize/minimize controls
 * - Graceful handling of no content
 * - Optimized video rendering
 */
export function ScreenShareViewer({
  className = "",
  participants = [],
}: ScreenShareViewerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const [screenTrack, setScreenTrack] = useState<
    RemoteVideoTrack | LocalVideoTrack | null
  >(null);
  const [presenter, setPresenter] = useState<{
    name: string;
    identity: string;
  } | null>(null);
  const [isLocalPresenter, setIsLocalPresenter] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const fullscreenContainerRef = useRef<HTMLDivElement>(null);

  const remoteParticipants = useRemoteParticipants();
  const { localParticipant } = useLocalParticipant();

  /**
   * Format presenter name and role for display
   * "David Gbams" + "moderator" → "David (Moderator) presenting"
   */
  const formatPresenterName = (
    presenterName: string,
    identity: string
  ): string => {
    // Find the participant's role from the participants array
    const participant = participants.find((p) => p.whopUserId === identity);

    if (!participant) {
      // Fallback to just first name if participant not found
      const firstName = presenterName.split(" ")[0];
      return `${firstName} is presenting`;
    }

    // Extract first name
    const firstName = presenterName.split(" ")[0];

    // Capitalize role (moderator → Moderator)
    const role =
      participant.role.charAt(0).toUpperCase() + participant.role.slice(1);

    return `${firstName} (${role}) is presenting`;
  };

  /**
   * Find and attach screen share track
   */
  useEffect(() => {
    let foundTrack: RemoteVideoTrack | LocalVideoTrack | null = null;
    let presenterInfo: { name: string; identity: string } | null = null;
    let isLocal = false;

    // First check local participant (when you're sharing your own screen)
    if (localParticipant) {
      const localScreenPublication = localParticipant.getTrackPublication(
        Track.Source.ScreenShare
      );

      if (localScreenPublication?.track) {
        foundTrack = localScreenPublication.track as LocalVideoTrack;
        presenterInfo = {
          name: localParticipant.name || localParticipant.identity,
          identity: localParticipant.identity,
        };
        isLocal = true;
      }
    }

    // If no local screen share, check remote participants
    if (!foundTrack) {
      for (const participant of remoteParticipants) {
        const screenSharePublication = participant.getTrackPublication(
          Track.Source.ScreenShare
        );

        if (
          screenSharePublication?.isSubscribed &&
          screenSharePublication.videoTrack
        ) {
          foundTrack = screenSharePublication.videoTrack as RemoteVideoTrack;
          presenterInfo = {
            name: participant.name || participant.identity,
            identity: participant.identity,
          };
          isLocal = false;
          console.log("📺 Found REMOTE screen share track");
          break;
        }
      }
    }

    setScreenTrack(foundTrack);
    setPresenter(presenterInfo);
    setIsLocalPresenter(isLocal);

    // For remote screen shares, attach to main video element
    // For local screen shares, don't attach (avoid recursion)
    if (foundTrack && !isLocal && videoRef.current) {
      console.log("📺 Attaching REMOTE screen share track to video element");
      foundTrack.attach(videoRef.current);
    }

    // Cleanup function - detach track
    return () => {
      if (foundTrack && videoRef.current && !isLocal) {
        console.log("🧹 Detaching screen share track");
        foundTrack.detach(videoRef.current);
      }
    };
  }, [remoteParticipants, localParticipant]);

  /**
   * Handle preview functionality for local presenter
   */
  useEffect(() => {
    if (
      screenTrack &&
      isLocalPresenter &&
      showPreview &&
      previewVideoRef.current
    ) {
      console.log("📺 Attaching LOCAL screen share track to preview");
      screenTrack.attach(previewVideoRef.current);
    }

    return () => {
      if (screenTrack && isLocalPresenter && previewVideoRef.current) {
        screenTrack.detach(previewVideoRef.current);
      }
    };
  }, [screenTrack, isLocalPresenter, showPreview]);

  /**
   * Fullscreen functionality - like video players
   */
  const enterFullscreen = async () => {
    if (fullscreenContainerRef.current) {
      try {
        await fullscreenContainerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } catch (error) {
        console.error("Failed to enter fullscreen:", error);
      }
    }
  };

  const exitFullscreen = async () => {
    try {
      await document.exitFullscreen();
      setIsFullscreen(false);
    } catch (error) {
      console.error("Failed to exit fullscreen:", error);
    }
  };

  const toggleFullscreen = () => {
    if (isFullscreen) {
      exitFullscreen();
    } else {
      enterFullscreen();
    }
  };

  // Mobile detection
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 1024);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Listen for fullscreen changes (e.g., ESC key)
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
    };
  }, []);

  /**
   * Render no content state
   */
  if (!screenTrack) {
    return (
      <div
        className={`flex-1 bg-neutral-900 flex items-center justify-center ${className}`}
      >
        <div className="text-center">
          <div className="text-6xl mb-4">📺</div>
          <p className="text-lg font-medium">No screen being shared</p>
          <p className="text-sm text-neutral-400 mt-2">
            Moderators can share their screen to present content
          </p>
        </div>
      </div>
    );
  }

  /**
   * Render local presenter view (with preview button)
   */
  if (isLocalPresenter) {
    return (
      <div
        ref={fullscreenContainerRef}
        className={`relative bg-neutral-900 flex items-center justify-center ${
          isFullscreen ? "w-screen h-screen" : "flex-1"
        } ${className}`}
        style={{
          // Ensure proper fullscreen behavior
          ...(isFullscreen && {
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            zIndex: 9999,
          }),
        }}
      >
        <div className="text-center">
          <div className="text-6xl mb-4">🎥</div>
          <p className="text-lg font-medium mb-4">You're presenting</p>
          <p className="text-sm text-neutral-400 mb-6">
            Your audience can see your screen. Click preview to see what you're
            sharing.
          </p>

          <div className="flex gap-3 justify-center">
            <Button onClick={() => setShowPreview(true)} className="">
              <Eye className="h-4 w-4" />
              Preview Your Screen Share
            </Button>

            <Button
              onClick={toggleFullscreen}
              variant="outline"
              size={isMobile ? "lg" : "default"}
              className={isMobile ? "h-12 text-base" : ""}
            >
              {isFullscreen ? (
                <Minimize2
                  className={isMobile ? "h-5 w-5 mr-2" : "h-4 w-4 mr-2"}
                />
              ) : (
                <Maximize2
                  className={isMobile ? "h-5 w-5 mr-2" : "h-4 w-4 mr-2"}
                />
              )}
              {isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
            </Button>
          </div>
        </div>

        {/* Preview Dialog */}
        {showPreview && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100]">
            <div className="bg-neutral-900 rounded-lg p-4 max-w-4xl max-h-4xl w-full h-full m-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white text-lg font-medium">
                  Preview: What your audience sees
                </h3>
                <Button
                  onClick={() => setShowPreview(false)}
                  variant="ghost"
                  size="sm"
                  className="text-neutral-400 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <video
                ref={previewVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain rounded"
                style={{
                  imageRendering: "crisp-edges",
                }}
              />
            </div>
          </div>
        )}

        {/* Presenter info */}
        {presenter && (
          <div className="absolute top-4 right-4 bg-black/50 px-3 py-1 rounded text-white text-sm flex items-center space-x-2 backdrop-blur-sm">
            <User className="h-4 w-4" />
            <span>
              {formatPresenterName(presenter.name, presenter.identity)}
            </span>
          </div>
        )}
      </div>
    );
  }

  /**
   * Render remote screen share content
   */
  return (
    <div
      ref={fullscreenContainerRef}
      className={`relative bg-black flex items-center justify-center ${
        isFullscreen ? "w-screen h-screen" : "flex-1"
      } ${className}`}
      style={{
        // Ensure proper fullscreen behavior
        ...(isFullscreen && {
          position: "fixed",
          top: 0,
          left: 0,
          width: "100vw",
          height: "100vh",
          zIndex: 9999,
        }),
      }}
    >
      {/* Video element */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className={`w-full h-full ${
          isFullscreen ? "object-contain" : "object-contain"
        }`}
        style={{
          // Optimize video rendering
          imageRendering: "crisp-edges", // Better for screen content
          // Fullscreen video styling like YouTube
          ...(isFullscreen && {
            maxWidth: "100vw",
            maxHeight: "100vh",
          }),
        }}
      />

      {/* Controls overlay */}
      <div className="absolute top-4 right-4 flex items-center space-x-2">
        {/* Fullscreen button - larger for mobile */}
        <Button
          onClick={toggleFullscreen}
          size={isMobile ? "default" : "sm"}
          variant="secondary"
          className={`bg-black/50 hover:bg-black/70 text-white border-0 backdrop-blur-sm ${
            isMobile ? "h-12 w-12 p-0" : ""
          }`}
          title={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
        >
          {isFullscreen ? (
            <Minimize2 className={isMobile ? "h-6 w-6" : "h-4 w-4"} />
          ) : (
            <Maximize2 className={isMobile ? "h-6 w-6" : "h-4 w-4"} />
          )}
        </Button>

        {/* Presenter info */}
        {presenter && (
          <div className="bg-black/50 px-3 py-1 rounded text-white text-sm flex items-center space-x-2 backdrop-blur-sm">
            <User className="h-4 w-4" />
            <span>{presenter.name} presenting</span>
          </div>
        )}
      </div>

      {/* Quality indicator (bottom left) */}
      {screenTrack && (
        <div className="absolute bottom-4 left-4">
          <div className="bg-black/50 px-2 py-1 rounded text-white text-xs backdrop-blur-sm">
            🔴 Live • 🔊 System Audio
          </div>
        </div>
      )}

      {/* Exit fullscreen hint (only when in fullscreen) */}
      {isFullscreen && (
        <div className="absolute top-4 left-4">
          <div className="bg-black/50 px-3 py-1 rounded text-white text-sm backdrop-blur-sm">
            Press <kbd className="bg-white/20 px-1 rounded">Esc</kbd> or click
            minimize to exit fullscreen
          </div>
        </div>
      )}
    </div>
  );
}
