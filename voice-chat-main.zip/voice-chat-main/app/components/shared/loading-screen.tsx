"use client";

import { ArrowRight, Mic, RefreshCw } from "lucide-react";
import Link from "next/link";
import { AnimatedDots } from "../ui/animated-dots";
import { Button } from "@/components/ui/button";
import { usePathname, useRouter } from "next/navigation";

const LoadingScreen = ({
  message,
  error,
  success,
  info,
  whopExperienceId,
  children,
  showButtons = true,
}: {
  message?: string | null;
  error?: boolean | null;
  success?: boolean | null;
  info?: boolean | null;
  whopExperienceId?: string | null;
  children?: React.ReactNode;
  showButtons?: boolean;
}) => {
  const router = useRouter();
  const pathname = usePathname();
  const experienceId = whopExperienceId || pathname.split("/")[2];

  return (
    <div className="flex items-center justify-center min-h-screen h-full p-8 relative">
      <div className="text-center max-w-md">
        <div className="flex flex-col gap-2 justify-center items-center">
          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-primary flex items-center justify-center animate-pulse">
            <Mic className="h-16 w-16 text-white" />
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 mt-2">
          {message ? (
            <>
              {error && (
                <div className="flex flex-col items-center justify-center gap-2">
                  <p className="text-sm text-red-600 dark:text-red-400 p-2 bg-red-600/10 dark:bg-red-400/10 rounded-md">
                    {message}
                  </p>
                  <div className="flex gap-3 justify-center">
                    <Button
                      onClick={() => router.refresh()}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      <RefreshCw className="h-4 w-4" />
                      Try Again
                    </Button>
                    <Button
                      onClick={() =>
                        router.push(`/experiences/${experienceId}/browse`)
                      }
                      className="flex items-center gap-2 text-white"
                    >
                      <ArrowRight className="h-4 w-4" />
                      Go to Browse
                    </Button>
                  </div>
                </div>
              )}
              {success && (
                <p className="text-sm text-green-600 dark:text-green-400 p-2 bg-green-600/10 dark:bg-green-400/10 rounded-md">
                  {message}
                </p>
              )}
              {info && (
                <div className="flex flex-col items-center justify-center gap-2">
                  <p className="text-sm text-neutral-600 dark:text-neutral-400 p-2 bg-neutral-600/10 dark:bg-neutral-400/10 rounded-md">
                    {message}
                  </p>
                  {showButtons && (
                    <div className="flex gap-3 justify-center">
                      <Button
                        onClick={() =>
                          router.push(`/experiences/${experienceId}/browse`)
                        }
                        variant="outline"
                        className="flex items-center gap-2 text-neutral-800 dark:text-white"
                      >
                        <ArrowRight className="h-4 w-4" />
                        Go to Browse
                      </Button>
                      {children}
                    </div>
                  )}
                </div>
              )}
            </>
          ) : (
            <AnimatedDots
              size="lg"
              className="text-neutral-200 dark:text-neutral-400"
            />
          )}
        </div>
      </div>
      <p className="text-sm text-neutral-600 dark:text-neutral-400 absolute bottom-4 left-1/2 -translate-x-1/2">
        powered by{" "}
        <Link
          className="text-black dark:text-white hover:underline"
          href="https://whop.com/joined/bookoo-apps-developers/"
        >
          Bookoo Apps
        </Link>
      </p>
    </div>
  );
};

export default LoadingScreen;
