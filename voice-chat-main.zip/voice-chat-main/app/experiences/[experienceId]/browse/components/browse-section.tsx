import { EnrichedRoom } from "@/convex/browse";
import { ChevronRightIcon } from "lucide-react";
import LoungeCard from "./lounge-card";
import LoadingCard from "./loading-card";

const BrowseSection = ({
  title,
  noLoungeText,
  lounges,
  isLoading = false,
}: {
  title: string;
  noLoungeText: string;
  lounges: EnrichedRoom[] | undefined;
  isLoading?: boolean;
}) => {
  return (
    <section className="mb-6 max-w-screen">
      <div className="relative max-w-max">
        <h2 className="font-medium">{title}</h2>
        <ChevronRightIcon className="size-5 absolute -right-5 top-[3px] text-neutral-500" />
      </div>
      <div className="relative flex gap-4 py-4 min-h-100 md:min-h-120 max-md:overflow-x-scroll md:grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {isLoading ? (
          // Loading skeleton
          <>
            {[...Array(4)].map((_, i) => (
              <LoadingCard key={i} />
            ))}
          </>
        ) : lounges?.length ? (
          lounges.map((room) => <LoungeCard key={room._id} lounge={room} />)
        ) : (
          <p className="text-neutral-400 text-sm col-span-full w-full text-center absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            {noLoungeText}
          </p>
        )}
      </div>
    </section>
  );
};

export default BrowseSection;
