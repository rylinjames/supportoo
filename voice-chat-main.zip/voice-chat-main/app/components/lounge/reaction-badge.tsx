"use client";

import { motion, AnimatePresence } from "motion/react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Id } from "@/convex/_generated/dataModel";
import { RoomReaction } from "@/types/participants";

interface ReactionBadgeProps {
  userId: string;
  roomId: string;
  convexUserId: string; // The Convex user ID to match against
}

export function ReactionBadge({
  userId,
  roomId,
  convexUserId,
}: ReactionBadgeProps) {
  // Get real-time reactions for this room
  const roomReactions: RoomReaction[] | undefined = useQuery(
    api.reactions.getRoomReactions,
    {
      roomId: roomId as Id<"rooms">,
    }
  );

  // Find the reaction for this specific user (only 1 per user now)
  const userReaction = roomReactions?.find(
    (reaction: RoomReaction) => reaction.userId === convexUserId
  );

  if (!userReaction) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0, opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="absolute -top-1 -right-1 size-6 bg-foreground border-neutral-200 dark:border-neutral-700 rounded-full flex items-center justify-center shadow-lg border z-10"
      >
        <span className="text-sm">{userReaction.emoji}</span>
      </motion.div>
    </AnimatePresence>
  );
}
