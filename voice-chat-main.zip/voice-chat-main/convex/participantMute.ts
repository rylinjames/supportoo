"use node";

import { action } from "./_generated/server";
import { mutation } from "./_generated/server";
import { api } from "./_generated/api";
import { v } from "convex/values";
import { createLoungeEvent, EVENT_TYPES } from "./events";

/**
 * Mute a specific participant (speaker only)
 * Can be called by moderators, room creators, or Whop admins
 */
export const muteParticipant = action({
  args: {
    roomId: v.id("rooms"),
    targetUserId: v.id("users"),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
    isWhopAdmin: v.boolean(),
  },
  handler: async (ctx, args): Promise<{ success: boolean; participantName?: string }> => {
    // 1. Validate requester permissions
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");

    const requesterParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.requesterId }
    );
    if (!requesterParticipant) throw new Error("Requester not in room");

    const targetParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.targetUserId }
    );
    if (!targetParticipant) throw new Error("Target user not in room");

    // Permission checks
    const isCreator = room.creatorId === args.requesterId;
    const isRequesterModerator = requesterParticipant.role === "moderator";
    const canManageModerators = isCreator || args.isWhopAdmin;

    // Only moderators, creators, or Whop admins can mute
    if (!(isRequesterModerator || canManageModerators)) {
      throw new Error("Not authorized to mute participants");
    }

    // Can only mute speakers (not moderators or listeners)
    if (targetParticipant.role !== "speaker") {
      throw new Error("Can only mute speakers");
    }

    // Can't mute the room creator
    if (room.creatorId === args.targetUserId) {
      throw new Error("Cannot mute the room creator");
    }

    // 2. Update Convex database
    await ctx.runMutation(api.participants.updateMuteStatus, {
      roomId: args.roomId,
      userId: args.targetUserId,
      isMuted: true,
    });

    // 3. Update LiveKit permissions
    const targetUser = await ctx.runQuery(api.users.getUser, {
      userId: args.targetUserId,
    });
    if (!targetUser?.whopUserId) {
      throw new Error("Target user not found");
    }

    const muteResult = await ctx.runAction(
      api.livekit.setParticipantPublishPermission,
      {
        roomName: args.roomId as unknown as string,
        participantIdentity: targetUser.whopUserId,
        canPublish: false,
      }
    );

    if (!muteResult.success) {
      console.error("Failed to mute in LiveKit:", muteResult.error);
      // Don't throw - database is already updated, LiveKit will sync eventually
    }

    // 4. Create lounge event
    await createLoungeEvent(ctx, {
      roomId: args.roomId,
      eventType: EVENT_TYPES.PARTICIPANT_MUTED,
      userId: args.targetUserId,
      eventData: {
        userName: targetUser.fullName.split(" ")[0], // First name
        actorUserName: "Unknown", // Will be set properly below
      },
    });

    return { success: true, participantName: targetUser.fullName };
  },
});

/**
 * Mute all speakers in a room
 * Can be called by moderators, room creators, or Whop admins
 */
export const muteAllSpeakers = action({
  args: {
    roomId: v.id("rooms"),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
    isWhopAdmin: v.boolean(),
  },
  handler: async (ctx, args): Promise<{ success: boolean; mutedCount: number; message?: string; errors?: string[] }> => {
    // 1. Validate requester permissions
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");

    const requesterParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.requesterId }
    );
    if (!requesterParticipant) throw new Error("Requester not in room");

    // Permission checks
    const isCreator = room.creatorId === args.requesterId;
    const isRequesterModerator = requesterParticipant.role === "moderator";
    const canManageModerators = isCreator || args.isWhopAdmin;

    // Only moderators, creators, or Whop admins can mute all
    if (!(isRequesterModerator || canManageModerators)) {
      throw new Error("Not authorized to mute participants");
    }

    // 2. Get all speakers in the room
    const speakers = await ctx.runQuery(api.participants.getRoomParticipants, {
      roomId: args.roomId,
    });

    const speakerParticipants = speakers.filter((p: any) => p.role === "speaker");

    if (speakerParticipants.length === 0) {
      return { success: true, mutedCount: 0, message: "No speakers to mute" };
    }

    // 3. Batch update database and LiveKit permissions
    let mutedCount = 0;
    const errors: string[] = [];

    for (const speaker of speakerParticipants) {
      try {
        // Skip room creator
        if (room.creatorId === speaker.userId) {
          continue;
        }

        // Update database
        await ctx.runMutation(api.participants.updateMuteStatus, {
          roomId: args.roomId,
          userId: speaker.userId,
          isMuted: true,
        });

        // Update LiveKit permissions
        if (speaker.user?.whopUserId) {
          const muteResult = await ctx.runAction(
            api.livekit.setParticipantPublishPermission,
            {
              roomName: args.roomId as unknown as string,
              participantIdentity: speaker.user.whopUserId,
              canPublish: false,
            }
          );

          if (!muteResult.success) {
            errors.push(
              `Failed to mute ${speaker.user.fullName}: ${muteResult.error}`
            );
          }
        }

        mutedCount++;
      } catch (error) {
        errors.push(
          `Failed to mute ${speaker.user?.fullName || "Unknown"}: ${error}`
        );
      }
    }

    // 4. Create lounge event
    await createLoungeEvent(ctx, {
      roomId: args.roomId,
      eventType: EVENT_TYPES.ALL_SPEAKERS_MUTED,
      userId: args.requesterId,
      eventData: {
        userName: "Unknown", // Will be set properly below
      },
    });

    return {
      success: true,
      mutedCount,
      errors: errors.length > 0 ? errors : undefined,
    };
  },
});

/**
 * Unmute a specific participant
 * Can be called by moderators, room creators, or Whop admins
 */
export const unmuteParticipant = action({
  args: {
    roomId: v.id("rooms"),
    targetUserId: v.id("users"),
    requesterId: v.id("users"),
    requesterCompanyId: v.id("companies"),
    isWhopAdmin: v.boolean(),
  },
  handler: async (ctx, args): Promise<{ success: boolean; participantName?: string }> => {
    // 1. Validate requester permissions (same as mute)
    const room = await ctx.runQuery(api.rooms.getRoom, { roomId: args.roomId });
    if (!room) throw new Error("Room not found");

    const requesterParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.requesterId }
    );
    if (!requesterParticipant) throw new Error("Requester not in room");

    const targetParticipant = await ctx.runQuery(
      api.participants.getParticipantByRoomAndUser,
      { roomId: args.roomId, userId: args.targetUserId }
    );
    if (!targetParticipant) throw new Error("Target user not in room");

    // Permission checks
    const isCreator = room.creatorId === args.requesterId;
    const isRequesterModerator = requesterParticipant.role === "moderator";
    const canManageModerators = isCreator || args.isWhopAdmin;

    if (!(isRequesterModerator || canManageModerators)) {
      throw new Error("Not authorized to unmute participants");
    }

    // Can only unmute speakers (not moderators or listeners)
    if (targetParticipant.role !== "speaker") {
      throw new Error("Can only unmute speakers");
    }

    // 2. Update Convex database
    await ctx.runMutation(api.participants.updateMuteStatus, {
      roomId: args.roomId,
      userId: args.targetUserId,
      isMuted: false,
    });

    // 3. Update LiveKit permissions
    const targetUser = await ctx.runQuery(api.users.getUser, {
      userId: args.targetUserId,
    });
    if (!targetUser?.whopUserId) {
      throw new Error("Target user not found");
    }

    const unmuteResult = await ctx.runAction(
      api.livekit.setParticipantPublishPermission,
      {
        roomName: args.roomId as unknown as string,
        participantIdentity: targetUser.whopUserId,
        canPublish: true,
      }
    );

    if (!unmuteResult.success) {
      console.error("Failed to unmute in LiveKit:", unmuteResult.error);
      // Don't throw - database is already updated
    }

    // 4. Create lounge event
    await createLoungeEvent(ctx, {
      roomId: args.roomId,
      eventType: EVENT_TYPES.PARTICIPANT_UNMUTED,
      userId: args.targetUserId,
      eventData: {
        userName: targetUser.fullName.split(" ")[0],
        actorUserName: "Unknown", // Will be set properly below
      },
    });

    return { success: true, participantName: targetUser.fullName };
  },
});
