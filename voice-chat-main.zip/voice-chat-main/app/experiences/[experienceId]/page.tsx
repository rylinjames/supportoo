"use client";

import { redirect, usePathname } from "next/navigation";

const ExperiencePage = () => {
  const pathname = usePathname();
  const experienceId = pathname.split("/")[2];

  redirect(`/experiences/${experienceId}/browse`);

  return null;
};

export default ExperiencePage;
