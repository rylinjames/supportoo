import { mutation } from "./_generated/server";
import { v } from "convex/values";
import { internal } from "./_generated/api";

// Create default company for the app
export const createDefaultCompany = mutation({
  args: {
    ownerId: v.id("users"), // Whop user ID converted to Convex user ID
  },
  handler: async (ctx, args) => {
    // Check if default company already exists
    const existing = await ctx.db
      .query("companies")
      .withIndex("by_whop_company_id", (q) =>
        q.eq("whopCompanyId", "test-company")
      )
      .first();

    if (existing) {
      return existing._id; // Return existing company ID
    }

    // Create new default company
    const companyId = await ctx.db.insert("companies", {
      whopCompanyId: "test-company",
      whopExperienceId: "test-experience",
      name: "Test Company",
      owner: args.ownerId,
      isActive: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    return companyId;
  },
});

// Initialize cron jobs for cleanup
export const initializeCronJobs = mutation({
  args: {},
  handler: async (
    ctx
  ): Promise<{ dailyCronId: string; hourlyCronId: string }> => {
    console.log("🚀 Initializing cron jobs...");

    // Register the daily cleanup cron job
    const dailyCronId: string = await ctx.runMutation(
      internal.cleanup.registerDailyCleanupCron,
      {}
    );

    // Register the hourly cleanup cron job
    const hourlyCronId: string = await ctx.runMutation(
      internal.cleanup.registerHourlyCleanupCron,
      {}
    );

    console.log("✅ All cron jobs initialized successfully");
    return { dailyCronId, hourlyCronId };
  },
});
